# Bluetooth HFP Voice Chat (Linux daemon + Android system app + JNI)

This package contains:
- **linux/bt_chatd**: Linux-level Bluetooth HFP-AG daemon (BlueZ + ALSA + SCO + CVSD bridge).
- **android/BtChatController**: Android 4.4 UI app (installed to `/system/app`) that controls the daemon.
- **android/BtChatController/app/src/main/cpp**: JNI native client that talks to `/dev/socket/bt_chatd` using AF_UNIX.
- **docs/**: Step-by-step setup and usage.

## Target environment
- Linux kernel: 3.4
- Android: 4.4 (system app install path: `/system/app/`)
- Bluetooth controller: USB
- Headset: classic BT headset supporting HFP (CVSD baseline).

## What this does
- Pair / trust / connect headsets via BlueZ D-Bus
- Simulate “phone-call style” chat:
  - Dial / Incoming / Answer / Reject / Hangup
  - “Number” displayed as MAC address
  - Volume state + control (AT+VGS, AT+VGM)
- Open SCO link and bridge audio:
  - Local ALSA PCM (8kHz, mono, S16_LE)
  - <-> CVSD <-> SCO packets

## Quick start
See: `docs/SETUP.md` and `docs/USAGE.md`
