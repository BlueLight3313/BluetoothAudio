# Setup guide (step-by-step)

This guide assumes you have **root** and can install a **system app** to `/system/app/`.

---

## 1) Prepare the device

### 1.1 Stop Android Bluetooth stack (Bluedroid)
Android 4.4 commonly runs Bluedroid services that will fight for the USB BT controller.

Try (vendor-specific):
```sh
stop bluetooth
stop bluetoothd
stop bluetooth_manager
stop bluedroid
```

Verify nothing BT-related is still running:
```sh
ps | grep -i -E "blue|bt"
```

If needed:
```sh
killall -9 bluetoothd bluetooth_manager
```

> Goal: only **BlueZ bluetoothd** should own the controller.

---

## 2) Load kernel modules

```sh
modprobe btusb
modprobe bluetooth
modprobe rfcomm
modprobe sco
```

Bring up the adapter:
```sh
hciconfig hci0 up
hciconfig -a
```

---

## 3) Start BlueZ bluetoothd

Create `/etc/bluetooth/main.conf` (if available on your rootfs):
```ini
[General]
Name = EmbeddedChat
DiscoverableTimeout = 0
PairableTimeout = 0
AutoEnable = true
```

Start bluetoothd (path may differ):
```sh
bluetoothd -n -d &
```

---

## 4) Verify ALSA mic & speaker

List devices:
```sh
arecord -l
aplay -l
```

Record + play quick test:
```sh
arecord -D default -f S16_LE -c 1 -r 8000 -d 3 /data/local/tmp/test.wav
aplay -D default /data/local/tmp/test.wav
```

If `default` doesn't work, use `plughw:X,Y` for your board.

---

## 5) Build and install the Linux daemon

### Option A: build on-device
```sh
cd linux/bt_chatd
make
```

### Option B: cross-compile
Use your cross toolchain and copy the resulting `bt_chatd` to the device.

### Install binary
Copy to `/system/bin/`:
```sh
adb root
adb remount
adb push linux/bt_chatd/bt_chatd /system/bin/bt_chatd
adb shell chmod 0755 /system/bin/bt_chatd
```

---

## 6) Start daemon manually (first test)

The daemon creates a control socket at:
- `/dev/socket/bt_chatd`

Start it:
```sh
adb shell /system/bin/bt_chatd --adapter hci0 --pcm-capture default --pcm-playback default
```

In another shell, test control:
```sh
adb shell 'echo STATUS | nc -U /dev/socket/bt_chatd'
```

---

## 7) Run daemon at boot (init.rc)

Add to your device init file (example snippet):

```rc
service bt_chatd /system/bin/bt_chatd --adapter hci0 --pcm-capture default --pcm-playback default
    class main
    user root
    group root bluetooth audio system
    disabled
    oneshot

on property:sys.boot_completed=1
    start bt_chatd
```

> `bt_chatd` itself sets permissions on `/dev/socket/bt_chatd` to be usable by the `system` user.

---

## 8) Build and install the Android system app

### Build APK
Open `android/BtChatController` in Android Studio and build the APK.

### Install to `/system/app/`
```sh
adb root
adb remount
adb shell mkdir -p /system/app/BtChatController
adb push android/BtChatController/app/build/outputs/apk/debug/app-debug.apk /system/app/BtChatController/BtChatController.apk
adb shell chmod 0644 /system/app/BtChatController/BtChatController.apk
adb reboot
```

After reboot, open **BtChatController** app.

---

## Troubleshooting

### A) HFP connects but no audio / noise
SCO packet sizes and CVSD handling can vary by controller/kernel.
Collect:
```sh
dmesg | grep -i -E "btusb|bluetooth|hci|sco"
hcitool con
```
and tune `sco_audio.cpp` buffering.

### B) Headset pairs but HFP RFCOMM doesn't show AT traffic
Some headsets require SDP/BlueZ Profile1 registration rather than a fixed RFCOMM channel.
This demo uses channel 8. If you see this issue, upgrade to Profile1-based HFP registration.

### C) ALSA busy
Stop Android audio services that lock the sound card, or use a different ALSA device.
