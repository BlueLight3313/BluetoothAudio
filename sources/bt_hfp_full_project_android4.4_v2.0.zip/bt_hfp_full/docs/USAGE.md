# Usage guide

## Concepts
- **Device acts as HFP Audio Gateway (AG)**.
- Headset acts as **Hands-Free (HF)**.
- The “phone number” in this system is a **user-defined value**:
  - we use **MAC address** as the identifier for both device and headset.

## Linux-side (daemon) control protocol
Control socket: `/dev/socket/bt_chatd`

Commands (one per line):
- `STATUS`
- `SCAN ON` / `SCAN OFF`
- `PAIR <MAC>`
- `TRUST <MAC>`
- `CONNECT <MAC>`
- `DIAL <MAC>`
- `ANSWER`
- `REJECT`
- `HANGUP`
- `SET_SPK 0..15`
- `SET_MIC 0..15`

Example (shell):
```sh
nc -U /dev/socket/bt_chatd
STATUS
SCAN ON
PAIR 01:23:45:67:89:AB
TRUST 01:23:45:67:89:AB
CONNECT 01:23:45:67:89:AB
DIAL 01:23:45:67:89:AB
```

## Android app
Open **BtChatController**:
1) Enter headset MAC address
2) Tap **Pair**, then **Trust**
3) Tap **Connect**
4) Tap **Dial** to start voice chat
5) Use **Hangup**, **Answer**, **Reject** accordingly
6) Adjust speaker/mic gains

The app calls into JNI which sends commands to the daemon.

## Typical states
`STATUS` example:
```
adapter=hci0 my_number=AA:BB:CC:DD:EE:FF connected=01:23:45:67:89:AB peer=01:23:45:67:89:AB call=ACTIVE sco=1 spk=8 mic=8 scanning=0
```
