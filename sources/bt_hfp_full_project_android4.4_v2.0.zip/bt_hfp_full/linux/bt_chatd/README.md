# bt_chatd (Linux daemon)

Build:
- `make`

Run:
- `/system/bin/bt_chatd --adapter hci0 --pcm-capture default --pcm-playback default`

Control socket:
- `/dev/socket/bt_chatd`

See also: `../../docs/SETUP.md` and `../../docs/USAGE.md`
