#include "bluez_agent.hpp"
#include "log.hpp"

static const char* AGENT_IFACE = "org.bluez.Agent1";

BluezAgent::BluezAgent(DBusConnection* conn, const std::string& path)
    : conn_(conn), path_(path) {}
BluezAgent::~BluezAgent() {}

bool BluezAgent::export_on_dbus() {
    if (!dbus_connection_add_filter(conn_, &BluezAgent::filter, this, nullptr)) {
        loge("dbus_connection_add_filter failed");
        return false;
    }
    logi("Agent exported at %s", path_.c_str());
    return true;
}

DBusHandlerResult BluezAgent::filter(DBusConnection* c, DBusMessage* m, void* user) {
    (void)c;
    return ((BluezAgent*)user)->handle(m);
}

DBusHandlerResult BluezAgent::handle(DBusMessage* m) {
    const char* path = dbus_message_get_path(m);
    const char* iface = dbus_message_get_interface(m);
    const char* member = dbus_message_get_member(m);

    if (!path || path_ != path) return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
    if (!iface || std::string(iface) != AGENT_IFACE) return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;
    if (!member) return DBUS_HANDLER_RESULT_NOT_YET_HANDLED;

    std::string method = member;
    logi("Agent1.%s called", method.c_str());

    if (method == "RequestPinCode") { reply_pin_code(m, "0000"); return DBUS_HANDLER_RESULT_HANDLED; }
    if (method == "RequestPasskey") { reply_passkey(m, 0); return DBUS_HANDLER_RESULT_HANDLED; }
    if (method == "RequestConfirmation") { reply_ok(m); return DBUS_HANDLER_RESULT_HANDLED; }
    if (method == "AuthorizeService") { reply_ok(m); return DBUS_HANDLER_RESULT_HANDLED; }
    if (method == "Release" || method == "Cancel") { reply_ok(m); return DBUS_HANDLER_RESULT_HANDLED; }

    // Default accept for headset compatibility.
    reply_ok(m);
    return DBUS_HANDLER_RESULT_HANDLED;
}

void BluezAgent::reply_ok(DBusMessage* m) {
    DBusMessage* r = dbus_message_new_method_return(m);
    dbus_connection_send(conn_, r, nullptr);
    dbus_message_unref(r);
}
void BluezAgent::reply_pin_code(DBusMessage* m, const std::string& pin) {
    DBusMessage* r = dbus_message_new_method_return(m);
    DBusMessageIter it; dbus_message_iter_init_append(r, &it);
    const char* p = pin.c_str();
    dbus_message_iter_append_basic(&it, DBUS_TYPE_STRING, &p);
    dbus_connection_send(conn_, r, nullptr);
    dbus_message_unref(r);
}
void BluezAgent::reply_passkey(DBusMessage* m, uint32_t passkey) {
    DBusMessage* r = dbus_message_new_method_return(m);
    DBusMessageIter it; dbus_message_iter_init_append(r, &it);
    dbus_uint32_t pk = passkey;
    dbus_message_iter_append_basic(&it, DBUS_TYPE_UINT32, &pk);
    dbus_connection_send(conn_, r, nullptr);
    dbus_message_unref(r);
}
