#pragma once
#include <string>
#include <algorithm>
#include <sstream>
#include <vector>
#include <cctype>

inline std::string trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && (s[a] == ' ' || s[a] == '\r' || s[a] == '\n' || s[a] == '\t')) a++;
    while (b > a && (s[b-1] == ' ' || s[b-1] == '\r' || s[b-1] == '\n' || s[b-1] == '\t')) b--;
    return s.substr(a, b-a);
}

inline std::vector<std::string> split_ws(const std::string& s) {
    std::istringstream iss(s);
    std::vector<std::string> out;
    std::string tok;
    while (iss >> tok) out.push_back(tok);
    return out;
}

inline std::string mac_to_bluez_path(const std::string& mac) {
    std::string m = mac;
    std::transform(m.begin(), m.end(), m.begin(), [](unsigned char c){
        if (c == ':') return (unsigned char)'_';
        return (unsigned char)std::toupper(c);
    });
    return std::string("dev_") + m;
}
