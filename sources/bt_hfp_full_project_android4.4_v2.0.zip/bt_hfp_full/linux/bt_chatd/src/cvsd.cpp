#include "cvsd.hpp"
#include <cstring>
#include <algorithm>

CvsdCodec::CvsdCodec() { reset(); }

void CvsdCodec::reset() {
    integrator_ = 0;
    step_ = 512;
    last_bit_ = 0;
}

void CvsdCodec::adapt(int bit) {
    if (bit == last_bit_) step_ = std::min(step_ + (step_ >> 3) + 8, 8192);
    else step_ = std::max(step_ - (step_ >> 4) - 4, 64);
    last_bit_ = bit;
}

size_t CvsdCodec::decode_cvsd_to_pcm16(const uint8_t* in_bits, size_t in_bytes,
                                       int16_t* out_pcm, size_t out_samples) {
    const size_t bits = in_bytes * 8;
    const size_t pcm_possible = bits / 8;
    const size_t pcm_write = std::min(out_samples, pcm_possible);

    size_t pcm_idx = 0;
    size_t bit_idx = 0;
    for (; pcm_idx < pcm_write; ++pcm_idx) {
        int32_t acc = 0;
        for (int k = 0; k < 8; ++k, ++bit_idx) {
            size_t byte_i = bit_idx / 8;
            int shift = 7 - (int)(bit_idx % 8);
            int bit = (in_bits[byte_i] >> shift) & 1;

            integrator_ += bit ? step_ : -step_;
            adapt(bit);
            acc += integrator_;
        }
        acc /= 8;
        acc = std::max(-32768, std::min(32767, acc));
        out_pcm[pcm_idx] = (int16_t)acc;
    }
    return pcm_write;
}

size_t CvsdCodec::encode_pcm16_to_cvsd(const int16_t* in_pcm, size_t in_samples,
                                       uint8_t* out_bits, size_t out_bytes) {
    const size_t bits_needed = in_samples * 8;
    const size_t bytes_needed = (bits_needed + 7) / 8;
    const size_t bytes_write = std::min(out_bytes, bytes_needed);

    std::memset(out_bits, 0, bytes_write);

    size_t bit_pos = 0;
    for (size_t i = 0; i < in_samples; ++i) {
        int32_t target = in_pcm[i];
        for (int k = 0; k < 8; ++k, ++bit_pos) {
            if ((bit_pos / 8) >= bytes_write) break;
            int bit = (integrator_ < target) ? 1 : 0;

            integrator_ += bit ? step_ : -step_;
            adapt(bit);

            size_t byte_i = bit_pos / 8;
            int shift = 7 - (int)(bit_pos % 8);
            if (bit) out_bits[byte_i] |= (uint8_t)(1u << shift);
        }
    }
    return bytes_write;
}
