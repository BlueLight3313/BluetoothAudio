#pragma once
#include <cstdint>
#include <cstddef>

/*
Very small CVSD codec implementation.
- Over the air, HFP uses CVSD (mandatory) or mSBC (optional).
- This demo bridges ALSA PCM <-> CVSD <-> SCO.
- It averages 8 bit-steps into 1 PCM sample to yield ~8kHz PCM.
*/

class CvsdCodec {
public:
    CvsdCodec();
    size_t decode_cvsd_to_pcm16(const uint8_t* in_bits, size_t in_bytes, int16_t* out_pcm, size_t out_samples);
    size_t encode_pcm16_to_cvsd(const int16_t* in_pcm, size_t in_samples, uint8_t* out_bits, size_t out_bytes);
    void reset();

private:
    int32_t integrator_;
    int32_t step_;
    int last_bit_;
    void adapt(int bit);
};
