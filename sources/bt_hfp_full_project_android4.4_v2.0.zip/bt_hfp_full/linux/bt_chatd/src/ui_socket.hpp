#pragma once
#include <string>
#include <functional>
#include <thread>

class UiSocketServer {
public:
    using Handler = std::function<std::string(const std::string& line)>;

    UiSocketServer(const std::string& path, Handler handler);
    ~UiSocketServer();

    bool start();
    void stop();

private:
    std::string sock_path_;
    Handler handler_;
    int listen_fd_ = -1;
    bool running_ = false;
    std::thread th_;

    void thread_main();
};
