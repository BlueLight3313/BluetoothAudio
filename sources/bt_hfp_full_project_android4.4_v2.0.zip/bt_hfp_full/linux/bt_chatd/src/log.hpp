#pragma once
#include <cstdio>
#include <cstdarg>
#include <ctime>

inline void log_ts_prefix(const char* level) {
    std::time_t t = std::time(nullptr);
    std::tm tmv;
    localtime_r(&t, &tmv);
    std::fprintf(stderr, "[%02d:%02d:%02d] %s: ", tmv.tm_hour, tmv.tm_min, tmv.tm_sec, level);
}

inline void logi(const char* fmt, ...) {
    log_ts_prefix("I");
    va_list ap; va_start(ap, fmt);
    std::vfprintf(stderr, fmt, ap);
    va_end(ap);
    std::fprintf(stderr, "\n");
}
inline void logw(const char* fmt, ...) {
    log_ts_prefix("W");
    va_list ap; va_start(ap, fmt);
    std::vfprintf(stderr, fmt, ap);
    va_end(ap);
    std::fprintf(stderr, "\n");
}
inline void loge(const char* fmt, ...) {
    log_ts_prefix("E");
    va_list ap; va_start(ap, fmt);
    std::vfprintf(stderr, fmt, ap);
    va_end(ap);
    std::fprintf(stderr, "\n");
}
