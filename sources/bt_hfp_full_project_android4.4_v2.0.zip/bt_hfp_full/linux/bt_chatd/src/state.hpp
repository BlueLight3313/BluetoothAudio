#pragma once
#include <string>
#include <mutex>

enum CallState {
    CALL_IDLE = 0,
    CALL_INCOMING,
    CALL_OUTGOING_DIALING,
    CALL_OUTGOING_ALERTING,
    CALL_ACTIVE
};

struct BtChatState {
    std::string adapter;
    std::string connected_mac;
    bool scanning = false;

    std::string my_number;
    std::string peer_number;

    CallState call_state = CALL_IDLE;

    int ind_service = 1;
    int ind_call = 0;
    int ind_callsetup = 0;
    int ind_callheld = 0;

    int spk_gain = 8;
    int mic_gain = 8;

    bool sco_open = false;
};

struct SharedState {
    std::mutex mu;
    BtChatState s;
};
