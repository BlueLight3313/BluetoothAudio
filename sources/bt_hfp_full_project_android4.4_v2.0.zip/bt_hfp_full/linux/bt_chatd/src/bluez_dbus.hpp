#pragma once
#include <dbus/dbus.h>
#include <string>
#include <functional>

class BluezDbus {
public:
    BluezDbus();
    ~BluezDbus();

    bool connect_system_bus();
    DBusConnection* conn() { return conn_; }

    bool adapter_set_powered(const std::string& adapter, bool on);
    bool adapter_start_discovery(const std::string& adapter);
    bool adapter_stop_discovery(const std::string& adapter);
    bool adapter_get_address(const std::string& adapter, std::string& out_mac);

    bool device_pair(const std::string& adapter, const std::string& mac);
    bool device_connect_profile(const std::string& adapter, const std::string& mac, const std::string& uuid);
    bool device_set_trusted(const std::string& adapter, const std::string& mac, bool trusted);

    bool register_agent(const std::string& agent_path, const std::string& capability);
    bool request_default_agent(const std::string& agent_path);

private:
    DBusConnection* conn_ = nullptr;

    bool set_property_bool(const std::string& bus, const std::string& path,
                           const std::string& iface, const std::string& prop, bool v);

    bool call_method(const std::string& bus, const std::string& path,
                     const std::string& iface, const std::string& method,
                     std::function<void(DBusMessageIter* args)> build_args);

    bool get_property_string(const std::string& bus, const std::string& path,
                             const std::string& iface, const std::string& prop, std::string& out);
};
