package com.example.btchatcontroller;

public class NativeBridge {
    static {
        System.loadLibrary("btchat_jni");
    }

    // Send a single command line (no trailing newline required).
    // Returns a single-line response (or error text).
    public static native String sendCommand(String cmd);
}
