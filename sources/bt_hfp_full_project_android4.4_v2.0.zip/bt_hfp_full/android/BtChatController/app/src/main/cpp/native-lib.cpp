#include <jni.h>
#include <string>
#include <android/log.h>

#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

#define LOG_TAG "BtChatJNI"
#define ALOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define ALOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)

// Control socket path created by bt_chatd
static const char* kSockPath = "/dev/socket/bt_chatd";

static std::string send_command_line(const std::string& cmd) {
    int fd = ::socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) {
        return std::string("ERR socket: ") + strerror(errno);
    }

    sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, kSockPath, sizeof(addr.sun_path)-1);

    if (::connect(fd, (sockaddr*)&addr, sizeof(addr)) < 0) {
        std::string err = std::string("ERR connect: ") + strerror(errno);
        ::close(fd);
        return err;
    }

    // bt_chatd sends a hello line. Read and ignore it.
    char hello[128];
    ::recv(fd, hello, sizeof(hello), MSG_DONTWAIT);

    std::string out = cmd;
    if (out.empty() || out.back() != '\n') out.push_back('\n');

    ssize_t wn = ::send(fd, out.c_str(), out.size(), 0);
    if (wn <= 0) {
        std::string err = std::string("ERR send: ") + strerror(errno);
        ::close(fd);
        return err;
    }

    // Read one line response
    std::string resp;
    char buf[256];
    while (true) {
        ssize_t rn = ::recv(fd, buf, sizeof(buf), 0);
        if (rn <= 0) break;
        resp.append(buf, buf + rn);
        size_t pos = resp.find('\n');
        if (pos != std::string::npos) {
            resp = resp.substr(0, pos);
            break;
        }
    }

    ::close(fd);

    if (resp.empty()) resp = "OK";
    return resp;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_btchatcontroller_NativeBridge_sendCommand(JNIEnv* env, jclass, jstring jcmd) {
    if (!jcmd) return env->NewStringUTF("ERR: null cmd");

    const char* c = env->GetStringUTFChars(jcmd, nullptr);
    std::string cmd = c ? c : "";
    env->ReleaseStringUTFChars(jcmd, c);

    std::string resp = send_command_line(cmd);
    return env->NewStringUTF(resp.c_str());
}
