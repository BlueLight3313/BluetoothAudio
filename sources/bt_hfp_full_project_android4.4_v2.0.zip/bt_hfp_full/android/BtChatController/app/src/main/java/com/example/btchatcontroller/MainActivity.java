package com.example.btchatcontroller;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {

    private TextView tvStatus;
    private TextView tvLog;
    private EditText etMac;
    private SeekBar sbSpk;
    private SeekBar sbMic;

    private Handler handler = new Handler();
    private Runnable statusPoll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = (TextView) findViewById(R.id.tvStatus);
        tvLog = (TextView) findViewById(R.id.tvLog);
        etMac = (EditText) findViewById(R.id.etMac);
        sbSpk = (SeekBar) findViewById(R.id.sbSpk);
        sbMic = (SeekBar) findViewById(R.id.sbMic);

        wireButton(R.id.btnStatus, "STATUS");
        wireButton(R.id.btnScanOn, "SCAN ON");
        wireButton(R.id.btnScanOff, "SCAN OFF");

        findViewById(R.id.btnPair).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { sendWithMac("PAIR "); }
        });
        findViewById(R.id.btnTrust).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { sendWithMac("TRUST "); }
        });
        findViewById(R.id.btnConnect).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { sendWithMac("CONNECT "); }
        });
        findViewById(R.id.btnDial).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { sendWithMac("DIAL "); }
        });

        wireButton(R.id.btnAnswer, "ANSWER");
        wireButton(R.id.btnReject, "REJECT");
        wireButton(R.id.btnHangup, "HANGUP");

        sbSpk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) appendLog(NativeBridge.sendCommand("SET_SPK " + progress));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        sbMic.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) appendLog(NativeBridge.sendCommand("SET_MIC " + progress));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        statusPoll = new Runnable() {
            @Override public void run() {
                String st = NativeBridge.sendCommand("STATUS");
                tvStatus.setText(st);
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(statusPoll);
    }

    private void wireButton(int id, final String cmd) {
        findViewById(id).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                appendLog(NativeBridge.sendCommand(cmd));
            }
        });
    }

    private void sendWithMac(String prefix) {
        String mac = etMac.getText().toString().trim();
        if (TextUtils.isEmpty(mac)) {
            appendLog("ERR: MAC is empty");
            return;
        }
        appendLog(NativeBridge.sendCommand(prefix + mac));
    }

    private void appendLog(String line) {
        if (line == null) line = "(null)";
        tvLog.setText(line + "\n" + tvLog.getText().toString());
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(statusPoll);
        super.onDestroy();
    }
}
