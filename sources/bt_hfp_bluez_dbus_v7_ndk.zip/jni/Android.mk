
LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := bt_chatd

LOCAL_SRC_FILES := ../src/main.c ../core/dbus_core.c ../modules/scan/scan.c ../modules/pair/pair.c ../modules/connect/connect.c ../modules/reconnect/reconnect.c ../profiles/hfp_ag/hfp_ag.c ../profiles/map_mse/map_mse.c ../audio/sco_bridge.c

LOCAL_C_INCLUDES := ../include ../core

LOCAL_LDLIBS := -ldbus-1 -lpthread

include $(BUILD_EXECUTABLE)
