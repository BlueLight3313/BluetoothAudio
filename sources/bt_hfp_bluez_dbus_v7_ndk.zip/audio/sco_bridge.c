
#include <stdio.h>

int sco_start()
{
    printf("Open SCO socket\n");
    return 0;
}

int sco_stop()
{
    printf("Close SCO socket\n");
    return 0;
}
