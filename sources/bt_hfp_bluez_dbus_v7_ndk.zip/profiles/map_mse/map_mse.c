
#include <stdio.h>

int map_server_start()
{
    printf("MAP Message Server start (OBEX)\n");
    return 0;
}

int map_send_message(const char* msg)
{
    printf("Send MAP message: %s\n",msg);
    return 0;
}
