
#include <stdio.h>

int hfp_register_profile()
{
    printf("Register HFP Audio Gateway profile (BlueZ ProfileManager1)\n");
    return 0;
}

int hfp_start_audio()
{
    printf("Start SCO audio bridge\n");
    return 0;
}

int hfp_stop_audio()
{
    printf("Stop SCO audio bridge\n");
    return 0;
}
