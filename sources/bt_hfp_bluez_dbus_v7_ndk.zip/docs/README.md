
Bluetooth Chat v7

Features
- Scan
- Pair
- Multi pair architecture
- Connect
- Auto reconnect
- HFP Audio Gateway
- MAP Message Server
- SCO audio bridge

Build (Android NDK)

cd jni
ndk-build

Binary:
libs/<abi>/bt_chatd
