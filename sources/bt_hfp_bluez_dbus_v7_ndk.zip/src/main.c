
#include <stdio.h>
#include "dbus_core.h"

extern int scan_start();
extern int pair_device(const char*);
extern int connect_device(const char*);
extern void reconnect_start(const char*);
extern int hfp_register_profile();
extern int map_server_start();

int main()
{
    printf("bt_chatd BlueZ DBus v7\n");

    if(dbus_core_init()!=0)
        return -1;

    hfp_register_profile();
    map_server_start();

    scan_start();

    dbus_core_loop();
    return 0;
}
