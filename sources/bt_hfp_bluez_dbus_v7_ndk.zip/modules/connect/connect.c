
#include "dbus_core.h"
#include <stdio.h>

int connect_device(const char* path)
{
    printf("Connect device %s\n",path);
    return dbus_method(path,"org.bluez.Device1","Connect");
}

int disconnect_device(const char* path)
{
    printf("Disconnect device %s\n",path);
    return dbus_method(path,"org.bluez.Device1","Disconnect");
}
