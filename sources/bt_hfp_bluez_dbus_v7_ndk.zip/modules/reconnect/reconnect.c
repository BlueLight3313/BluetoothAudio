
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include "connect.c"

static char dev[128];
static pthread_t th;

static void* loop(void* p)
{
    while(1)
    {
        printf("Reconnect attempt\n");
        connect_device(dev);
        sleep(5);
    }
}

void reconnect_start(const char* path)
{
    strcpy(dev,path);
    pthread_create(&th,NULL,loop,NULL);
}
