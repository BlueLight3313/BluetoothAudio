
#include "dbus_core.h"
#include <stdio.h>

int pair_device(const char* path)
{
    printf("Pair device %s\n",path);
    return dbus_method(path,"org.bluez.Device1","Pair");
}
