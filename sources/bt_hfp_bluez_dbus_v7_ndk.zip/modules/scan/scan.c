
#include "dbus_core.h"
#include <stdio.h>

int scan_start()
{
    printf("BlueZ StartDiscovery\n");
    return dbus_method("/org/bluez/hci0","org.bluez.Adapter1","StartDiscovery");
}

int scan_stop()
{
    printf("BlueZ StopDiscovery\n");
    return dbus_method("/org/bluez/hci0","org.bluez.Adapter1","StopDiscovery");
}
