#pragma once
#ifdef __cplusplus
extern "C" {
#endif

typedef struct hfp_ag hfp_ag_t;

hfp_ag_t* hfp_ag_start(int use_opensles);
void hfp_ag_stop(hfp_ag_t* a);
void hfp_ag_set_number(hfp_ag_t* a,const char* s);
int  hfp_ag_get_peer_mac(hfp_ag_t* a,char out[18]);

// DIAL triggers an incoming-call UI (RING/+CLIP) if RFCOMM is connected.
int  hfp_ag_dial(hfp_ag_t* a,const char* mac_str);
int  hfp_ag_hangup(hfp_ag_t* a);

// v3.6: runtime status for watchdog / UI.
int  hfp_ag_is_rfcomm_connected(hfp_ag_t* a);
void hfp_ag_set_state_ptr(void* app_state_ptr);

#ifdef __cplusplus
}
#endif
