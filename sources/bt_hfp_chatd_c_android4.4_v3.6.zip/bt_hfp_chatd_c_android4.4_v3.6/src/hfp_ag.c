#include "hfp_ag.h"
#include "rfcomm.h"
#include "bt_util.h"
#include "log.h"
#include "sco_bridge.h"
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <stdio.h>

#define RFCOMM_CH_DEFAULT 8

static void* g_state_ptr = NULL;

void hfp_ag_set_state_ptr(void* app_state_ptr){
  g_state_ptr = app_state_ptr;
}

static void state_set_rfcomm(int on){
  if(!g_state_ptr) return;
  struct minimal_state {
    int adapter_index;
    int mgmt_ready;
    int powered;
    int scanning;
    int auto_enabled;
    int has_target;
    bdaddr_t target;
    int connected;
    bdaddr_t connected_addr;
    int rfcomm_connected;
    int sco_running;
    char scan_results[512];
    char num[64];
  };
  struct minimal_state* st=(struct minimal_state*)g_state_ptr;
  st->rfcomm_connected = on;
}


typedef enum {
  CALL_IDLE = 0,
  CALL_INCOMING = 1,
  CALL_ACTIVE = 2,
  CALL_OUTGOING_DIALING = 3
} call_state_t;

struct hfp_ag{
  int listen_fd, cli_fd;
  pthread_t th;
  volatile int running;

  bdaddr_t peer;
  char peer_str[18];

  // caller-id display string
  char display[64];

  // call state/indicators
  call_state_t call_state;
  int ind_service;    // 0/1
  int ind_call;       // 0/1
  int ind_callsetup;  // 0..3
  int ind_callheld;   // 0..2

  int spk_gain; // 0..15 typical
  int mic_gain; // 0..15 typical

  sco_bridge_t* sco;
  int use_opensles;
};

static void send_raw(struct hfp_ag* a, const char* s){
  if(a->cli_fd<0) return;
  (void)write(a->cli_fd, s, strlen(s));
}
static void send_line(struct hfp_ag* a,const char* s){
  char buf[512];
  snprintf(buf,sizeof(buf),"%s\r\n",s);
  send_raw(a, buf);
}
static void send_ok(struct hfp_ag* a){ send_line(a,"OK"); }
static void send_error(struct hfp_ag* a){ send_line(a,"ERROR"); }

static void ind_ciev(struct hfp_ag* a, int ind, int val){
  // indicator index mapping is up to AG; we use:
  // 1=service 2=call 3=callsetup 4=callheld
  char l[64];
  snprintf(l,sizeof(l),"+CIEV: %d,%d", ind, val);
  send_line(a, l);
}

static void update_indicators(struct hfp_ag* a){
  // Push current indicator states (optional). Many headsets accept periodic CIEV.
  ind_ciev(a, 1, a->ind_service);
  ind_ciev(a, 2, a->ind_call);
  ind_ciev(a, 3, a->ind_callsetup);
  ind_ciev(a, 4, a->ind_callheld);
}

static void set_incoming_call(struct hfp_ag* a){
  a->call_state = CALL_INCOMING;
  a->ind_service = 1;
  a->ind_call = 0;
  a->ind_callsetup = 1; // incoming
  a->ind_callheld = 0;

  // Ring + caller id
  send_line(a,"RING");
  const char* num=a->display[0]?a->display:a->peer_str;
  char clip[256];
  snprintf(clip,sizeof(clip),"+CLIP: \"%s\",129", num);
  send_line(a, clip);

  // Notify indicators
  update_indicators(a);
}

static void set_outgoing_dialing(struct hfp_ag* a){
  a->call_state = CALL_OUTGOING_DIALING;
  a->ind_service = 1;
  a->ind_call = 0;
  a->ind_callsetup = 2; // outgoing dialing
  a->ind_callheld = 0;
  update_indicators(a);
}

static void set_call_active(struct hfp_ag* a){
  a->call_state = CALL_ACTIVE;
  a->ind_service = 1;
  a->ind_call = 1;
  a->ind_callsetup = 0;
  a->ind_callheld = 0;
  update_indicators(a);
}

static void set_call_idle(struct hfp_ag* a){
  a->call_state = CALL_IDLE;
  a->ind_call = 0;
  a->ind_callsetup = 0;
  a->ind_callheld = 0;
  update_indicators(a);
}

static void start_sco_if_needed(struct hfp_ag* a){
  if(!a->sco){
    a->sco = sco_bridge_start(&a->peer, a->use_opensles);
  }
}

static void stop_sco(struct hfp_ag* a){
  if(a->sco){
    sco_bridge_stop(a->sco);
    a->sco=NULL;
  }
}

static void handle_at_line(struct hfp_ag* a, const char* line){
  // Basic AT negotiation
  if(strcmp(line,"AT")==0){ send_ok(a); return; }
  if(strncmp(line,"AT+BRSF=",8)==0){ send_line(a,"+BRSF: 0"); send_ok(a); return; }

  if(strcmp(line,"AT+CIND=?")==0){
    // Ind list: service, call, callsetup, callheld
    send_line(a,"+CIND: (\"service\",(0,1)),(\"call\",(0,1)),(\"callsetup\",(0-3)),(\"callheld\",(0-2))");
    send_ok(a); return;
  }
  if(strcmp(line,"AT+CIND?")==0){
    char l[64];
    snprintf(l,sizeof(l),"+CIND: %d,%d,%d,%d", a->ind_service,a->ind_call,a->ind_callsetup,a->ind_callheld);
    send_line(a,l);
    send_ok(a); return;
  }
  if(strncmp(line,"AT+CMER=",8)==0){
    // enable indicator event reporting
    send_ok(a);
    // Push current state once
    update_indicators(a);
    return;
  }

  // Codec negotiation (we stay CVSD)
  if(strncmp(line,"AT+BAC=",7)==0){ send_ok(a); send_line(a,"AT+BCS=1"); return; }
  if(strncmp(line,"AT+BCS=",7)==0){ send_ok(a); return; }

  // Volume controls
  if(strncmp(line,"AT+VGS=",7)==0){
    a->spk_gain = atoi(line+7);
    send_ok(a);
    return;
  }
  if(strncmp(line,"AT+VGM=",7)==0){
    a->mic_gain = atoi(line+7);
    send_ok(a);
    return;
  }

  // List current calls: minimal support so headsets don't get stuck
  if(strcmp(line,"AT+CLCC")==0){
    // If active/incoming/outgoing, return one entry, else nothing.
    // Format: +CLCC: <idx>,<dir>,<stat>,<mode>,<mpty>[,<number>,<type>]
    if(a->call_state == CALL_ACTIVE){
      send_line(a, "+CLCC: 1,0,0,0,0");
    } else if(a->call_state == CALL_INCOMING){
      send_line(a, "+CLCC: 1,1,4,0,0");
    } else if(a->call_state == CALL_OUTGOING_DIALING){
      send_line(a, "+CLCC: 1,0,2,0,0");
    }
    send_ok(a);
    return;
  }

  // Answer
  if(strcmp(line,"ATA")==0){
    // Accept incoming or complete outgoing into active
    send_ok(a);
    set_call_active(a);
    start_sco_if_needed(a);
    return;
  }

  // Hang up
  if(strcmp(line,"AT+CHUP")==0){
    send_ok(a);
    stop_sco(a);
    set_call_idle(a);
    return;
  }

  // Outgoing dial from headset
  if(strncmp(line,"ATD",3)==0){
    // Example ATD123; or ATD>...
    send_ok(a);
    set_outgoing_dialing(a);
    // For "chat" mode, we can immediately transition to active and open SCO,
    // or wait for headset to send ATA. Many headsets expect active only after "call connected".
    // We'll send CIEV transitions to active after a short delay is handled by the user action.
    // Here: immediately set active and start SCO for best chance of audio chat.
    set_call_active(a);
    start_sco_if_needed(a);
    return;
  }

  // Reject/hold features (ack OK, but no real implementation)
  if(strncmp(line,"AT+CHLD=",8)==0){ send_ok(a); return; }

  // Default: OK (keeps many headsets happy)
  send_ok(a);
}

static void* th_main(void* p){
  struct hfp_ag* a=(struct hfp_ag*)p;

  while(a->running){
    struct sockaddr_rc rem;
    socklen_t len=sizeof(rem);
    int fd=accept(a->listen_fd,(struct sockaddr*)&rem,&len);
    if(fd<0) continue;

    a->cli_fd=fd;
    a->peer=rem.rc_bdaddr;
    bt_format_mac(&a->peer,a->peer_str);

    LOGI("RFCOMM connected %s", a->peer_str);
    state_set_rfcomm(1);

    // When HFP connects, service becomes available
    a->ind_service = 1;
    update_indicators(a);

    char buf[1024];
    size_t used=0;

    while(a->running){
      ssize_t n=read(fd, buf+used, sizeof(buf)-1-used);
      if(n<=0) break;
      used+=(size_t)n;
      buf[used]=0;

      char* cr;
      while((cr=strchr(buf,'\r'))){
        *cr=0;
        char line[256];
        snprintf(line,sizeof(line),"%s",buf);

        size_t remn=used-((cr-buf)+1);
        memmove(buf, cr+1, remn);
        used=remn;
        buf[used]=0;

        // Trim spaces
        size_t L=strlen(line);
        while(L && (line[L-1]=='\n' || line[L-1]==' ' || line[L-1]=='\t')) line[--L]=0;

        if(line[0]==0) continue;
        LOGI("HF->AG: %s", line);
        handle_at_line(a, line);
      }
    }

    LOGI("RFCOMM disconnected");
    state_set_rfcomm(0);
    close(fd);
    a->cli_fd=-1;
    stop_sco(a);
    set_call_idle(a);
  }
  return 0;
}

hfp_ag_t* hfp_ag_start(int use_opensles){
  struct hfp_ag* a=(struct hfp_ag*)calloc(1,sizeof(*a));
  a->use_opensles = use_opensles;

  a->listen_fd=socket(AF_BLUETOOTH,SOCK_STREAM,BTPROTO_RFCOMM);
  if(a->listen_fd<0){ free(a); return NULL; }

  struct sockaddr_rc loc;
  memset(&loc,0,sizeof(loc));
  loc.rc_family=AF_BLUETOOTH;
  bt_bdaddr_any(&loc.rc_bdaddr);
  loc.rc_channel=RFCOMM_CH_DEFAULT;

  if(bind(a->listen_fd,(struct sockaddr*)&loc,sizeof(loc))<0){ close(a->listen_fd); free(a); return NULL; }
  if(listen(a->listen_fd,1)<0){ close(a->listen_fd); free(a); return NULL; }

  a->cli_fd=-1;
  a->running=1;
  a->display[0]=0;
  a->peer_str[0]=0;

  // initial indicators
  a->ind_service=0;
  a->ind_call=0;
  a->ind_callsetup=0;
  a->ind_callheld=0;
  a->spk_gain=10;
  a->mic_gain=10;

  pthread_create(&a->th,0,th_main,a);
  LOGI("HFP AG started ch %d", RFCOMM_CH_DEFAULT);
  return (hfp_ag_t*)a;
}

void hfp_ag_stop(hfp_ag_t* a0){
  struct hfp_ag* a=(struct hfp_ag*)a0;
  if(!a) return;
  a->running=0;
  shutdown(a->listen_fd,SHUT_RDWR);
  pthread_join(a->th,0);
  close(a->listen_fd);
  if(a->cli_fd>=0) close(a->cli_fd);
  stop_sco(a);
  free(a);
}

void hfp_ag_set_number(hfp_ag_t* a0,const char* s){
  struct hfp_ag* a=(struct hfp_ag*)a0;
  if(!a) return;
  if(!s) s="";
  snprintf(a->display,sizeof(a->display),"%s",s);
}

int hfp_ag_get_peer_mac(hfp_ag_t* a0,char out[18]){
  struct hfp_ag* a=(struct hfp_ag*)a0;
  if(!a||!out) return -1;
  snprintf(out,18,"%s",a->peer_str);
  return 0;
}

int hfp_ag_dial(hfp_ag_t* a0,const char* mac_str){
  struct hfp_ag* a=(struct hfp_ag*)a0;
  if(!a||!mac_str) return -1;
  bdaddr_t b;
  if(bt_parse_mac(mac_str,&b)<0) return -1;
  a->peer=b;
  bt_format_mac(&a->peer,a->peer_str);

  // If RFCOMM connected, generate an incoming call UI on headset.
  if(a->cli_fd>=0){
    set_incoming_call(a);
    return 0;
  }

  // If RFCOMM is not connected yet, we still try to start SCO directly (some stacks allow),
  // but many headsets will not accept SCO without HFP. Return OK for now.
  return 0;
}

int hfp_ag_hangup(hfp_ag_t* a0){
  struct hfp_ag* a=(struct hfp_ag*)a0;
  if(!a) return -1;
  stop_sco(a);
  set_call_idle(a);
  if(a->cli_fd>=0){
    // Some headsets accept explicit CHUP unsolicited, but keep minimal.
    // send_line(a, "NO CARRIER"); // optional
  }
  return 0;
}


int hfp_ag_is_rfcomm_connected(hfp_ag_t* a0){
  struct hfp_ag* a=(struct hfp_ag*)a0;
  if(!a) return 0;
  return (a->cli_fd>=0) ? 1 : 0;
}
