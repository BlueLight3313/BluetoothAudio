#include "sdp_server.h"
#include "l2cap.h"
#include "bt_util.h"
#include "log.h"

#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define SDP_PSM 0x0001

// SDP PDU IDs
#define SDP_PDU_SERVICE_SEARCH_REQ            0x02
#define SDP_PDU_SERVICE_SEARCH_RSP            0x03
#define SDP_PDU_SERVICE_ATTRIBUTE_REQ         0x04
#define SDP_PDU_SERVICE_ATTRIBUTE_RSP         0x05
#define SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_REQ  0x06
#define SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_RSP  0x07

struct sdp_server {
    int fd;
    int rfcomm_ch;
    pthread_t th;
    volatile int running;
};

static void be16_put(unsigned char* p, unsigned short v){ p[0]=(unsigned char)(v>>8); p[1]=(unsigned char)(v&0xFF); }
static unsigned short be16_get(const unsigned char* p){ return (unsigned short)((p[0]<<8)|p[1]); }

static int build_hfp_ag_attr_list(unsigned char* out, int cap, int rfcomm_ch){
    unsigned char tmp[512];
    unsigned char* t=tmp;

    // 0x0000 ServiceRecordHandle = 0x00010001
    *t++=0x09; *t++=0x00; *t++=0x00;
    *t++=0x0A; *t++=0x00; *t++=0x01; *t++=0x00; *t++=0x01;

    // 0x0001 ServiceClassIDList = seq(uuid16 0x111F)
    *t++=0x09; *t++=0x00; *t++=0x01;
    *t++=0x35; *t++=0x03;
    *t++=0x19; *t++=0x11; *t++=0x1F;

    // 0x0004 ProtocolDescriptorList = seq( L2CAP(PSM 0x0003), RFCOMM(ch) )
    *t++=0x09; *t++=0x00; *t++=0x04;
    *t++=0x35; *t++=0x11;
      *t++=0x35; *t++=0x06;
        *t++=0x19; *t++=0x01; *t++=0x00;
        *t++=0x09; *t++=0x00; *t++=0x03;
      *t++=0x35; *t++=0x05;
        *t++=0x19; *t++=0x00; *t++=0x03;
        *t++=0x08; *t++=(unsigned char)(rfcomm_ch & 0xFF);

    // 0x0005 BrowseGroupList = seq(uuid16 0x1002)
    *t++=0x09; *t++=0x00; *t++=0x05;
    *t++=0x35; *t++=0x03;
    *t++=0x19; *t++=0x10; *t++=0x02;

    // 0x0006 LanguageBaseAttributeIDList
    *t++=0x09; *t++=0x00; *t++=0x06;
    *t++=0x35; *t++=0x09;
    *t++=0x09; *t++=0x65; *t++=0x6E;
    *t++=0x09; *t++=0x00; *t++=0x6A;
    *t++=0x09; *t++=0x01; *t++=0x00;

    // 0x0009 BluetoothProfileDescriptorList = seq(seq(uuid16 0x111E, uint16 0x0107))
    *t++=0x09; *t++=0x00; *t++=0x09;
    *t++=0x35; *t++=0x0A;
      *t++=0x35; *t++=0x08;
        *t++=0x19; *t++=0x11; *t++=0x1E;
        *t++=0x09; *t++=0x01; *t++=0x07;

    // 0x0100 ServiceName = "HFP AG"
    *t++=0x09; *t++=0x01; *t++=0x00;
    *t++=0x25; *t++=0x06;
    *t++='H'; *t++='F'; *t++='P'; *t++=' '; *t++='A'; *t++='G';

    // 0x0311 SupportedFeatures = uint16 0x0001
    *t++=0x09; *t++=0x03; *t++=0x11;
    *t++=0x09; *t++=0x00; *t++=0x01;

    int attr_bytes=(int)(t - tmp);
    if(attr_bytes <=0 || attr_bytes > cap-2) return -1;

    out[0]=0x35;
    out[1]=(unsigned char)(attr_bytes & 0xFF);
    memcpy(out+2, tmp, (size_t)attr_bytes);
    return 2 + attr_bytes;
}

// Continuation token: 1 byte offset (0..255), 0 means no continuation.
static void sdp_send_search_rsp(int cfd, unsigned short tid, unsigned short max_handles, unsigned char cont_in){
    (void)max_handles;

    // We only have one record handle 0x00010001
    unsigned int handle = 0x00010001;

    // Continuation for search result: if cont_in != 0, send no more.
    unsigned short count = (cont_in==0) ? 1 : 0;
    unsigned short total = 1;

    unsigned char rsp[64];
    unsigned char* q=rsp;
    *q++ = SDP_PDU_SERVICE_SEARCH_RSP;
    be16_put(q, tid); q+=2;
    unsigned char* plen_ptr=q; q+=2;

    be16_put(q, total); q+=2; // TotalServiceRecordCount
    be16_put(q, count); q+=2; // CurrentServiceRecordCount
    if(count==1){
        *q++ = (unsigned char)((handle>>24)&0xFF);
        *q++ = (unsigned char)((handle>>16)&0xFF);
        *q++ = (unsigned char)((handle>>8)&0xFF);
        *q++ = (unsigned char)(handle&0xFF);
    }

    // ContinuationState
    if(cont_in==0){
        *q++ = 0x00; // no continuation
    } else {
        *q++ = 0x00;
    }

    unsigned short plen=(unsigned short)(q-(plen_ptr+2));
    be16_put(plen_ptr, plen);
    (void)send(cfd, rsp, (size_t)(q-rsp), 0);
}

static void sdp_send_attr_rsp(int cfd, unsigned short tid, const unsigned char* attr_list, int attr_len,
                              unsigned short max_attr_bytes, unsigned char cont_token){
    int offset=(int)cont_token;
    if(offset<0) offset=0;
    if(offset>attr_len) offset=attr_len;

    int remaining=attr_len-offset;
    int send_bytes=remaining;
    if(send_bytes>(int)max_attr_bytes) send_bytes=(int)max_attr_bytes;

    unsigned char next_token=0;
    if(offset+send_bytes < attr_len) next_token=(unsigned char)(offset+send_bytes);

    unsigned char rsp[1024];
    unsigned char* q=rsp;
    *q++ = (attr_list[0] ? 0 : 0); // dummy to avoid warnings
    // caller sets PDU later
    (void)q;
    // not used here
    (void)cfd; (void)tid; (void)attr_list; (void)attr_len; (void)max_attr_bytes; (void)cont_token; (void)next_token; (void)send_bytes;
}

// Common response builder for attribute-based PDUs.
static void send_attr_pdu(int cfd, unsigned char pdu, unsigned short tid,
                          const unsigned char* attr_list, int attr_len,
                          unsigned short max_attr_bytes, unsigned char cont_token){
    int offset=(int)cont_token;
    if(offset<0) offset=0;
    if(offset>attr_len) offset=attr_len;

    int remaining=attr_len-offset;
    int send_bytes=remaining;
    if(send_bytes>(int)max_attr_bytes) send_bytes=(int)max_attr_bytes;

    unsigned char next_token=0;
    if(offset+send_bytes < attr_len) next_token=(unsigned char)(offset+send_bytes);

    unsigned char rsp[1024];
    unsigned char* q=rsp;
    *q++ = pdu;
    be16_put(q, tid); q+=2;
    unsigned char* plen_ptr=q; q+=2;

    // AttributeListByteCount = total attr_len
    be16_put(q, (unsigned short)attr_len); q+=2;

    memcpy(q, attr_list+offset, (size_t)send_bytes); q+=send_bytes;

    if(next_token!=0){
        *q++=0x01;
        *q++=next_token;
    } else {
        *q++=0x00;
    }

    unsigned short plen=(unsigned short)(q-(plen_ptr+2));
    be16_put(plen_ptr, plen);
    (void)send(cfd, rsp, (size_t)(q-rsp), 0);
}

static int skip_de(const unsigned char** pp, const unsigned char* end){
    const unsigned char* p=*pp;
    if(p>=end) return -1;
    unsigned char d=*p++;
    unsigned int size_idx = d & 0x07;
    if((d & 0xF8) == 0x30){ // seq
        unsigned int len=0;
        if(size_idx==5){
            if(p>=end) return -1;
            len=*p++;
        } else if(size_idx==6){
            if(p+2>end) return -1;
            len=be16_get(p); p+=2;
        } else {
            return -1;
        }
        if(p+len > end) return -1;
        p += len;
        *pp=p;
        return 0;
    }
    // allow uint16/uint32/uint8/string with 1-byte length
    if(d==0x09){ // uint16
        if(p+2>end) return -1;
        p+=2;
        *pp=p; return 0;
    }
    if(d==0x0A){ // uint32
        if(p+4>end) return -1;
        p+=4;
        *pp=p; return 0;
    }
    if(d==0x08){ // uint8
        if(p+1>end) return -1;
        p+=1;
        *pp=p; return 0;
    }
    if((d & 0xF8)==0x20){ // string
        if(size_idx==5){
            if(p>=end) return -1;
            unsigned int len=*p++;
            if(p+len>end) return -1;
            p+=len;
            *pp=p; return 0;
        }
    }
    return -1;
}

static void* th_main(void* arg){
    struct sdp_server* s=(struct sdp_server*)arg;

    unsigned char attr_list[512];
    int attr_len = build_hfp_ag_attr_list(attr_list, (int)sizeof(attr_list), s->rfcomm_ch);
    if(attr_len < 0) attr_len = 0;

    while(s->running){
        int cfd=accept(s->fd, NULL, NULL);
        if(cfd<0){
            if(errno==EINTR) continue;
            usleep(50*1000);
            continue;
        }

        unsigned char req[1024];
        ssize_t n=recv(cfd, req, sizeof(req), 0);
        if(n < 5){ close(cfd); continue; }

        unsigned char pdu_id=req[0];
        unsigned short tid=be16_get(req+1);
        unsigned short plen=be16_get(req+3);
        if((int)plen + 5 > (int)n) { close(cfd); continue; }

        const unsigned char* p = req + 5;
        const unsigned char* end = req + 5 + plen;

        if(pdu_id == SDP_PDU_SERVICE_SEARCH_REQ){
            // ServiceSearchPattern (DE seq) + MaxRecordCount(uint16) + Continuation
            if(skip_de(&p,end)<0){ close(cfd); continue; }
            if(p+2>end){ close(cfd); continue; }
            unsigned short max_rc = be16_get(p); p+=2;
            unsigned char cont_len=0, cont_token=0;
            if(p<end){
                cont_len=*p++;
                if(cont_len==1 && p<end) cont_token=*p++;
            }
            sdp_send_search_rsp(cfd, tid, max_rc, cont_token);
            close(cfd);
            continue;
        }

        if(pdu_id == SDP_PDU_SERVICE_ATTRIBUTE_REQ){
            // ServiceRecordHandle(uint32) + MaxAttributeByteCount(uint16) + AttributeIDList(DE seq) + Continuation
            if(p+4>end){ close(cfd); continue; }
            p+=4; // ignore handle
            if(p+2>end){ close(cfd); continue; }
            unsigned short max_attr_bytes = be16_get(p); p+=2;
            if(skip_de(&p,end)<0){ close(cfd); continue; }
            unsigned char cont_len=0, cont_token=0;
            if(p<end){
                cont_len=*p++;
                if(cont_len==1 && p<end) cont_token=*p++;
            }
            if(attr_len>0){
                send_attr_pdu(cfd, SDP_PDU_SERVICE_ATTRIBUTE_RSP, tid, attr_list, attr_len, max_attr_bytes, cont_token);
            }
            close(cfd);
            continue;
        }

        if(pdu_id == SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_REQ){
            // ServiceSearchPattern(DE) + MaxAttrBytes(uint16) + AttributeIDList(DE) + Continuation
            if(skip_de(&p,end)<0){ close(cfd); continue; }
            if(p+2>end){ close(cfd); continue; }
            unsigned short max_attr_bytes = be16_get(p); p+=2;
            if(skip_de(&p,end)<0){ close(cfd); continue; }

            unsigned char cont_len=0, cont_token=0;
            if(p<end){
                cont_len=*p++;
                if(cont_len==1 && p<end) cont_token=*p++;
            }

            if(attr_len>0){
                send_attr_pdu(cfd, SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_RSP, tid, attr_list, attr_len, max_attr_bytes, cont_token);
            }
            close(cfd);
            continue;
        }

        // unsupported PDU
        close(cfd);
    }
    return NULL;
}

sdp_server_t* sdp_server_start(int rfcomm_channel){
    struct sdp_server* s=(struct sdp_server*)calloc(1,sizeof(*s));
    s->rfcomm_ch = rfcomm_channel;

    s->fd = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP);
    if(s->fd < 0){
        LOGE("SDP socket failed: %s", strerror(errno));
        free(s);
        return NULL;
    }

    struct sockaddr_l2 addr;
    memset(&addr,0,sizeof(addr));
    addr.l2_family = AF_BLUETOOTH;
    addr.l2_psm = htons(SDP_PSM);
    bt_bdaddr_any(&addr.l2_bdaddr);

    if(bind(s->fd, (struct sockaddr*)&addr, sizeof(addr))<0){
        LOGE("SDP bind failed: %s", strerror(errno));
        close(s->fd); free(s);
        return NULL;
    }
    if(listen(s->fd, 5)<0){
        LOGE("SDP listen failed: %s", strerror(errno));
        close(s->fd); free(s);
        return NULL;
    }

    s->running=1;
    pthread_create(&s->th, NULL, th_main, s);
    LOGI("SDP server started (HFP AG UUID 0x111F, RFCOMM ch=%d)", rfcomm_channel);
    return (sdp_server_t*)s;
}

void sdp_server_stop(sdp_server_t* s0){
    struct sdp_server* s=(struct sdp_server*)s0;
    if(!s) return;
    s->running=0;
    shutdown(s->fd, SHUT_RDWR);
    pthread_join(s->th, NULL);
    close(s->fd);
    free(s);
}
