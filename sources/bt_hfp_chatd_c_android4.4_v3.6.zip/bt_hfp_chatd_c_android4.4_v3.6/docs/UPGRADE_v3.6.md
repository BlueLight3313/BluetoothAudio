# Upgrade v3.6: RFCOMM watchdog + broader SDP compatibility

## 1) RFCOMM watchdog (for "any headset" reliability)
Problem: some headsets pair/connect BR/EDR but never open RFCOMM/HFP, so SCO cannot start.
Fix: state machine now tracks how long `rfcomm_connected=0` while `connected=1`.
- After 10 seconds without RFCOMM, it triggers a reconnect (DISCONNECT+CONNECT) to recover.
- HFP layer updates `rfcomm_connected` in shared state.

Files:
- src/state_machine.c
- src/hfp_ag.c / src/hfp_ag.h
- src/main.c (wires state pointer)

## 2) SDP improvements
Added support for additional SDP client behaviors:
- ServiceSearchRequest (PDU 0x02) -> returns one record handle
- ServiceAttributeRequest (PDU 0x04) -> returns same attribute list as search-attribute
- ContinuationState token remains supported for attribute responses.

File:
- src/sdp_server.c

## Why this helps chat mode
Even for "Bluetooth-only chat", headsets typically require HFP RFCOMM + a call-like state before opening SCO.
This upgrade makes it more likely RFCOMM is established automatically.
