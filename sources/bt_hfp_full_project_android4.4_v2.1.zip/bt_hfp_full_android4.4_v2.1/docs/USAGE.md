# Usage (Android 4.4)

Control socket: `/dev/socket/bt_chatd`

Commands:
- STATUS
- SCAN ON|OFF
- PAIR <MAC>
- TRUST <MAC>
- CONNECT <MAC>
- DIAL <MAC>
- ANSWER / REJECT / HANGUP
- SET_SPK 0..15 / SET_MIC 0..15
- SET_NUMBER <string>   (v2.1)

Example:
```sh
echo "SET_NUMBER 9001234567" | nc -U /dev/socket/bt_chatd
echo "CONNECT 01:23:45:67:89:AB" | nc -U /dev/socket/bt_chatd
echo "DIAL 01:23:45:67:89:AB" | nc -U /dev/socket/bt_chatd
```

When a headset indicates an incoming call (ATD...), bt_chatd sends:
- RING
- +CLIP: "<your SET_NUMBER>",129
