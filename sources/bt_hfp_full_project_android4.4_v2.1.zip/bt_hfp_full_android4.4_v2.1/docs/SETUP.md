# Setup (Android 4.4)

1) Stop Android BT stack so BlueZ owns the controller
2) Start `bluetoothd`
3) Build and run `bt_chatd` (creates `/dev/socket/bt_chatd`)
4) Install app to `/system/app/BtChatController/BtChatController.apk`

Quick commands:
```sh
stop bluetooth
modprobe btusb; modprobe bluetooth; modprobe rfcomm; modprobe sco
hciconfig hci0 up
bluetoothd -n -d &
/system/bin/bt_chatd --adapter hci0 --pcm-capture default --pcm-playback default
```
