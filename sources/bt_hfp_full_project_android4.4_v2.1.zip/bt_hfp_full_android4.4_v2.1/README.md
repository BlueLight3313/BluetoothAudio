# Android 4.4 full project v2.1 (Linux daemon + Android system app)

New in v2.1:
- `SET_NUMBER <string>`: store a special string and send it to the headset using HFP caller ID (`+CLIP`) when an incoming call is indicated.

Contents:
- linux/bt_chatd : BlueZ + ALSA + HFP AG + SCO(CVSD) daemon, control via UNIX socket `/dev/socket/bt_chatd`
- android/BtChatController : Android 4.4 system app + JNI AF_UNIX client

Docs: docs/SETUP.md, docs/USAGE.md
