#include "ui_socket.hpp"
#include "log.hpp"
#include "util.hpp"
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cstring>
#include <cerrno>

UiSocketServer::UiSocketServer(const std::string& path, Handler handler) : sock_path_(path), handler_(handler) {}
UiSocketServer::~UiSocketServer(){ stop(); }

bool UiSocketServer::start(){
    stop();
    listen_fd_ = ::socket(AF_UNIX, SOCK_STREAM, 0);
    if(listen_fd_<0){ loge("socket(AF_UNIX) failed"); return false; }
    ::unlink(sock_path_.c_str());

    sockaddr_un addr{}; addr.sun_family=AF_UNIX;
    std::snprintf(addr.sun_path, sizeof(addr.sun_path), "%s", sock_path_.c_str());
    if(::bind(listen_fd_, (sockaddr*)&addr, sizeof(addr))<0){
        loge("bind(%s) failed: %s", sock_path_.c_str(), std::strerror(errno));
        ::close(listen_fd_); listen_fd_=-1; return false;
    }

    ::chmod(sock_path_.c_str(), 0660);
    ::chown(sock_path_.c_str(), 0, 1000); // system gid usually 1000

    if(::listen(listen_fd_,5)<0){
        loge("listen failed: %s", std::strerror(errno));
        ::close(listen_fd_); listen_fd_=-1; return false;
    }
    running_=true;
    th_=std::thread(&UiSocketServer::thread_main, this);
    logi("Control socket listening at %s", sock_path_.c_str());
    return true;
}

void UiSocketServer::stop(){
    running_=false;
    if(listen_fd_>=0){ ::shutdown(listen_fd_, SHUT_RDWR); ::close(listen_fd_); listen_fd_=-1; }
    if(th_.joinable()) th_.join();
    ::unlink(sock_path_.c_str());
}

void UiSocketServer::thread_main(){
    while(running_){
        int cfd = ::accept(listen_fd_, nullptr, nullptr);
        if(cfd<0){ if(running_) logw("accept failed"); continue; }
        const char* hello="bt_chatd ready\n";
        ::write(cfd, hello, std::strlen(hello));

        char buf[1024]; std::string partial;
        while(running_){
            ssize_t n=::read(cfd, buf, sizeof(buf));
            if(n<=0) break;
            partial.append(buf, buf+n);
            size_t pos;
            while((pos=partial.find('\n'))!=std::string::npos){
                std::string line=trim(partial.substr(0,pos));
                partial.erase(0,pos+1);
                if(line.empty()) continue;
                std::string resp=handler_(line);
                if(resp.empty()) resp="OK";
                resp.push_back('\n');
                ::write(cfd, resp.c_str(), resp.size());
            }
        }
        ::close(cfd);
    }
}
