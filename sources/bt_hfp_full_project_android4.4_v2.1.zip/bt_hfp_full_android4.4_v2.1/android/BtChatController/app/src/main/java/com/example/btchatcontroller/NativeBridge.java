package com.example.btchatcontroller;
public class NativeBridge {
  static { System.loadLibrary("btchat_jni"); }
  public static native String sendCommand(String cmd);
}
