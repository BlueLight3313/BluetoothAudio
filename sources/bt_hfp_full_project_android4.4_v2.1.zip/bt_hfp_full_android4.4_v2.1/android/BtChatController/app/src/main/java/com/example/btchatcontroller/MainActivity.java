package com.example.btchatcontroller;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
  private TextView tvStatus, tvLog;
  private EditText etMac, etNumber;
  private SeekBar sbSpk, sbMic;
  private Handler handler = new Handler();
  private Runnable statusPoll;

  @Override protected void onCreate(Bundle savedInstanceState){
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    tvStatus = (TextView)findViewById(R.id.tvStatus);
    tvLog = (TextView)findViewById(R.id.tvLog);
    etMac = (EditText)findViewById(R.id.etMac);
    etNumber = (EditText)findViewById(R.id.etNumber);
    sbSpk = (SeekBar)findViewById(R.id.sbSpk);
    sbMic = (SeekBar)findViewById(R.id.sbMic);

    wire(R.id.btnStatus, "STATUS");
    wire(R.id.btnScanOn, "SCAN ON");
    wire(R.id.btnScanOff, "SCAN OFF");
    wireMac(R.id.btnPair, "PAIR ");
    wireMac(R.id.btnTrust, "TRUST ");
    wireMac(R.id.btnConnect, "CONNECT ");
    wireMac(R.id.btnDial, "DIAL ");
    wire(R.id.btnAnswer, "ANSWER");
    wire(R.id.btnReject, "REJECT");
    wire(R.id.btnHangup, "HANGUP");

    findViewById(R.id.btnSetNumber).setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        String num = etNumber.getText().toString().trim();
        if (TextUtils.isEmpty(num)) { append("ERR: number empty"); return; }
        append(NativeBridge.sendCommand("SET_NUMBER " + num));
      }
    });

    sbSpk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      @Override public void onProgressChanged(SeekBar sb,int p,boolean fromUser){ if(fromUser) append(NativeBridge.sendCommand("SET_SPK "+p)); }
      @Override public void onStartTrackingTouch(SeekBar sb){}
      @Override public void onStopTrackingTouch(SeekBar sb){}
    });
    sbMic.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      @Override public void onProgressChanged(SeekBar sb,int p,boolean fromUser){ if(fromUser) append(NativeBridge.sendCommand("SET_MIC "+p)); }
      @Override public void onStartTrackingTouch(SeekBar sb){}
      @Override public void onStopTrackingTouch(SeekBar sb){}
    });

    statusPoll = new Runnable(){
      @Override public void run(){
        tvStatus.setText(NativeBridge.sendCommand("STATUS"));
        handler.postDelayed(this, 1000);
      }
    };
    handler.post(statusPoll);
  }

  private void wire(int id, final String cmd){
    findViewById(id).setOnClickListener(new View.OnClickListener(){
      @Override public void onClick(View v){ append(NativeBridge.sendCommand(cmd)); }
    });
  }

  private void wireMac(int id, final String prefix){
    findViewById(id).setOnClickListener(new View.OnClickListener(){
      @Override public void onClick(View v){
        String mac = etMac.getText().toString().trim();
        if(TextUtils.isEmpty(mac)){ append("ERR: MAC empty"); return; }
        append(NativeBridge.sendCommand(prefix + mac));
      }
    });
  }

  private void append(String s){
    if(s==null) s="(null)";
    tvLog.setText(s + "\n" + tvLog.getText().toString());
  }

  @Override protected void onDestroy(){
    handler.removeCallbacks(statusPoll);
    super.onDestroy();
  }
}
