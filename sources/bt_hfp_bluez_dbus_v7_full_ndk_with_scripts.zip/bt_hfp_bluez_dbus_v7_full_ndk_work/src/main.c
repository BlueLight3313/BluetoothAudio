
#include <stdio.h>

int dbus_core_init();
void dbus_core_loop();

extern int adapter_start_scan();
extern int hfp_register_profile();
extern int map_server_start();

int main(){
    printf("Bluetooth Chat Stage3 (HFP + MAP)\n");

    if(dbus_core_init()!=0)
        return -1;

    hfp_register_profile();
    map_server_start();

    adapter_start_scan();

    dbus_core_loop();
    return 0;
}
