
#include "dbus_core.h"
#include <stdio.h>

int device_pair(const char* path){
    printf("Pair %s\n",path);
    return dbus_call(path,"org.bluez.Device1","Pair");
}

int device_connect(const char* path){
    printf("Connect %s\n",path);
    return dbus_call(path,"org.bluez.Device1","Connect");
}

int device_disconnect(const char* path){
    printf("Disconnect %s\n",path);
    return dbus_call(path,"org.bluez.Device1","Disconnect");
}
