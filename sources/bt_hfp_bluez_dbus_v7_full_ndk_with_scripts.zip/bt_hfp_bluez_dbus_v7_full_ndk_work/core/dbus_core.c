
#include "dbus_core.h"
#include <stdio.h>

static DBusConnection *conn;

int dbus_core_init()
{
    DBusError err;
    dbus_error_init(&err);

    conn=dbus_bus_get(DBUS_BUS_SYSTEM,&err);

    if(dbus_error_is_set(&err)){
        printf("DBus error: %s\n",err.message);
        dbus_error_free(&err);
        return -1;
    }
    printf("DBus connected\n");
    return 0;
}

void dbus_core_loop()
{
    while(1)
        dbus_connection_read_write_dispatch(conn,1000);
}

DBusConnection* dbus_core_conn(){ return conn; }

int dbus_call(const char* path,const char* iface,const char* method)
{
    DBusMessage *msg,*reply;
    DBusError err;
    dbus_error_init(&err);

    msg=dbus_message_new_method_call("org.bluez",path,iface,method);
    reply=dbus_connection_send_with_reply_and_block(conn,msg,1000,&err);
    dbus_message_unref(msg);

    if(dbus_error_is_set(&err)){
        printf("DBus error: %s\n",err.message);
        dbus_error_free(&err);
        return -1;
    }
    if(reply) dbus_message_unref(reply);
    return 0;
}
