
#include <stdio.h>

int sco_open(){
    printf("Open SCO socket\n");
    return 0;
}

int sco_close(){
    printf("Close SCO socket\n");
    return 0;
}
