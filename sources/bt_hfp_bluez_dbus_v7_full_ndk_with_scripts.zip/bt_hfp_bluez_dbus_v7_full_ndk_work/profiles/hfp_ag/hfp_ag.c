
#include <stdio.h>

int hfp_register_profile(){
    printf("Register HFP Audio Gateway via ProfileManager1\n");
    return 0;
}

int hfp_start_voice(){
    printf("Start RFCOMM + SCO voice channel\n");
    return 0;
}

int hfp_stop_voice(){
    printf("Stop voice channel\n");
    return 0;
}
