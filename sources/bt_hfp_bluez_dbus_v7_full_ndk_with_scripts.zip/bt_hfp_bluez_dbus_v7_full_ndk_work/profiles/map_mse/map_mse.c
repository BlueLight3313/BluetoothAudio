
#include <stdio.h>

int map_server_start(){
    printf("MAP OBEX Message Server start\n");
    return 0;
}

int map_send_sms(const char* msg){
    printf("Send SMS via MAP: %s\n",msg);
    return 0;
}
