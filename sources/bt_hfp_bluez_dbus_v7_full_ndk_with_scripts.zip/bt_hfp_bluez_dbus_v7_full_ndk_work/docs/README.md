
Stage3 adds:
- HFP Audio Gateway profile skeleton
- RFCOMM/SCO voice architecture
- MAP Message Server skeleton
- SMS send interface

Build:
cd jni
ndk-build
