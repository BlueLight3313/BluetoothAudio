#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"

if [[ -n "${ANDROID_NDK:-}" && -x "$ANDROID_NDK/ndk-build" ]]; then
  cd "$PROJECT_ROOT/jni"
  "$ANDROID_NDK/ndk-build" NDK_PROJECT_PATH="$PROJECT_ROOT" clean || true
fi

rm -rf "$PROJECT_ROOT/libs" "$PROJECT_ROOT/obj"

echo "Clean complete."
