# Combined BlueZ + D-Bus Project (v7 full)

This package combines the updated BlueZ + D-Bus project work into one source tree.

Included:
- DBus core
- Adapter scan control
- Device pair/connect/disconnect
- Reconnect module
- HFP Audio Gateway architecture
- SCO audio bridge architecture
- MAP Message Server architecture
- Android NDK build files

Important:
This combined package consolidates the updated BlueZ/D-Bus architecture work from the staged versions into one project.
Some subsystems are still architectural/skeleton implementations and require real-device completion and integration:
- full BlueZ Agent1 pairing flow
- BlueZ signal monitoring
- full HFP RFCOMM/AT engine
- SCO PCM routing
- full MAP OBEX packet handling

Build:
cd jni
ndk-build
