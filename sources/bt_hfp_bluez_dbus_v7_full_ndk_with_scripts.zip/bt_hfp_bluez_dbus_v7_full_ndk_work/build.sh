#!/usr/bin/env bash
set -euo pipefail

if [[ -z "${ANDROID_NDK:-}" ]]; then
  echo "ERROR: ANDROID_NDK is not set."
  echo "Example:"
  echo "  export ANDROID_NDK=/home/yourname/android-ndk-r21e"
  exit 2
fi

if [[ ! -x "$ANDROID_NDK/ndk-build" ]]; then
  echo "ERROR: ndk-build not found at:"
  echo "  $ANDROID_NDK/ndk-build"
  exit 2
fi

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_ROOT/jni"

echo "[1/2] Running ndk-build..."
"$ANDROID_NDK/ndk-build" NDK_PROJECT_PATH="$PROJECT_ROOT"

echo "[2/2] Build finished."
echo "Expected outputs:"
echo "  $PROJECT_ROOT/libs/armeabi-v7a/bt_chatd"
echo "  $PROJECT_ROOT/libs/arm64-v8a/bt_chatd"
