package com.example.btchatcontroller;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    private TextView tvStatus;
    private TextView tvLog;
    private EditText etMac, etHost, etPort;
    private SeekBar sbSpk, sbMic;

    private final Handler handler = new Handler();
    private Runnable statusPoll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = findViewById(R.id.tvStatus);
        tvLog = findViewById(R.id.tvLog);
        etMac = findViewById(R.id.etMac);
        etHost = findViewById(R.id.etHost);
        etPort = findViewById(R.id.etPort);
        sbSpk = findViewById(R.id.sbSpk);
        sbMic = findViewById(R.id.sbMic);

        applyEndpoint();

        findViewById(R.id.btnStatus).setOnClickListener(v -> { applyEndpoint(); appendLog(NativeBridge.sendCommand("STATUS")); });
        findViewById(R.id.btnScanOn).setOnClickListener(v -> { applyEndpoint(); appendLog(NativeBridge.sendCommand("SCAN ON")); });
        findViewById(R.id.btnScanOff).setOnClickListener(v -> { applyEndpoint(); appendLog(NativeBridge.sendCommand("SCAN OFF")); });

        findViewById(R.id.btnPair).setOnClickListener(v -> sendWithMac("PAIR "));
        findViewById(R.id.btnTrust).setOnClickListener(v -> sendWithMac("TRUST "));
        findViewById(R.id.btnConnect).setOnClickListener(v -> sendWithMac("CONNECT "));
        findViewById(R.id.btnDial).setOnClickListener(v -> sendWithMac("DIAL "));

        findViewById(R.id.btnAnswer).setOnClickListener(v -> { applyEndpoint(); appendLog(NativeBridge.sendCommand("ANSWER")); });
        findViewById(R.id.btnReject).setOnClickListener(v -> { applyEndpoint(); appendLog(NativeBridge.sendCommand("REJECT")); });
        findViewById(R.id.btnHangup).setOnClickListener(v -> { applyEndpoint(); appendLog(NativeBridge.sendCommand("HANGUP")); });

        sbSpk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) { applyEndpoint(); appendLog(NativeBridge.sendCommand("SET_SPK " + progress)); }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        sbMic.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) { applyEndpoint(); appendLog(NativeBridge.sendCommand("SET_MIC " + progress)); }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        statusPoll = new Runnable() {
            @Override public void run() {
                applyEndpoint();
                tvStatus.setText(NativeBridge.sendCommand("STATUS"));
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(statusPoll);
    }

    private void applyEndpoint() {
        String host = etHost.getText().toString().trim();
        String portStr = etPort.getText().toString().trim();
        if (TextUtils.isEmpty(host)) host = "127.0.0.1";
        int port = 3333;
        try { port = Integer.parseInt(portStr); } catch (Exception ignored) {}
        NativeBridge.setEndpoint(host, port);
    }

    private void sendWithMac(String prefix) {
        applyEndpoint();
        String mac = etMac.getText().toString().trim();
        if (TextUtils.isEmpty(mac)) { appendLog("ERR: MAC is empty"); return; }
        appendLog(NativeBridge.sendCommand(prefix + mac));
    }

    private void appendLog(String line) {
        if (line == null) line = "(null)";
        tvLog.setText(line + "\n" + tvLog.getText().toString());
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(statusPoll);
        super.onDestroy();
    }
}
