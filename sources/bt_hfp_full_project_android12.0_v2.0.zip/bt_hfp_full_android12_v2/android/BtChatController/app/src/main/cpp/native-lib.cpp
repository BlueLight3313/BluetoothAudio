#include <jni.h>
#include <string>
#include <android/log.h>

#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

#define LOG_TAG "BtChatJNI"
#define ALOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static std::string g_host = "127.0.0.1";
static int g_port = 3333;

static std::string send_command_line(const std::string& cmd) {
    int fd = ::socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return std::string("ERR socket: ") + strerror(errno);

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons((uint16_t)g_port);
    if (::inet_pton(AF_INET, g_host.c_str(), &addr.sin_addr) != 1) {
        ::close(fd);
        return "ERR inet_pton";
    }

    if (::connect(fd, (sockaddr*)&addr, sizeof(addr)) < 0) {
        std::string err = std::string("ERR connect: ") + strerror(errno);
        ::close(fd);
        return err;
    }

    // Read hello (best-effort)
    char hello[128];
    ::recv(fd, hello, sizeof(hello), MSG_DONTWAIT);

    std::string out = cmd;
    if (out.empty() || out.back() != '\n') out.push_back('\n');

    if (::send(fd, out.c_str(), out.size(), 0) <= 0) {
        std::string err = std::string("ERR send: ") + strerror(errno);
        ::close(fd);
        return err;
    }

    std::string resp;
    char buf[256];
    while (true) {
        ssize_t rn = ::recv(fd, buf, sizeof(buf), 0);
        if (rn <= 0) break;
        resp.append(buf, buf + rn);
        size_t pos = resp.find('\n');
        if (pos != std::string::npos) { resp = resp.substr(0, pos); break; }
    }

    ::close(fd);
    if (resp.empty()) resp = "OK";
    return resp;
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_btchatcontroller_NativeBridge_setEndpoint(JNIEnv* env, jclass, jstring jhost, jint jport) {
    const char* h = env->GetStringUTFChars(jhost, nullptr);
    if (h) {
        g_host = h;
        env->ReleaseStringUTFChars(jhost, h);
    }
    g_port = (int)jport;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_btchatcontroller_NativeBridge_sendCommand(JNIEnv* env, jclass, jstring jcmd) {
    if (!jcmd) return env->NewStringUTF("ERR: null cmd");
    const char* c = env->GetStringUTFChars(jcmd, nullptr);
    std::string cmd = c ? c : "";
    env->ReleaseStringUTFChars(jcmd, c);
    std::string resp = send_command_line(cmd);
    return env->NewStringUTF(resp.c_str());
}
