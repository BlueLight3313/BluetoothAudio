package com.example.btchatcontroller;

public class NativeBridge {
    static { System.loadLibrary("btchat_jni"); }
    public static native void setEndpoint(String host, int port);
    public static native String sendCommand(String cmd);
}
