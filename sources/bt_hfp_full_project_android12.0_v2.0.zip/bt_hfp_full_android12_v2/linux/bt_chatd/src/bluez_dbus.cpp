#include "bluez_dbus.hpp"
#include "log.hpp"
#include "util.hpp"

static const char* BLUEZ_BUS = "org.bluez";

BluezDbus::BluezDbus() {}
BluezDbus::~BluezDbus() { if (conn_) dbus_connection_unref(conn_); conn_=nullptr; }

bool BluezDbus::connect_system_bus() {
    DBusError err; dbus_error_init(&err);
    conn_ = dbus_bus_get(DBUS_BUS_SYSTEM, &err);
    if (!conn_) {
        loge("dbus_bus_get(system) failed: %s", err.message ? err.message : "unknown");
        dbus_error_free(&err);
        return false;
    }
    dbus_connection_set_exit_on_disconnect(conn_, 0);
    return true;
}

bool BluezDbus::call_method(const std::string& bus, const std::string& path,
                            const std::string& iface, const std::string& method,
                            std::function<void(DBusMessageIter* args)> build_args) {
    DBusMessage* msg = dbus_message_new_method_call(bus.c_str(), path.c_str(), iface.c_str(), method.c_str());
    if (!msg) return false;

    DBusMessageIter it; dbus_message_iter_init_append(msg, &it);
    if (build_args) build_args(&it);

    DBusError err; dbus_error_init(&err);
    DBusMessage* reply = dbus_connection_send_with_reply_and_block(conn_, msg, 5000, &err);
    dbus_message_unref(msg);

    if (!reply) {
        loge("D-Bus call %s.%s failed: %s", iface.c_str(), method.c_str(), err.message ? err.message : "unknown");
        dbus_error_free(&err);
        return false;
    }
    dbus_message_unref(reply);
    return true;
}

bool BluezDbus::set_property_bool(const std::string& bus, const std::string& path,
                                  const std::string& iface, const std::string& prop, bool v) {
    return call_method(bus, path, "org.freedesktop.DBus.Properties", "Set",
        [&](DBusMessageIter* it){
            const char* iface_c = iface.c_str();
            const char* prop_c = prop.c_str();
            dbus_message_iter_append_basic(it, DBUS_TYPE_STRING, &iface_c);
            dbus_message_iter_append_basic(it, DBUS_TYPE_STRING, &prop_c);

            DBusMessageIter var;
            dbus_message_iter_open_container(it, DBUS_TYPE_VARIANT, "b", &var);
            dbus_bool_t bv = v ? 1 : 0;
            dbus_message_iter_append_basic(&var, DBUS_TYPE_BOOLEAN, &bv);
            dbus_message_iter_close_container(it, &var);
        });
}

bool BluezDbus::get_property_string(const std::string& bus, const std::string& path,
                                    const std::string& iface, const std::string& prop, std::string& out) {
    DBusMessage* msg = dbus_message_new_method_call(bus.c_str(), path.c_str(),
        "org.freedesktop.DBus.Properties", "Get");
    if (!msg) return false;

    DBusMessageIter it; dbus_message_iter_init_append(msg, &it);
    const char* iface_c = iface.c_str();
    const char* prop_c = prop.c_str();
    dbus_message_iter_append_basic(&it, DBUS_TYPE_STRING, &iface_c);
    dbus_message_iter_append_basic(&it, DBUS_TYPE_STRING, &prop_c);

    DBusError err; dbus_error_init(&err);
    DBusMessage* reply = dbus_connection_send_with_reply_and_block(conn_, msg, 3000, &err);
    dbus_message_unref(msg);

    if (!reply) {
        loge("Get %s.%s failed: %s", iface.c_str(), prop.c_str(), err.message ? err.message : "unknown");
        dbus_error_free(&err);
        return false;
    }

    DBusMessageIter rit;
    dbus_message_iter_init(reply, &rit);
    if (dbus_message_iter_get_arg_type(&rit) != DBUS_TYPE_VARIANT) { dbus_message_unref(reply); return false; }
    DBusMessageIter var; dbus_message_iter_recurse(&rit, &var);
    if (dbus_message_iter_get_arg_type(&var) != DBUS_TYPE_STRING) { dbus_message_unref(reply); return false; }
    const char* s = nullptr;
    dbus_message_iter_get_basic(&var, &s);
    out = s ? s : "";
    dbus_message_unref(reply);
    return true;
}

bool BluezDbus::adapter_set_powered(const std::string& adapter, bool on) {
    std::string path = "/org/bluez/" + adapter;
    return set_property_bool(BLUEZ_BUS, path, "org.bluez.Adapter1", "Powered", on);
}
bool BluezDbus::adapter_start_discovery(const std::string& adapter) {
    std::string path = "/org/bluez/" + adapter;
    return call_method(BLUEZ_BUS, path, "org.bluez.Adapter1", "StartDiscovery", nullptr);
}
bool BluezDbus::adapter_stop_discovery(const std::string& adapter) {
    std::string path = "/org/bluez/" + adapter;
    return call_method(BLUEZ_BUS, path, "org.bluez.Adapter1", "StopDiscovery", nullptr);
}
bool BluezDbus::adapter_get_address(const std::string& adapter, std::string& out_mac) {
    std::string path = "/org/bluez/" + adapter;
    return get_property_string(BLUEZ_BUS, path, "org.bluez.Adapter1", "Address", out_mac);
}
bool BluezDbus::device_pair(const std::string& adapter, const std::string& mac) {
    std::string path = "/org/bluez/" + adapter + "/" + mac_to_bluez_path(mac);
    return call_method(BLUEZ_BUS, path, "org.bluez.Device1", "Pair", nullptr);
}
bool BluezDbus::device_set_trusted(const std::string& adapter, const std::string& mac, bool trusted) {
    std::string path = "/org/bluez/" + adapter + "/" + mac_to_bluez_path(mac);
    return set_property_bool(BLUEZ_BUS, path, "org.bluez.Device1", "Trusted", trusted);
}
bool BluezDbus::device_connect_profile(const std::string& adapter, const std::string& mac, const std::string& uuid) {
    std::string path = "/org/bluez/" + adapter + "/" + mac_to_bluez_path(mac);
    return call_method(BLUEZ_BUS, path, "org.bluez.Device1", "ConnectProfile",
        [&](DBusMessageIter* it){
            const char* u = uuid.c_str();
            dbus_message_iter_append_basic(it, DBUS_TYPE_STRING, &u);
        });
}
bool BluezDbus::register_agent(const std::string& agent_path, const std::string& capability) {
    return call_method(BLUEZ_BUS, "/org/bluez", "org.bluez.AgentManager1", "RegisterAgent",
        [&](DBusMessageIter* it){
            const char* ap = agent_path.c_str();
            const char* cap = capability.c_str();
            dbus_message_iter_append_basic(it, DBUS_TYPE_OBJECT_PATH, &ap);
            dbus_message_iter_append_basic(it, DBUS_TYPE_STRING, &cap);
        });
}
bool BluezDbus::request_default_agent(const std::string& agent_path) {
    return call_method(BLUEZ_BUS, "/org/bluez", "org.bluez.AgentManager1", "RequestDefaultAgent",
        [&](DBusMessageIter* it){
            const char* ap = agent_path.c_str();
            dbus_message_iter_append_basic(it, DBUS_TYPE_OBJECT_PATH, &ap);
        });
}
