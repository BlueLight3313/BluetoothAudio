#pragma once
#include <string>
#include <thread>
#include <atomic>
#include "cvsd.hpp"

class ScoAudioBridge {
public:
    ScoAudioBridge();
    ~ScoAudioBridge();
    bool start(const std::string& remote_mac, const std::string& pcm_capture_dev, const std::string& pcm_playback_dev);
    void stop();
    bool running() const { return running_; }
private:
    std::atomic<bool> running_{false};
    int sco_fd_=-1;
    std::string remote_mac_, cap_dev_, pb_dev_;
    std::thread th_tx_, th_rx_;
    void* cap_handle_=nullptr;
    void* pb_handle_=nullptr;
    CvsdCodec cvsd_tx_, cvsd_rx_;
    bool open_sco();
    bool open_alsa();
    void close_sco();
    void close_alsa();
    void thread_tx();
    void thread_rx();
};
