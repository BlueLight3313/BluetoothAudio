#pragma once
#include <string>
#include <functional>
#include <thread>

class TcpControlServer {
public:
    using Handler = std::function<std::string(const std::string& line)>;
    TcpControlServer(const std::string& bind_ip, int port, Handler handler);
    ~TcpControlServer();
    bool start();
    void stop();
private:
    std::string bind_ip_;
    int port_;
    Handler handler_;
    int listen_fd_=-1;
    bool running_=false;
    std::thread th_;
    void thread_main();
    void handle_client(int cfd);
};
