#pragma once
#include <dbus/dbus.h>
#include <string>

class BluezAgent {
public:
    BluezAgent(DBusConnection* conn, const std::string& path);
    ~BluezAgent();
    bool export_on_dbus();
private:
    DBusConnection* conn_;
    std::string path_;
    static DBusHandlerResult filter(DBusConnection* c, DBusMessage* m, void* user);
    DBusHandlerResult handle(DBusMessage* m);
    void reply_ok(DBusMessage* m);
    void reply_pin_code(DBusMessage* m, const std::string& pin);
    void reply_passkey(DBusMessage* m, uint32_t passkey);
};
