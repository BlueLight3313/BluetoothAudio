#pragma once
#include <string>
#include <thread>
#include <atomic>
#include <functional>
#include "state.hpp"

class HfpAgServer {
public:
    using ScoStartFn = std::function<void(const std::string& mac)>;
    using ScoStopFn  = std::function<void(void)>;

    HfpAgServer(SharedState* st, ScoStartFn on_sco_start, ScoStopFn on_sco_stop);
    ~HfpAgServer();

    bool start();
    void stop();

    bool dial_to(const std::string& mac);
    bool answer();
    bool reject();
    bool hangup();

    void set_spk_gain(int v);
    void set_mic_gain(int v);

    void set_connected_mac(const std::string& mac);

private:
    SharedState* st_;
    ScoStartFn on_sco_start_;
    ScoStopFn on_sco_stop_;
    std::atomic<bool> running_{false};
    std::thread th_;
    int rfcomm_listen_=-1;
    int rfcomm_fd_=-1;
    std::string peer_mac_;
    bool open_rfcomm_server();
    void close_rfcomm();
    void thread_main();
    void handle_line(const std::string& line);
    void send_line(const std::string& s);
    void send_ok();
    void send_cind_list();
    void send_cind_status();
    void send_ciev(const char* ind, int val);
    void send_ring_clip();
    void set_call_state(CallState cs);
};
