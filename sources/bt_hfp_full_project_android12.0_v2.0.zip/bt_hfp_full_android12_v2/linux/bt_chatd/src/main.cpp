#include "log.hpp"
#include "util.hpp"
#include "state.hpp"
#include "bluez_dbus.hpp"
#include "bluez_agent.hpp"
#include "tcp_server.hpp"
#include "hfp_ag.hpp"
#include "sco_audio.hpp"
#include <cstdlib>

static const char* HFP_HF_UUID = "0000111e-0000-1000-8000-00805f9b34fb";

static std::string status_text(SharedState* st) {
    std::lock_guard<std::mutex> lk(st->mu);
    const BtChatState& s = st->s;

    auto cs_to_str = [&](CallState cs)->const char*{
        switch (cs) {
            case CALL_IDLE: return "IDLE";
            case CALL_INCOMING: return "INCOMING";
            case CALL_OUTGOING_DIALING: return "OUTGOING_DIALING";
            case CALL_OUTGOING_ALERTING: return "OUTGOING_ALERTING";
            case CALL_ACTIVE: return "ACTIVE";
        }
        return "UNKNOWN";
    };

    char buf[512];
    std::snprintf(buf, sizeof(buf),
        "adapter=%s my_number=%s connected=%s peer=%s call=%s sco=%d spk=%d mic=%d scanning=%d",
        s.adapter.c_str(), s.my_number.c_str(),
        s.connected_mac.c_str(), s.peer_number.c_str(),
        cs_to_str(s.call_state),
        s.sco_open ? 1 : 0, s.spk_gain, s.mic_gain, s.scanning ? 1 : 0
    );
    return buf;
}

int main(int argc, char** argv) {
    std::string adapter = "hci0";
    std::string cap_dev = "default";
    std::string pb_dev  = "default";

    std::string tcp_ip = "127.0.0.1";
    int tcp_port = 3333;

    for (int i=1;i<argc;++i) {
        std::string a = argv[i];
        if (a=="--adapter" && i+1<argc) adapter = argv[++i];
        else if (a=="--pcm-capture" && i+1<argc) cap_dev = argv[++i];
        else if (a=="--pcm-playback" && i+1<argc) pb_dev = argv[++i];
        else if (a=="--tcp" && i+1<argc) {
            std::string v = argv[++i];
            auto p = v.find(':');
            if (p != std::string::npos) { tcp_ip = v.substr(0,p); tcp_port = std::atoi(v.substr(p+1).c_str()); }
            else tcp_ip = v;
        }
    }

    SharedState shared;
    { std::lock_guard<std::mutex> lk(shared.mu); shared.s.adapter = adapter; }

    BluezDbus bluez;
    if (!bluez.connect_system_bus()) return 2;

    bluez.adapter_set_powered(adapter, true);

    std::string myaddr;
    if (bluez.adapter_get_address(adapter, myaddr)) {
        std::lock_guard<std::mutex> lk(shared.mu);
        shared.s.my_number = myaddr;
    } else {
        logw("Failed to read adapter address");
    }

    const std::string agent_path = "/bt_chatd/agent";
    BluezAgent agent(bluez.conn(), agent_path);
    if (!agent.export_on_dbus()) return 3;
    bluez.register_agent(agent_path, "NoInputNoOutput");
    bluez.request_default_agent(agent_path);

    ScoAudioBridge audio;
    HfpAgServer hfp(&shared,
        [&](const std::string& mac){
            if (!audio.running()) {
                if (!audio.start(mac, cap_dev, pb_dev)) loge("Failed to start SCO audio bridge");
                else { std::lock_guard<std::mutex> lk(shared.mu); shared.s.sco_open = true; }
            }
        },
        [&](){
            audio.stop();
            std::lock_guard<std::mutex> lk(shared.mu);
            shared.s.sco_open = false;
        });

    if (!hfp.start()) { loge("Failed to start HFP AG"); return 4; }

    auto handler = [&](const std::string& line)->std::string {
        auto tok = split_ws(line);
        if (tok.empty()) return "ERR";
        const std::string& cmd = tok[0];

        if (cmd=="STATUS") return status_text(&shared);

        if (cmd=="SCAN" && tok.size()>=2) {
            if (tok[1]=="ON") {
                if (bluez.adapter_start_discovery(adapter)) { std::lock_guard<std::mutex> lk(shared.mu); shared.s.scanning=true; return "OK"; }
                return "ERR StartDiscovery";
            } else {
                if (bluez.adapter_stop_discovery(adapter)) { std::lock_guard<std::mutex> lk(shared.mu); shared.s.scanning=false; return "OK"; }
                return "ERR StopDiscovery";
            }
        }

        if (cmd=="PAIR" && tok.size()==2) return bluez.device_pair(adapter, tok[1]) ? "OK" : "ERR Pair";
        if (cmd=="TRUST" && tok.size()==2) return bluez.device_set_trusted(adapter, tok[1], true) ? "OK" : "ERR Trust";

        if (cmd=="CONNECT" && tok.size()==2) {
            if (!bluez.device_connect_profile(adapter, tok[1], HFP_HF_UUID)) return "ERR ConnectProfile";
            hfp.set_connected_mac(tok[1]);
            return "OK";
        }

        if (cmd=="DIAL" && tok.size()==2) return hfp.dial_to(tok[1]) ? "OK" : "ERR Dial";
        if (cmd=="ANSWER") return hfp.answer() ? "OK" : "ERR Answer";
        if (cmd=="REJECT") return hfp.reject() ? "OK" : "ERR Reject";
        if (cmd=="HANGUP") return hfp.hangup() ? "OK" : "ERR Hangup";

        if (cmd=="SET_SPK" && tok.size()==2) { hfp.set_spk_gain(std::atoi(tok[1].c_str())); return "OK"; }
        if (cmd=="SET_MIC" && tok.size()==2) { hfp.set_mic_gain(std::atoi(tok[1].c_str())); return "OK"; }

        return "ERR Unknown";
    };

    TcpControlServer tcp_srv(tcp_ip, tcp_port, handler);
    if (!tcp_srv.start()) { loge("TCP control failed to start"); return 5; }

    logi("bt_chatd running. tcp=%s:%d", tcp_ip.c_str(), tcp_port);

    while (true) {
        dbus_connection_read_write_dispatch(bluez.conn(), 100);
    }
    return 0;
}
