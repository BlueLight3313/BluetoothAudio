#include "tcp_server.hpp"
#include "log.hpp"
#include "util.hpp"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <cstring>
#include <cerrno>

TcpControlServer::TcpControlServer(const std::string& bind_ip, int port, Handler handler)
    : bind_ip_(bind_ip), port_(port), handler_(handler) {}
TcpControlServer::~TcpControlServer() { stop(); }

bool TcpControlServer::start() {
    stop();
    listen_fd_ = ::socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd_ < 0) { loge("socket failed: %s", std::strerror(errno)); return false; }

    int one = 1;
    ::setsockopt(listen_fd_, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons((uint16_t)port_);
    addr.sin_addr.s_addr = ::inet_addr(bind_ip_.c_str());

    if (::bind(listen_fd_, (sockaddr*)&addr, sizeof(addr)) < 0) {
        loge("bind(%s:%d) failed: %s", bind_ip_.c_str(), port_, std::strerror(errno));
        ::close(listen_fd_); listen_fd_=-1; return false;
    }
    if (::listen(listen_fd_, 5) < 0) {
        loge("listen failed: %s", std::strerror(errno));
        ::close(listen_fd_); listen_fd_=-1; return false;
    }

    running_ = true;
    th_ = std::thread(&TcpControlServer::thread_main, this);
    logi("TCP control listening at %s:%d", bind_ip_.c_str(), port_);
    return true;
}

void TcpControlServer::stop() {
    running_ = false;
    if (listen_fd_ >= 0) {
        ::shutdown(listen_fd_, SHUT_RDWR);
        ::close(listen_fd_);
        listen_fd_=-1;
    }
    if (th_.joinable()) th_.join();
}

void TcpControlServer::thread_main() {
    while (running_) {
        int cfd = ::accept(listen_fd_, nullptr, nullptr);
        if (cfd < 0) { if (running_) logw("accept failed"); continue; }
        handle_client(cfd);
        ::close(cfd);
    }
}

void TcpControlServer::handle_client(int cfd) {
    const char* hello = "bt_chatd ready\n";
    ::send(cfd, hello, std::strlen(hello), 0);

    char buf[1024];
    std::string partial;
    while (running_) {
        ssize_t n = ::recv(cfd, buf, sizeof(buf), 0);
        if (n <= 0) break;
        partial.append(buf, buf + n);

        size_t pos;
        while ((pos = partial.find('\n')) != std::string::npos) {
            std::string line = trim(partial.substr(0, pos));
            partial.erase(0, pos + 1);
            if (line.empty()) continue;
            std::string resp = handler_(line);
            if (resp.empty()) resp = "OK";
            resp.push_back('\n');
            ::send(cfd, resp.c_str(), resp.size(), 0);
        }
    }
}
