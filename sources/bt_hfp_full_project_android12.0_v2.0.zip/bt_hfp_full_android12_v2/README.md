# Bluetooth HFP Voice Chat v2.0 (Android 12.0)

This package contains:
- **linux/bt_chatd**: Linux-level Bluetooth HFP-AG daemon (BlueZ + ALSA + SCO + CVSD bridge)
- **android/BtChatController**: Android 12.0 UI app (AndroidX)
- **android/BtChatController/app/src/main/cpp**: JNI native client (TCP localhost control)
- **docs/**: Step-by-step setup and usage

## Android 12 change (why v2.0)
Android 12 SELinux and app sandboxing often block direct access to `/dev/socket/*` from apps.
To avoid needing SELinux policy changes, v2.0 adds a **localhost TCP control interface**:

- `bt_chatd` listens on **127.0.0.1:3333** by default (configurable)
- Android app connects via TCP (requires `INTERNET` permission)

Bluetooth/HFP/audio logic remains Linux-level (no Android Bluetooth APIs).

## Quick start
See `docs/SETUP_ANDROID12.md` and `docs/USAGE.md`.
