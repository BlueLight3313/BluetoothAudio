# Usage

Control endpoint: `127.0.0.1:3333`

Commands:
- STATUS
- SCAN ON / SCAN OFF
- PAIR <MAC>
- TRUST <MAC>
- CONNECT <MAC>
- DIAL <MAC>
- ANSWER
- REJECT
- HANGUP
- SET_SPK 0..15
- SET_MIC 0..15

Shell example:
```sh
nc 127.0.0.1 3333
STATUS
SCAN ON
PAIR 01:23:45:67:89:AB
TRUST 01:23:45:67:89:AB
CONNECT 01:23:45:67:89:AB
DIAL 01:23:45:67:89:AB
```

Android app:
- Enter MAC
- Pair → Trust → Connect → Dial
- Use Answer/Reject/Hangup and volume sliders
