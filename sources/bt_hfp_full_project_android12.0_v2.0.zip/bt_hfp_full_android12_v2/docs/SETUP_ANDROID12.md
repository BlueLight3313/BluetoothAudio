# Setup (Android 12.0)

## 1) Linux side: BlueZ + ALSA + bt_chatd

### 1.1 Stop Android BT stack (vendor specific)
Goal: BlueZ owns the controller.
```sh
ps | grep -i -E "bluetooth|bluedroid|bt"
```
Stop/disable vendor services as your firmware allows.

### 1.2 Modules + adapter
```sh
modprobe btusb
modprobe bluetooth
modprobe rfcomm
modprobe sco
hciconfig hci0 up
hciconfig -a
```

### 1.3 Start BlueZ
```sh
bluetoothd -n -d &
```

### 1.4 Verify ALSA
```sh
arecord -l
aplay -l
arecord -D default -f S16_LE -c 1 -r 8000 -d 3 /data/local/tmp/test.wav
aplay -D default /data/local/tmp/test.wav
```

### 1.5 Build bt_chatd
```sh
cd linux/bt_chatd
make
```

### 1.6 Install + run bt_chatd
```sh
adb root
adb remount
adb push linux/bt_chatd/bt_chatd /system/bin/bt_chatd
adb shell chmod 0755 /system/bin/bt_chatd

/system/bin/bt_chatd --adapter hci0 --pcm-capture default --pcm-playback default --tcp 127.0.0.1:3333
```

Test control:
```sh
echo STATUS | nc 127.0.0.1 3333
```

## 2) Android 12 app

Open `android/BtChatController` in Android Studio, build, then:
```sh
adb install -r android/BtChatController/app/build/outputs/apk/debug/app-debug.apk
```

Open app → set MAC → Pair/Trust/Connect/Dial.

## Boot start (optional)
Add service to init scripts:
```rc
service bt_chatd /system/bin/bt_chatd --adapter hci0 --pcm-capture default --pcm-playback default --tcp 127.0.0.1:3333
    class main
    user root
    group root bluetooth audio system inet
    disabled
    oneshot

on property:sys.boot_completed=1
    start bt_chatd
```
