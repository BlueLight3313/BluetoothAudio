
#pragma once

int bt_init();
void bt_event_loop();
int bt_scan_start();
int bt_pair_device(const char *mac);
int bt_connect_device(const char *mac);
