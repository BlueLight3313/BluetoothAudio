
#include <stdio.h>
#include <stdlib.h>
#include <dbus/dbus.h>
#include "bluetooth_manager.h"

int main()
{
    printf("Bluetooth HFP/MAP daemon starting...\n");

    if (bt_init() != 0) {
        printf("Bluetooth init failed\n");
        return -1;
    }

    bt_event_loop();

    return 0;
}
