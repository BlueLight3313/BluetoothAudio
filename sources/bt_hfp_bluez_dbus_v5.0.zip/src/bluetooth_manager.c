
#include "bluetooth_manager.h"
#include <stdio.h>
#include <dbus/dbus.h>

static DBusConnection *conn;

int bt_init()
{
    DBusError err;
    dbus_error_init(&err);

    conn = dbus_bus_get(DBUS_BUS_SYSTEM, &err);
    if (dbus_error_is_set(&err)) {
        printf("DBus error: %s\n", err.message);
        dbus_error_free(&err);
        return -1;
    }

    if (!conn) {
        printf("DBus connection failed\n");
        return -1;
    }

    printf("Connected to system DBus\n");
    return 0;
}

void bt_event_loop()
{
    while (1) {
        dbus_connection_read_write_dispatch(conn, 1000);
    }
}

int bt_scan_start()
{
    printf("Start scan (BlueZ Adapter1.StartDiscovery)\n");
    return 0;
}

int bt_pair_device(const char *mac)
{
    printf("Pair device %s\n", mac);
    return 0;
}

int bt_connect_device(const char *mac)
{
    printf("Connect device %s\n", mac);
    return 0;
}
