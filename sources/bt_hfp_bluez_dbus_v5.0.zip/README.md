
Bluetooth HFP/MAP BlueZ v5.0

Architecture
------------

This version uses:

BlueZ
D-Bus
Linux Bluetooth stack

Layers:

Application
    |
D-Bus API
    |
BlueZ daemon
    |
Kernel Bluetooth stack
    |
USB Bluetooth controller

Features planned:
- Scan
- Pair
- Multi pair
- Auto reconnect
- HFP voice
- MAP messaging

Build:

sudo apt install libdbus-1-dev bluez
make

Run:

sudo ./bt_chatd
