
#include <stdio.h>
#include "agent.h"

int agent_register()
{
    printf("Register pairing agent\n");
    return 0;
}
