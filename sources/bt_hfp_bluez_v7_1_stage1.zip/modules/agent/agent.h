
#pragma once
int agent_register();
