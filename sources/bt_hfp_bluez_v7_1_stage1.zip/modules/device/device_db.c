
#include "device_db.h"
#include <string.h>
#include <stdio.h>

static bt_device devices[MAX_DEVICES];
static int count=0;

void device_db_add(const char* mac)
{
    if(count>=MAX_DEVICES) return;
    strcpy(devices[count].mac,mac);
    count++;
    printf("Device stored: %s\n",mac);
}

int device_db_count()
{
    return count;
}
