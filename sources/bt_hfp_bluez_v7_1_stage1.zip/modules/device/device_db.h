
#pragma once
#define MAX_DEVICES 8

typedef struct {
    char mac[18];
} bt_device;

void device_db_add(const char* mac);
int device_db_count();
