
#pragma once
int adapter_start_discovery();
int adapter_stop_discovery();
