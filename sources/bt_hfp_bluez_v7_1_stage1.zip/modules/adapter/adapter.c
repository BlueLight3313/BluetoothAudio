
#include "adapter.h"
#include "dbus_core.h"
#include <stdio.h>

int adapter_start_discovery()
{
    printf("StartDiscovery requested\n");
    return 0;
}

int adapter_stop_discovery()
{
    printf("StopDiscovery requested\n");
    return 0;
}
