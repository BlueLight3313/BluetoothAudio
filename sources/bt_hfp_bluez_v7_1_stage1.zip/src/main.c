
#include <stdio.h>
#include "dbus_core.h"
#include "adapter.h"
#include "agent.h"

int main()
{
    printf("Bluetooth Chat Stage1 (BlueZ core)\n");

    if(dbus_core_init()!=0)
        return -1;

    agent_register();
    adapter_start_discovery();

    dbus_core_loop();
    return 0;
}
