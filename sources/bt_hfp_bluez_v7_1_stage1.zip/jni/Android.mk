
LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := bt_chatd

LOCAL_SRC_FILES := ../src/main.c ../core/dbus_core.c ../modules/adapter/adapter.c ../modules/agent/agent.c ../modules/device/device_db.c

LOCAL_C_INCLUDES := ../include ../modules/adapter ../modules/agent ../modules/device

LOCAL_LDLIBS := -ldbus-1

include $(BUILD_EXECUTABLE)
