
Stage1 BlueZ Core

Implements:
- DBus core
- Adapter discovery
- Pairing agent
- Device database

Build:
cd jni
ndk-build
