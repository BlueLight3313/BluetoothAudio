
Bluetooth Chat v6.1 BlueZ Architecture

Application
   |
DBus manager
   |
BlueZ
   |
Kernel Bluetooth stack
   |
Controller

Modules:
scan
pair
connect
reconnect
hfp_ag
map_mse
