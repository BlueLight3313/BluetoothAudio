
#include "pair.h"
#include "dbus_manager.h"
#include <stdio.h>

int pair_init()
{
    printf("Pair module init\n");
    return 0;
}

int pair_device(const char* device_path)
{
    printf("Pairing %s\n",device_path);
    return dbus_call_method(device_path,"org.bluez.Device1","Pair");
}
