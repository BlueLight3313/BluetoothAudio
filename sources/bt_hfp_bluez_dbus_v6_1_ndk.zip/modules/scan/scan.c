
#include "scan.h"
#include "dbus_manager.h"
#include <stdio.h>

int scan_init()
{
    printf("Scan module init\n");
    return 0;
}

int scan_start()
{
    printf("StartDiscovery via BlueZ\n");
    return dbus_call_method("/org/bluez/hci0","org.bluez.Adapter1","StartDiscovery");
}

int scan_stop()
{
    printf("StopDiscovery via BlueZ\n");
    return dbus_call_method("/org/bluez/hci0","org.bluez.Adapter1","StopDiscovery");
}
