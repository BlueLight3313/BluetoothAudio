
#pragma once
int connect_init();
int connect_device(const char* device_path);
int disconnect_device(const char* device_path);
