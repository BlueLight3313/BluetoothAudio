
#include "connect.h"
#include "dbus_manager.h"
#include <stdio.h>

int connect_init()
{
    printf("Connect module init\n");
    return 0;
}

int connect_device(const char* device_path)
{
    printf("Connect %s\n",device_path);
    return dbus_call_method(device_path,"org.bluez.Device1","Connect");
}

int disconnect_device(const char* device_path)
{
    printf("Disconnect %s\n",device_path);
    return dbus_call_method(device_path,"org.bluez.Device1","Disconnect");
}
