
#include "map_mse.h"
#include <stdio.h>

int map_init()
{
    printf("MAP Message Server init\n");
    return 0;
}

int map_send_sms(const char* msg)
{
    printf("MAP send message: %s\n",msg);
    return 0;
}
