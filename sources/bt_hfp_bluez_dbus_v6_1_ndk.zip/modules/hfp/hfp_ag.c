
#include "hfp_ag.h"
#include <stdio.h>

int hfp_init()
{
    printf("HFP Audio Gateway init\n");
    return 0;
}

int hfp_start_chat()
{
    printf("Start SCO voice channel\n");
    return 0;
}

int hfp_stop_chat()
{
    printf("Stop SCO voice channel\n");
    return 0;
}
