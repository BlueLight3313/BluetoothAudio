
#include "reconnect.h"
#include "connect.h"
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

static char device[128];
static pthread_t thread;

static void* loop(void* p)
{
    while(1)
    {
        printf("Reconnect attempt\n");
        connect_device(device);
        sleep(5);
    }
}

void reconnect_start(const char* device_path)
{
    strcpy(device,device_path);
    pthread_create(&thread,NULL,loop,NULL);
}
