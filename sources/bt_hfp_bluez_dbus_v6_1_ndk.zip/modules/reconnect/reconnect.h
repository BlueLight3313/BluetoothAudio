
#pragma once
void reconnect_start(const char* device_path);
