
#include <stdio.h>
#include "dbus_manager.h"
#include "scan.h"
#include "pair.h"
#include "connect.h"
#include "reconnect.h"
#include "hfp_ag.h"
#include "map_mse.h"

int main()
{
    printf("bt_chatd BlueZ DBus v6.1 starting\n");

    if(dbus_manager_init()!=0)
        return -1;

    scan_init();
    pair_init();
    connect_init();
    hfp_init();
    map_init();

    scan_start();

    dbus_manager_loop();

    return 0;
}
