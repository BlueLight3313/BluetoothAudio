#include "sdp_server.h"
#include "l2cap.h"
#include "bt_util.h"
#include "log.h"

#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define SDP_PSM 0x0001

// SDP PDU IDs
#define SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_REQ 0x06
#define SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_RSP 0x07

struct sdp_server {
    int fd;
    int rfcomm_ch;
    pthread_t th;
    volatile int running;
};

static void be16_put(unsigned char* p, unsigned short v){ p[0]=(unsigned char)(v>>8); p[1]=(unsigned char)(v&0xFF); }
static unsigned short be16_get(const unsigned char* p){ return (unsigned short)((p[0]<<8)|p[1]); }

// Build a fairly small, common set of attributes for HFP AG. We return the bytes of a DataElementSequence.
static int build_hfp_ag_attr_list(unsigned char* out, int cap, int rfcomm_ch){
    unsigned char tmp[512];
    unsigned char* t=tmp;

    // Attr 0x0000 ServiceRecordHandle = 0x00010001
    *t++=0x09; *t++=0x00; *t++=0x00;
    *t++=0x0A; *t++=0x00; *t++=0x01; *t++=0x00; *t++=0x01;

    // Attr 0x0001 ServiceClassIDList = seq(uuid16 0x111F)
    *t++=0x09; *t++=0x00; *t++=0x01;
    *t++=0x35; *t++=0x03;
    *t++=0x19; *t++=0x11; *t++=0x1F; // HFP Audio Gateway

    // Attr 0x0004 ProtocolDescriptorList = seq( L2CAP(PSM 0x0003), RFCOMM(channel) )
    *t++=0x09; *t++=0x00; *t++=0x04;
    *t++=0x35; *t++=0x11; // len 17
      *t++=0x35; *t++=0x06;
        *t++=0x19; *t++=0x01; *t++=0x00; // L2CAP
        *t++=0x09; *t++=0x00; *t++=0x03; // PSM RFCOMM
      *t++=0x35; *t++=0x05;
        *t++=0x19; *t++=0x00; *t++=0x03; // RFCOMM
        *t++=0x08; *t++=(unsigned char)(rfcomm_ch & 0xFF);

    // Attr 0x0005 BrowseGroupList = seq(uuid16 0x1002)
    *t++=0x09; *t++=0x00; *t++=0x05;
    *t++=0x35; *t++=0x03;
    *t++=0x19; *t++=0x10; *t++=0x02;

    // Attr 0x0006 LanguageBaseAttributeIDList (en, UTF-8, base 0x0100)
    *t++=0x09; *t++=0x00; *t++=0x06;
    *t++=0x35; *t++=0x09;
    *t++=0x09; *t++=0x65; *t++=0x6E; // "en"
    *t++=0x09; *t++=0x00; *t++=0x6A; // UTF-8
    *t++=0x09; *t++=0x01; *t++=0x00; // base

    // Attr 0x0009 BluetoothProfileDescriptorList = seq( seq(uuid16 0x111E, uint16 0x0107) )
    *t++=0x09; *t++=0x00; *t++=0x09;
    *t++=0x35; *t++=0x0A;
      *t++=0x35; *t++=0x08;
        *t++=0x19; *t++=0x11; *t++=0x1E; // Handsfree profile
        *t++=0x09; *t++=0x01; *t++=0x07; // version 1.7

    // Attr 0x0100 ServiceName = "HFP AG"
    *t++=0x09; *t++=0x01; *t++=0x00;
    *t++=0x25; *t++=0x06;
    *t++='H'; *t++='F'; *t++='P'; *t++=' '; *t++='A'; *t++='G';

    // Attr 0x0311 SupportedFeatures = uint16 0x0001
    *t++=0x09; *t++=0x03; *t++=0x11;
    *t++=0x09; *t++=0x00; *t++=0x01;

    int attr_bytes=(int)(t - tmp);
    if(attr_bytes <=0 || attr_bytes > cap-2) return -1;

    // Wrap into a DataElementSequence 0x35 len
    out[0]=0x35;
    out[1]=(unsigned char)(attr_bytes & 0xFF);
    memcpy(out+2, tmp, (size_t)attr_bytes);
    return 2 + attr_bytes;
}

// Continuation: we use a 1-byte offset into the attribute list payload.
// ContinuationState format (SDP): 1 byte length N, then N bytes token.
// We'll use N=1, token=offset (0..255). 0 means "no continuation".
static void* th_main(void* arg){
    struct sdp_server* s=(struct sdp_server*)arg;

    while(s->running){
        int cfd=accept(s->fd, NULL, NULL);
        if(cfd<0){
            if(errno==EINTR) continue;
            usleep(50*1000);
            continue;
        }

        unsigned char req[1024];
        ssize_t n=recv(cfd, req, sizeof(req), 0);
        if(n < 5){
            close(cfd);
            continue;
        }

        unsigned char pdu_id=req[0];
        unsigned short tid=be16_get(req+1);
        unsigned short plen=be16_get(req+3);
        if((int)plen + 5 > (int)n) {
            // not enough bytes
            close(cfd);
            continue;
        }

        if(pdu_id != SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_REQ){
            close(cfd);
            continue;
        }

        // Request layout:
        // 0: pdu_id
        // 1..2: tid
        // 3..4: param_len
        // params:
        //   ServiceSearchPattern (DE seq)
        //   MaximumAttributeByteCount (uint16)
        //   AttributeIDList (DE seq)
        //   ContinuationState (1 + N)
        //
        // We only need MaximumAttributeByteCount and ContinuationState to split response.
        const unsigned char* p = req + 5;
        const unsigned char* end = req + 5 + plen;

        // skip ServiceSearchPattern (DE)
        if(p >= end) { close(cfd); continue; }
        // minimal DE skip: handle 0x35 len8
        if(*p == 0x35 && p+2 <= end){
            unsigned int len = p[1];
            p += 2 + len;
        } else {
            // unknown; bail
            close(cfd);
            continue;
        }

        if(p+2 > end){ close(cfd); continue; }
        unsigned short max_attr_bytes = be16_get(p); p += 2;
        if(max_attr_bytes < 16) max_attr_bytes = 16; // safety

        // skip AttributeIDList (DE)
        if(p >= end){ close(cfd); continue; }
        if(*p == 0x35 && p+2 <= end){
            unsigned int len = p[1];
            p += 2 + len;
        } else {
            close(cfd);
            continue;
        }

        unsigned char cont_len = 0;
        unsigned char cont_token = 0;
        if(p < end){
            cont_len = *p++;
            if(cont_len == 1 && p < end){
                cont_token = *p++;
            }
        }

        unsigned char attr_list[512];
        int attr_len = build_hfp_ag_attr_list(attr_list, (int)sizeof(attr_list), s->rfcomm_ch);
        if(attr_len < 0){
            close(cfd);
            continue;
        }

        // We return "AttributeLists" as raw bytes inside the response.
        // If too large for max_attr_bytes, send chunk with continuation token = next offset.
        int offset = (int)cont_token;
        if(offset < 0) offset = 0;
        if(offset > attr_len) offset = attr_len;

        int remaining = attr_len - offset;
        int send_bytes = remaining;
        if(send_bytes > (int)max_attr_bytes) send_bytes = (int)max_attr_bytes;

        unsigned char next_token = 0;
        if(offset + send_bytes < attr_len){
            next_token = (unsigned char)(offset + send_bytes);
        }

        unsigned char rsp[1024];
        unsigned char* q=rsp;
        *q++ = SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_RSP;
        be16_put(q, tid); q+=2;

        unsigned char* rsp_plen_ptr=q; q+=2;

        // AttributeListsByteCount is total attribute list length (not chunk length)
        be16_put(q, (unsigned short)attr_len); q+=2;

        memcpy(q, attr_list + offset, (size_t)send_bytes);
        q += send_bytes;

        // ContinuationState
        if(next_token != 0){
            *q++ = 0x01;
            *q++ = next_token;
        }else{
            *q++ = 0x00;
        }

        unsigned short rsp_plen=(unsigned short)(q - (rsp_plen_ptr + 2));
        be16_put(rsp_plen_ptr, rsp_plen);

        (void)send(cfd, rsp, (size_t)(q - rsp), 0);
        close(cfd);
    }
    return NULL;
}

sdp_server_t* sdp_server_start(int rfcomm_channel){
    struct sdp_server* s=(struct sdp_server*)calloc(1,sizeof(*s));
    s->rfcomm_ch = rfcomm_channel;

    s->fd = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP);
    if(s->fd < 0){
        LOGE("SDP socket failed: %s", strerror(errno));
        free(s);
        return NULL;
    }

    struct sockaddr_l2 addr;
    memset(&addr,0,sizeof(addr));
    addr.l2_family = AF_BLUETOOTH;
    addr.l2_psm = htons(SDP_PSM);
    bt_bdaddr_any(&addr.l2_bdaddr);

    if(bind(s->fd, (struct sockaddr*)&addr, sizeof(addr))<0){
        LOGE("SDP bind failed: %s", strerror(errno));
        close(s->fd); free(s);
        return NULL;
    }
    if(listen(s->fd, 5)<0){
        LOGE("SDP listen failed: %s", strerror(errno));
        close(s->fd); free(s);
        return NULL;
    }

    s->running=1;
    pthread_create(&s->th, NULL, th_main, s);
    LOGI("SDP server started (HFP AG UUID 0x111F, RFCOMM ch=%d)", rfcomm_channel);
    return (sdp_server_t*)s;
}

void sdp_server_stop(sdp_server_t* s0){
    struct sdp_server* s=(struct sdp_server*)s0;
    if(!s) return;
    s->running=0;
    shutdown(s->fd, SHUT_RDWR);
    pthread_join(s->th, NULL);
    close(s->fd);
    free(s);
}
