#include "sdp_server.h"
#include "l2cap.h"
#include "bt_util.h"
#include "log.h"

#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>

// SDP PSM
#define SDP_PSM 0x0001

// SDP PDU IDs
#define SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_REQ 0x06
#define SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_RSP 0x07

struct sdp_server {
    int fd;
    int rfcomm_ch;
    pthread_t th;
    volatile int running;
};

static void be16_put(unsigned char* p, unsigned short v){ p[0]=(unsigned char)(v>>8); p[1]=(unsigned char)(v&0xFF); }

static int build_hfp_ag_attr_list(unsigned char* out, int cap, int rfcomm_ch){
    // Build an AttributeList as an SDP Data Element Sequence.
    // Minimal attributes for HFP AG discovery:
    // - 0x0000 ServiceRecordHandle (uint32)
    // - 0x0001 ServiceClassIDList (seq(uuid16 0x111F))
    // - 0x0004 ProtocolDescriptorList (seq( seq(l2cap, psm=3?) + seq(rfcomm, channel) ))
    // - 0x0009 BluetoothProfileDescriptorList (seq( seq(uuid16 0x111E, uint16 0x0107) ))
    // - 0x0311 SupportedFeatures (uint16 0x0001) [optional, minimal]
    //
    // NOTE: For RFCOMM, headsets mainly need the channel number.
    // L2CAP PSM for RFCOMM is implicitly 0x0003; we include it.

    unsigned char* p=out;
    unsigned char* end=out+cap;

    // We'll assemble inside a top-level sequence; easiest is to write into temp then wrap.
    unsigned char tmp[512];
    unsigned char* t=tmp;

    // Helper lambdas (manual)
    def_attr = lambda attr_id, val_bytes: None  # placeholder for readability

    // Attribute 0x0000: ServiceRecordHandle = 0x00010001
    # can't use lambda in C; build directly below (kept in comment form)
    // Each attribute is: uint16 attrId, then a DataElement for value.
    // AttributeList is a sequence of these attribute entries, but the "AttributeLists" in response uses a byte stream.
    // We'll output "AttributeLists" as a DataElementSequence of attribute entries:
    //   DE_SEQ(len=...) { DE_UINT16(attrId) DE_value ... } repeated.

    // We'll build as raw bytes of attribute entries then wrap later.

    // Attr 0x0000
    *t++=0x09; *t++=0x00; *t++=0x00; // uint16 0x0000
    *t++=0x0A; *t++=0x00; *t++=0x01; *t++=0x00; *t++=0x01; // uint32 0x00010001

    // Attr 0x0001 ServiceClassIDList = seq( uuid16 0x111F )
    *t++=0x09; *t++=0x00; *t++=0x01;
    // value: seq len=3
    *t++=0x35; *t++=0x03;
    *t++=0x19; *t++=0x11; *t++=0x1F;

    // Attr 0x0004 ProtocolDescriptorList
    *t++=0x09; *t++=0x00; *t++=0x04;
    // value: outer seq length to fill later
    unsigned char* pdl_len = t; *t++=0x35; unsigned char* pdl_len_byte=t++; // seq, 1-byte len
    unsigned char* pdl_start=t;

    // Protocol #1: L2CAP with PSM RFCOMM(0x0003)
    *t++=0x35; *t++=0x06;           // seq len 6
    *t++=0x19; *t++=0x01; *t++=0x00; // uuid16 L2CAP 0x0100
    *t++=0x09; *t++=0x00; *t++=0x03; // uint16 PSM 0x0003 (RFCOMM)

    // Protocol #2: RFCOMM with channel
    *t++=0x35; *t++=0x05;           // seq len 5
    *t++=0x19; *t++=0x00; *t++=0x03; // uuid16 RFCOMM 0x0003
    *t++=0x08; *t++=(unsigned char)(rfcomm_ch & 0xFF); // uint8 channel

    // fill pdl length
    *pdl_len_byte = (unsigned char)(t - pdl_start);

    // Attr 0x0009 BluetoothProfileDescriptorList
    *t++=0x09; *t++=0x00; *t++=0x09;
    // value: seq
    unsigned char* bpd = t; *t++=0x35; unsigned char* bpd_len=t++;
    unsigned char* bpd_start=t;

    // inner seq: uuid 0x111E (Handsfree) + version 0x0107
    *t++=0x35; *t++=0x08;
    *t++=0x19; *t++=0x11; *t++=0x1E; // uuid16 Handsfree
    *t++=0x09; *t++=0x01; *t++=0x07; // uint16 version 0x0107

    *bpd_len = (unsigned char)(t - bpd_start);

    // Attr 0x0311 SupportedFeatures (optional)
    *t++=0x09; *t++=0x03; *t++=0x11;
    *t++=0x09; *t++=0x00; *t++=0x01; // uint16 features=1 (minimal)

    int attr_bytes=(int)(t - tmp);
    if(attr_bytes <=0 || attr_bytes > cap-2) return -1;

    // Wrap attribute entries into a DataElementSequence:
    // 0x35 len attr_bytes  then entries
    if(2 + attr_bytes > cap) return -1;
    *p++=0x35;
    *p++=(unsigned char)(attr_bytes & 0xFF);
    memcpy(p, tmp, (size_t)attr_bytes);
    p += attr_bytes;

    return (int)(p - out);
}

static void* th_main(void* arg){
    struct sdp_server* s=(struct sdp_server*)arg;

    while(s->running){
        int cfd=accept(s->fd, NULL, NULL);
        if(cfd<0){
            if(errno==EINTR) continue;
            usleep(100*1000);
            continue;
        }

        unsigned char req[1024];
        ssize_t n=recv(cfd, req, sizeof(req), 0);
        if(n < 5){
            close(cfd);
            continue;
        }

        unsigned char pdu_id=req[0];
        unsigned short tid=(unsigned short)((req[1]<<8) | req[2]);
        unsigned short plen=(unsigned short)((req[3]<<8) | req[4]);
        (void)plen;

        if(pdu_id != SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_REQ){
            // ignore unsupported
            close(cfd);
            continue;
        }

        // Build response
        unsigned char rsp[1024];
        unsigned char* p=rsp;

        *p++ = SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_RSP;
        be16_put(p, tid); p+=2;

        // Reserve plen
        unsigned char* plen_ptr=p; p+=2;

        // AttributeListsByteCount (2 bytes) + AttributeLists + ContinuationState
        unsigned char attr_list[512];
        int attr_len=build_hfp_ag_attr_list(attr_list, (int)sizeof(attr_list), s->rfcomm_ch);
        if(attr_len<0){
            close(cfd);
            continue;
        }

        // AttributeListsByteCount = attr_len
        be16_put(p, (unsigned short)attr_len); p+=2;
        memcpy(p, attr_list, (size_t)attr_len); p+=attr_len;

        // ContinuationState: 1 byte length (0)
        *p++ = 0x00;

        unsigned short rsp_plen=(unsigned short)(p - (plen_ptr + 2));
        be16_put(plen_ptr, rsp_plen);

        (void)send(cfd, rsp, (size_t)(p - rsp), 0);
        close(cfd);
    }
    return NULL;
}

sdp_server_t* sdp_server_start(int rfcomm_channel){
    struct sdp_server* s=(struct sdp_server*)calloc(1,sizeof(*s));
    s->rfcomm_ch = rfcomm_channel;

    s->fd = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP);
    if(s->fd < 0){
        LOGE("SDP socket failed: %s", strerror(errno));
        free(s);
        return NULL;
    }

    struct sockaddr_l2 addr;
    memset(&addr,0,sizeof(addr));
    addr.l2_family = AF_BLUETOOTH;
    addr.l2_psm = htons(SDP_PSM);
    bt_bdaddr_any(&addr.l2_bdaddr);

    if(bind(s->fd, (struct sockaddr*)&addr, sizeof(addr))<0){
        LOGE("SDP bind failed: %s", strerror(errno));
        close(s->fd); free(s);
        return NULL;
    }
    if(listen(s->fd, 5)<0){
        LOGE("SDP listen failed: %s", strerror(errno));
        close(s->fd); free(s);
        return NULL;
    }

    s->running=1;
    pthread_create(&s->th, NULL, th_main, s);
    LOGI("SDP server started (HFP AG UUID 0x111F, RFCOMM ch=%d)", rfcomm_channel);
    return (sdp_server_t*)s;
}

void sdp_server_stop(sdp_server_t* s0){
    struct sdp_server* s=(struct sdp_server*)s0;
    if(!s) return;
    s->running=0;
    shutdown(s->fd, SHUT_RDWR);
    pthread_join(s->th, NULL);
    close(s->fd);
    free(s);
}
