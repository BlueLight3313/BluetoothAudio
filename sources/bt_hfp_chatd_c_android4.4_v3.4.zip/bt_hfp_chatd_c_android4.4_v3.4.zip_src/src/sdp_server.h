#pragma once
#ifdef __cplusplus
extern "C" {
#endif

typedef struct sdp_server sdp_server_t;

// Start a minimal SDP server for HFP Audio Gateway (UUID 0x111F) on RFCOMM channel 8.
// This is required for many headsets to discover and connect HFP.
sdp_server_t* sdp_server_start(int rfcomm_channel);

// Stop server and free resources.
void sdp_server_stop(sdp_server_t* s);

#ifdef __cplusplus
}
#endif
