#pragma once
#include <stdint.h>
#include "bluetooth.h"

#define BTPROTO_L2CAP 0

#ifndef AF_BLUETOOTH
#define AF_BLUETOOTH 31
#endif

#ifndef SOCK_SEQPACKET
#define SOCK_SEQPACKET 5
#endif

// kernel sockaddr for L2CAP (classic)
struct sockaddr_l2 {
    uint16_t l2_family;
    uint16_t l2_psm;
    bdaddr_t l2_bdaddr;
    uint16_t l2_cid;
    uint8_t  l2_bdaddr_type;
};
