# SDP upgrade (v3.4)

## Why this is needed
Many Bluetooth headsets will not open an HFP (RFCOMM) session unless the device advertises an HFP Audio Gateway service via SDP.
Without RFCOMM, the headset often won't enable SCO audio, even if you only want "Bluetooth voice chat" (no real phone call).

## What was added
- `src/sdp_server.c/.h`: a minimal SDP server on L2CAP PSM 0x0001
  - Responds to ServiceSearchAttributeRequest
  - Advertises HFP Audio Gateway UUID 0x111F and RFCOMM channel 8

## Result
Headsets can discover the HFP AG service and are more likely to connect RFCOMM and allow SCO audio.
