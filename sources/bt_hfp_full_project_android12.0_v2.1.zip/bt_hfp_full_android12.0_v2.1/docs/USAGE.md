# Usage (Android 12 v2.1)

Control endpoint: 127.0.0.1:3333

Commands include:
- SET_NUMBER <string>

Example:
```sh
echo "SET_NUMBER 9001234567" | nc 127.0.0.1 3333
```
