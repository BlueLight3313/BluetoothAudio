# Setup (Android 12)

Run daemon:
```sh
bluetoothd -n -d &
/system/bin/bt_chatd --adapter hci0 --pcm-capture default --pcm-playback default --tcp 127.0.0.1:3333
```

Test:
```sh
echo STATUS | nc 127.0.0.1 3333
echo "SET_NUMBER 9001234567" | nc 127.0.0.1 3333
```
