package com.example.btchatcontroller;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.widget.*;

public class MainActivity extends AppCompatActivity {
  private TextView tvStatus, tvLog;
  private EditText etMac, etNumber, etHost, etPort;
  private SeekBar sbSpk, sbMic;
  private final Handler handler = new Handler();
  private Runnable statusPoll;

  @Override protected void onCreate(Bundle savedInstanceState){
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    tvStatus=findViewById(R.id.tvStatus);
    tvLog=findViewById(R.id.tvLog);
    etMac=findViewById(R.id.etMac);
    etNumber=findViewById(R.id.etNumber);
    etHost=findViewById(R.id.etHost);
    etPort=findViewById(R.id.etPort);
    sbSpk=findViewById(R.id.sbSpk);
    sbMic=findViewById(R.id.sbMic);

    applyEndpoint();

    findViewById(R.id.btnSetNumber).setOnClickListener(v -> {
      applyEndpoint();
      String num = etNumber.getText().toString().trim();
      if (TextUtils.isEmpty(num)) { append("ERR: number empty"); return; }
      append(NativeBridge.sendCommand("SET_NUMBER " + num));
    });

    findViewById(R.id.btnStatus).setOnClickListener(v -> { applyEndpoint(); append(NativeBridge.sendCommand("STATUS")); });
    findViewById(R.id.btnScanOn).setOnClickListener(v -> { applyEndpoint(); append(NativeBridge.sendCommand("SCAN ON")); });
    findViewById(R.id.btnScanOff).setOnClickListener(v -> { applyEndpoint(); append(NativeBridge.sendCommand("SCAN OFF")); });

    findViewById(R.id.btnPair).setOnClickListener(v -> sendWithMac("PAIR "));
    findViewById(R.id.btnTrust).setOnClickListener(v -> sendWithMac("TRUST "));
    findViewById(R.id.btnConnect).setOnClickListener(v -> sendWithMac("CONNECT "));
    findViewById(R.id.btnDial).setOnClickListener(v -> sendWithMac("DIAL "));

    findViewById(R.id.btnAnswer).setOnClickListener(v -> { applyEndpoint(); append(NativeBridge.sendCommand("ANSWER")); });
    findViewById(R.id.btnReject).setOnClickListener(v -> { applyEndpoint(); append(NativeBridge.sendCommand("REJECT")); });
    findViewById(R.id.btnHangup).setOnClickListener(v -> { applyEndpoint(); append(NativeBridge.sendCommand("HANGUP")); });

    sbSpk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      @Override public void onProgressChanged(SeekBar sb,int p,boolean fromUser){ if(fromUser){ applyEndpoint(); append(NativeBridge.sendCommand("SET_SPK "+p)); } }
      @Override public void onStartTrackingTouch(SeekBar sb){}
      @Override public void onStopTrackingTouch(SeekBar sb){}
    });
    sbMic.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
      @Override public void onProgressChanged(SeekBar sb,int p,boolean fromUser){ if(fromUser){ applyEndpoint(); append(NativeBridge.sendCommand("SET_MIC "+p)); } }
      @Override public void onStartTrackingTouch(SeekBar sb){}
      @Override public void onStopTrackingTouch(SeekBar sb){}
    });

    statusPoll = new Runnable(){
      @Override public void run(){
        applyEndpoint();
        tvStatus.setText(NativeBridge.sendCommand("STATUS"));
        handler.postDelayed(this, 1000);
      }
    };
    handler.post(statusPoll);
  }

  private void applyEndpoint(){
    String host = etHost.getText().toString().trim();
    String ps = etPort.getText().toString().trim();
    if(TextUtils.isEmpty(host)) host="127.0.0.1";
    int port=3333; try{ port=Integer.parseInt(ps); }catch(Exception ignored){}
    NativeBridge.setEndpoint(host, port);
  }

  private void sendWithMac(String prefix){
    applyEndpoint();
    String mac = etMac.getText().toString().trim();
    if(TextUtils.isEmpty(mac)){ append("ERR: MAC empty"); return; }
    append(NativeBridge.sendCommand(prefix + mac));
  }

  private void append(String s){
    if(s==null) s="(null)";
    tvLog.setText(s + "\n" + tvLog.getText().toString());
  }

  @Override protected void onDestroy(){
    handler.removeCallbacks(statusPoll);
    super.onDestroy();
  }
}
