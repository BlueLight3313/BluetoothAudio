# Android 12.0 full project v2.1 (Linux daemon + Android app)

New in v2.1:
- `SET_NUMBER <string>`: send caller-id (+CLIP) with a special string.

Contents:
- linux/bt_chatd : BlueZ + ALSA + HFP AG + SCO(CVSD), control via TCP 127.0.0.1:3333
- android/BtChatController : Android 12 app + JNI TCP client
Docs: docs/SETUP_ANDROID12.md, docs/USAGE.md
