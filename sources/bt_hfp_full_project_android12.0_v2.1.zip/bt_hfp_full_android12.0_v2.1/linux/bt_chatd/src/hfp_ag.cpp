#include "hfp_ag.hpp"
#include "log.hpp"
#include "util.hpp"
#include <unistd.h>
#include <sys/socket.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/rfcomm.h>
#include <cstring>
#include <algorithm>
#include <cstdlib>

static const int RFCOMM_CH=8;

HfpAgServer::HfpAgServer(SharedState* st, ScoStartFn on_sco_start, ScoStopFn on_sco_stop)
    : st_(st), on_sco_start_(on_sco_start), on_sco_stop_(on_sco_stop) {}
HfpAgServer::~HfpAgServer(){ stop(); }

bool HfpAgServer::start(){
    stop();
    if(!open_rfcomm_server()) return false;
    running_=true;
    th_=std::thread(&HfpAgServer::thread_main, this);
    logi("HFP AG RFCOMM server started on channel %d", RFCOMM_CH);
    return true;
}
void HfpAgServer::stop(){
    running_=false;
    close_rfcomm();
    if(th_.joinable()) th_.join();
}
void HfpAgServer::set_connected_mac(const std::string& mac){
    std::lock_guard<std::mutex> lk(st_->mu);
    st_->s.connected_mac = mac;
    st_->s.peer_number = mac;
    peer_mac_ = mac;
}

bool HfpAgServer::open_rfcomm_server(){
    rfcomm_listen_=::socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);
    if(rfcomm_listen_<0) return false;
    sockaddr_rc loc{}; loc.rc_family=AF_BLUETOOTH; loc.rc_bdaddr=*BDADDR_ANY; loc.rc_channel=(uint8_t)RFCOMM_CH;
    if(::bind(rfcomm_listen_, (sockaddr*)&loc, sizeof(loc))<0){ ::close(rfcomm_listen_); rfcomm_listen_=-1; return false; }
    if(::listen(rfcomm_listen_, 1)<0){ ::close(rfcomm_listen_); rfcomm_listen_=-1; return false; }
    return true;
}
void HfpAgServer::close_rfcomm(){
    if(rfcomm_fd_>=0){ ::shutdown(rfcomm_fd_, SHUT_RDWR); ::close(rfcomm_fd_); rfcomm_fd_=-1; }
    if(rfcomm_listen_>=0){ ::shutdown(rfcomm_listen_, SHUT_RDWR); ::close(rfcomm_listen_); rfcomm_listen_=-1; }
}
void HfpAgServer::thread_main(){
    while(running_){
        sockaddr_rc rem{}; socklen_t len=sizeof(rem);
        int fd=::accept(rfcomm_listen_, (sockaddr*)&rem, &len);
        if(fd<0){ if(running_) logw("accept failed"); continue; }
        rfcomm_fd_=fd;
        char mac[18]{0}; ba2str(&rem.rc_bdaddr, mac);
        logi("HFP RFCOMM connected from %s", mac);
        set_connected_mac(mac);

        std::string buf; char tmp[512];
        while(running_){
            ssize_t n=::read(fd, tmp, sizeof(tmp));
            if(n<=0) break;
            buf.append(tmp, tmp+n);
            size_t pos;
            while((pos=buf.find('\r'))!=std::string::npos){
                std::string line=trim(buf.substr(0,pos));
                buf.erase(0,pos+1);
                if(!line.empty()){ logi("HF -> AG: %s", line.c_str()); handle_line(line); }
            }
        }
        logi("HFP RFCOMM disconnected");
        rfcomm_fd_=-1;
        { std::lock_guard<std::mutex> lk(st_->mu); st_->s.call_state=CALL_IDLE; st_->s.ind_call=0; st_->s.ind_callsetup=0; st_->s.sco_open=false; }
        on_sco_stop_();
        ::close(fd);
    }
}

void HfpAgServer::send_line(const std::string& s){
    if(rfcomm_fd_<0) return;
    std::string out=s+"\r\n";
    ::write(rfcomm_fd_, out.c_str(), out.size());
}
void HfpAgServer::send_ok(){ send_line("OK"); }
void HfpAgServer::send_cind_list(){
    send_line("+CIND: (\"service\",(0,1)),(\"call\",(0,1)),(\"callsetup\",(0-3)),(\"callheld\",(0-2))");
    send_ok();
}
void HfpAgServer::send_cind_status(){
    std::lock_guard<std::mutex> lk(st_->mu);
    char s[128]; std::snprintf(s,sizeof(s),"+CIND: %d,%d,%d,%d", st_->s.ind_service, st_->s.ind_call, st_->s.ind_callsetup, st_->s.ind_callheld);
    send_line(s); send_ok();
}
void HfpAgServer::send_ciev(const char* ind,int val){
    int idx=0;
    if(!std::strcmp(ind,"service")) idx=1;
    else if(!std::strcmp(ind,"call")) idx=2;
    else if(!std::strcmp(ind,"callsetup")) idx=3;
    else if(!std::strcmp(ind,"callheld")) idx=4;
    if(!idx) return;
    char s[64]; std::snprintf(s,sizeof(s),"+CIEV: %d,%d", idx, val);
    send_line(s);
}

void HfpAgServer::send_ring_clip(){
    send_line("RING");
    std::string num;
    { std::lock_guard<std::mutex> lk(st_->mu);
      num = st_->s.display_number.empty() ? st_->s.peer_number : st_->s.display_number;
    }
    send_line(std::string("+CLIP: \"") + num + "\",129");
}

void HfpAgServer::set_call_state(CallState cs){
    std::lock_guard<std::mutex> lk(st_->mu);
    st_->s.call_state=cs;
    if(cs==CALL_IDLE){ st_->s.ind_call=0; st_->s.ind_callsetup=0; }
    else if(cs==CALL_INCOMING){ st_->s.ind_call=0; st_->s.ind_callsetup=1; }
    else if(cs==CALL_OUTGOING_DIALING){ st_->s.ind_call=0; st_->s.ind_callsetup=2; }
    else if(cs==CALL_OUTGOING_ALERTING){ st_->s.ind_call=0; st_->s.ind_callsetup=3; }
    else if(cs==CALL_ACTIVE){ st_->s.ind_call=1; st_->s.ind_callsetup=0; }
}

void HfpAgServer::handle_line(const std::string& line){
    if(line=="AT"){ send_ok(); return; }
    if(line.rfind("AT+BRSF=",0)==0){ send_line("+BRSF: 0"); send_ok(); return; }
    if(line=="AT+CIND=?"){ send_cind_list(); return; }
    if(line=="AT+CIND?"){ send_cind_status(); return; }
    if(line.rfind("AT+CMER=",0)==0){ send_ok(); return; }

    if(line.rfind("AT+VGS=",0)==0){
        int v=std::atoi(line.c_str()+7);
        { std::lock_guard<std::mutex> lk(st_->mu); st_->s.spk_gain=std::max(0,std::min(15,v)); }
        send_ok(); return;
    }
    if(line.rfind("AT+VGM=",0)==0){
        int v=std::atoi(line.c_str()+7);
        { std::lock_guard<std::mutex> lk(st_->mu); st_->s.mic_gain=std::max(0,std::min(15,v)); }
        send_ok(); return;
    }

    if(line=="ATA"){
        { std::lock_guard<std::mutex> lk(st_->mu);
          if(st_->s.call_state==CALL_INCOMING){ st_->s.call_state=CALL_ACTIVE; st_->s.ind_call=1; st_->s.ind_callsetup=0; } }
        send_ok();
        send_ciev("callsetup",0);
        send_ciev("call",1);
        on_sco_start_(peer_mac_);
        { std::lock_guard<std::mutex> lk(st_->mu); st_->s.sco_open=true; }
        return;
    }

    if(line=="AT+CHUP"){ hangup(); send_ok(); return; }

    if(line.size()>=3 && line[0]=='A' && line[1]=='T' && line[2]=='D'){
        set_call_state(CALL_INCOMING);
        send_ok();
        send_ciev("callsetup",1);
        send_ring_clip();
        return;
    }

    if(line.rfind("AT+BAC=",0)==0){ send_ok(); send_line("AT+BCS=1"); return; }
    if(line.rfind("AT+BCS=",0)==0){ send_ok(); return; }

    send_ok();
}

bool HfpAgServer::dial_to(const std::string& mac){
    if(rfcomm_fd_<0) return false;
    set_connected_mac(mac);
    set_call_state(CALL_OUTGOING_ALERTING);
    send_ciev("callsetup",3);
    ::sleep(1);
    set_call_state(CALL_ACTIVE);
    send_ciev("callsetup",0);
    send_ciev("call",1);
    on_sco_start_(peer_mac_);
    { std::lock_guard<std::mutex> lk(st_->mu); st_->s.sco_open=true; }
    return true;
}
bool HfpAgServer::answer(){
    if(rfcomm_fd_<0) return false;
    { std::lock_guard<std::mutex> lk(st_->mu);
      if(st_->s.call_state!=CALL_INCOMING) return false;
      st_->s.call_state=CALL_ACTIVE; st_->s.ind_call=1; st_->s.ind_callsetup=0; }
    send_ciev("callsetup",0);
    send_ciev("call",1);
    on_sco_start_(peer_mac_);
    { std::lock_guard<std::mutex> lk(st_->mu); st_->s.sco_open=true; }
    return true;
}
bool HfpAgServer::reject(){
    if(rfcomm_fd_<0) return false;
    { std::lock_guard<std::mutex> lk(st_->mu);
      if(st_->s.call_state!=CALL_INCOMING) return false;
      st_->s.call_state=CALL_IDLE; st_->s.ind_call=0; st_->s.ind_callsetup=0; }
    send_ciev("callsetup",0);
    send_line("NO CARRIER");
    return true;
}
bool HfpAgServer::hangup(){
    if(rfcomm_fd_<0) return false;
    { std::lock_guard<std::mutex> lk(st_->mu);
      st_->s.call_state=CALL_IDLE; st_->s.ind_call=0; st_->s.ind_callsetup=0; st_->s.sco_open=false; }
    send_ciev("call",0);
    send_ciev("callsetup",0);
    on_sco_stop_();
    return true;
}
void HfpAgServer::set_spk_gain(int v){
    v=std::max(0,std::min(15,v));
    { std::lock_guard<std::mutex> lk(st_->mu); st_->s.spk_gain=v; }
    char s[32]; std::snprintf(s,sizeof(s),"+VGS: %d",v);
    send_line(s);
}
void HfpAgServer::set_mic_gain(int v){
    v=std::max(0,std::min(15,v));
    { std::lock_guard<std::mutex> lk(st_->mu); st_->s.mic_gain=v; }
    char s[32]; std::snprintf(s,sizeof(s),"+VGM: %d",v);
    send_line(s);
}
