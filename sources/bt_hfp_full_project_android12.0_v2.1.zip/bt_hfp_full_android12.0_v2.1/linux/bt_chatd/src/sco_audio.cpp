#include "sco_audio.hpp"
#include "log.hpp"
#include <alsa/asoundlib.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/sco.h>
#include <sys/socket.h>
#include <unistd.h>
#include <cstring>

static bool alsa_open_pcm(snd_pcm_t** out, const char* dev, snd_pcm_stream_t stream){
    snd_pcm_t* h=nullptr;
    if(snd_pcm_open(&h, dev, stream, 0)<0) return false;
    snd_pcm_hw_params_t* hw=nullptr; snd_pcm_hw_params_alloca(&hw);
    snd_pcm_hw_params_any(h, hw);
    snd_pcm_hw_params_set_access(h, hw, SND_PCM_ACCESS_RW_INTERLEAVED);
    snd_pcm_hw_params_set_format(h, hw, SND_PCM_FORMAT_S16_LE);
    unsigned int rate=8000;
    snd_pcm_hw_params_set_rate_near(h, hw, &rate, nullptr);
    snd_pcm_hw_params_set_channels(h, hw, 1);
    snd_pcm_uframes_t period=160;
    snd_pcm_hw_params_set_period_size_near(h, hw, &period, nullptr);
    if(snd_pcm_hw_params(h, hw)<0){ snd_pcm_close(h); return false; }
    snd_pcm_prepare(h);
    *out=h;
    return true;
}

ScoAudioBridge::ScoAudioBridge(){}
ScoAudioBridge::~ScoAudioBridge(){ stop(); }

bool ScoAudioBridge::start(const std::string& remote_mac,const std::string& pcm_capture_dev,const std::string& pcm_playback_dev){
    stop();
    remote_mac_=remote_mac; cap_dev_=pcm_capture_dev; pb_dev_=pcm_playback_dev;
    if(!open_alsa()){ loge("ALSA open failed"); close_alsa(); return false; }
    if(!open_sco()){ loge("SCO open failed"); close_sco(); close_alsa(); return false; }
    cvsd_tx_.reset(); cvsd_rx_.reset();
    running_=true;
    th_tx_=std::thread(&ScoAudioBridge::thread_tx, this);
    th_rx_=std::thread(&ScoAudioBridge::thread_rx, this);
    logi("SCO audio started with %s", remote_mac_.c_str());
    return true;
}

void ScoAudioBridge::stop(){
    running_=false;
    if(sco_fd_>=0) ::shutdown(sco_fd_, SHUT_RDWR);
    if(th_tx_.joinable()) th_tx_.join();
    if(th_rx_.joinable()) th_rx_.join();
    close_sco(); close_alsa();
}

bool ScoAudioBridge::open_alsa(){
    snd_pcm_t* cap=nullptr; snd_pcm_t* pb=nullptr;
    if(!alsa_open_pcm(&cap, cap_dev_.c_str(), SND_PCM_STREAM_CAPTURE)) return false;
    if(!alsa_open_pcm(&pb, pb_dev_.c_str(), SND_PCM_STREAM_PLAYBACK)){ snd_pcm_close(cap); return false; }
    cap_handle_=cap; pb_handle_=pb; return true;
}
void ScoAudioBridge::close_alsa(){
    if(cap_handle_){ snd_pcm_close((snd_pcm_t*)cap_handle_); cap_handle_=nullptr; }
    if(pb_handle_){ snd_pcm_close((snd_pcm_t*)pb_handle_); pb_handle_=nullptr; }
}
bool ScoAudioBridge::open_sco(){
    sco_fd_=::socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_SCO);
    if(sco_fd_<0) return false;
    sockaddr_sco addr{}; addr.sco_family=AF_BLUETOOTH;
    bacpy(&addr.sco_bdaddr, BDADDR_ANY);
    if(::bind(sco_fd_, (sockaddr*)&addr, sizeof(addr))<0){ ::close(sco_fd_); sco_fd_=-1; return false; }
    sockaddr_sco r{}; r.sco_family=AF_BLUETOOTH;
    if(str2ba(remote_mac_.c_str(), &r.sco_bdaddr)<0){ ::close(sco_fd_); sco_fd_=-1; return false; }
    if(::connect(sco_fd_, (sockaddr*)&r, sizeof(r))<0){ ::close(sco_fd_); sco_fd_=-1; return false; }
    return true;
}
void ScoAudioBridge::close_sco(){ if(sco_fd_>=0){ ::close(sco_fd_); sco_fd_=-1; } }

void ScoAudioBridge::thread_tx(){
    snd_pcm_t* cap=(snd_pcm_t*)cap_handle_;
    if(!cap) return;
    const size_t pcm_samples=160;
    int16_t pcm[pcm_samples];
    uint8_t cvsd[160];
    while(running_){
        snd_pcm_sframes_t got=snd_pcm_readi(cap, pcm, pcm_samples);
        if(got<0){ snd_pcm_recover(cap, (int)got, 1); continue; }
        size_t wrote=cvsd_tx_.encode_pcm16_to_cvsd(pcm, (size_t)got, cvsd, sizeof(cvsd));
        if(!wrote) continue;
        if(::send(sco_fd_, cvsd, wrote, 0)<=0) break;
    }
}
void ScoAudioBridge::thread_rx(){
    snd_pcm_t* pb=(snd_pcm_t*)pb_handle_;
    if(!pb) return;
    uint8_t cvsd[240];
    int16_t pcm[512];
    while(running_){
        ssize_t n=::recv(sco_fd_, cvsd, sizeof(cvsd), 0);
        if(n<=0) break;
        size_t samples=cvsd_rx_.decode_cvsd_to_pcm16(cvsd, (size_t)n, pcm, sizeof(pcm)/sizeof(pcm[0]));
        if(!samples) continue;
        snd_pcm_sframes_t put=snd_pcm_writei(pb, pcm, (snd_pcm_uframes_t)samples);
        if(put<0) snd_pcm_recover(pb, (int)put, 1);
    }
}
