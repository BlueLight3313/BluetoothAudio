
#include <stdio.h>

int agent_register()
{
    printf("Register pairing agent (Agent1)\n");
    return 0;
}
