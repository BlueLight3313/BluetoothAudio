
#include <stdio.h>
#include <string.h>

#define MAX_DEVICES 8

static char devices[MAX_DEVICES][18];
static int count=0;

void device_add(const char* mac)
{
    if(count>=MAX_DEVICES) return;
    strcpy(devices[count++],mac);
    printf("Stored device %s\n",mac);
}

int device_count()
{
    return count;
}
