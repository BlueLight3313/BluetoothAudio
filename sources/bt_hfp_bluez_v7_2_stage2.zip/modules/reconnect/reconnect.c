
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

extern int device_connect(const char*);

static char device[128];
static pthread_t thread;

static void* loop(void* p)
{
    while(1)
    {
        printf("Reconnect attempt\n");
        device_connect(device);
        sleep(5);
    }
}

void reconnect_start(const char* path)
{
    strcpy(device,path);
    pthread_create(&thread,NULL,loop,NULL);
}
