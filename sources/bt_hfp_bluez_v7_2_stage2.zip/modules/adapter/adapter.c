
#include "dbus_core.h"
#include <stdio.h>

int adapter_start_scan()
{
    printf("BlueZ StartDiscovery\n");
    return dbus_call("/org/bluez/hci0","org.bluez.Adapter1","StartDiscovery");
}

int adapter_stop_scan()
{
    printf("BlueZ StopDiscovery\n");
    return dbus_call("/org/bluez/hci0","org.bluez.Adapter1","StopDiscovery");
}
