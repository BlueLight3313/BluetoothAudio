
#pragma once
#include <dbus/dbus.h>

int dbus_core_init();
void dbus_core_loop();
DBusConnection* dbus_core_conn();
int dbus_call(const char* path,const char* iface,const char* method);
