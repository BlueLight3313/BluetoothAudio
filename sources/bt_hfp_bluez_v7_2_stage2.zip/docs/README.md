
Stage2 BlueZ Control

Implements:
- scan
- pair
- connect
- disconnect
- reconnect loop

Build:
cd jni
ndk-build
