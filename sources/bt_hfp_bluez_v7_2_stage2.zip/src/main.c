
#include <stdio.h>

int dbus_core_init();
void dbus_core_loop();

int adapter_start_scan();
int device_pair(const char*);
int device_connect(const char*);

int main()
{
    printf("Bluetooth Chat Stage2 (BlueZ device control)\n");

    if(dbus_core_init()!=0)
        return -1;

    adapter_start_scan();

    dbus_core_loop();

    return 0;
}
