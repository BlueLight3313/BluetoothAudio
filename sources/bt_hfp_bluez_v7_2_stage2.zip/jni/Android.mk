
LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := bt_chatd

LOCAL_SRC_FILES := ../src/main.c ../core/dbus_core.c ../modules/adapter/adapter.c ../modules/agent/agent.c ../modules/device/device_db.c ../modules/connect/connect.c ../modules/reconnect/reconnect.c

LOCAL_C_INCLUDES := ../include

LOCAL_LDLIBS := -ldbus-1 -lpthread

include $(BUILD_EXECUTABLE)
