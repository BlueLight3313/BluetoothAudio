
#include "dbus_conn.h"
#include <stdio.h>

static DBusConnection *conn;

int dbus_init()
{
    DBusError err;
    dbus_error_init(&err);

    conn = dbus_bus_get(DBUS_BUS_SYSTEM, &err);

    if (dbus_error_is_set(&err))
    {
        printf("DBus error: %s\n", err.message);
        dbus_error_free(&err);
        return -1;
    }

    if (!conn)
        return -1;

    printf("Connected to system DBus\n");
    return 0;
}

void dbus_event_loop()
{
    while (1)
        dbus_connection_read_write_dispatch(conn, 1000);
}

DBusConnection* dbus_get()
{
    return conn;
}
