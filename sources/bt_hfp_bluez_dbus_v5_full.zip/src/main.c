
#include <stdio.h>
#include "dbus_conn.h"
#include "scan.h"
#include "pair.h"
#include "hfp_chat.h"
#include "map_sms.h"

int main()
{
    printf("bt_chatd BlueZ/DBus v5.0\n");

    if (dbus_init() != 0)
        return -1;

    scan_init();
    pair_init();
    hfp_init();
    map_init();

    dbus_event_loop();
    return 0;
}
