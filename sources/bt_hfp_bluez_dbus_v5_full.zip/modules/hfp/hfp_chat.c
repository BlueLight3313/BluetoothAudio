
#include <stdio.h>
#include "hfp_chat.h"

int hfp_init()
{
    printf("HFP module ready\n");
    return 0;
}

int hfp_start_chat()
{
    printf("Start HFP voice chat\n");
    return 0;
}

int hfp_stop_chat()
{
    printf("Stop HFP voice chat\n");
    return 0;
}
