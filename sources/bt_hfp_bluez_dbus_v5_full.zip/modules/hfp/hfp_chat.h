
#pragma once
int hfp_init();
int hfp_start_chat();
int hfp_stop_chat();
