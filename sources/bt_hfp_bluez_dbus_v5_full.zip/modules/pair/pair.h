
#pragma once
int pair_init();
int pair_device(const char *mac);
