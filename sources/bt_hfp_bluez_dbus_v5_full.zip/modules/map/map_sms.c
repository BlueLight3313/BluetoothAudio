
#include <stdio.h>
#include "map_sms.h"

int map_init()
{
    printf("MAP module ready\n");
    return 0;
}

int map_send_sms(const char *msg)
{
    printf("Send SMS: %s\n", msg);
    return 0;
}
