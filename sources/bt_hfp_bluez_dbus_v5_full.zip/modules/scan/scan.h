
#pragma once
int scan_init();
int scan_start();
int scan_stop();
