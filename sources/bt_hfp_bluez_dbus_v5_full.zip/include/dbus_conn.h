
#pragma once
#include <dbus/dbus.h>

int dbus_init();
void dbus_event_loop();
DBusConnection* dbus_get();
