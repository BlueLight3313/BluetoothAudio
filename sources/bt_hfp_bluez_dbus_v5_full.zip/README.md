
Bluetooth Voice Chat Project v5 BlueZ/DBus

Features

Scan
Pair
Connect
Auto reconnect
Voice chat
SMS via MAP

Build

sudo apt install bluez libdbus-1-dev
make

Run

sudo ./bt_chatd
