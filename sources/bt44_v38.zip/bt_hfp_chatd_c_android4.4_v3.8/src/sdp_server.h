#pragma once
#ifdef __cplusplus
extern "C" {
#endif

typedef struct sdp_server sdp_server_t;

// Minimal SDP server advertising HFP Audio Gateway (UUID 0x111F) on a given RFCOMM channel.
// Many headsets require this discovery step before opening RFCOMM/HFP and enabling SCO.
sdp_server_t* sdp_server_start(int rfcomm_channel);
void sdp_server_stop(sdp_server_t* s);

#ifdef __cplusplus
}
#endif
