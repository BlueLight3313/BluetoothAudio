#include "sdp_server.h"
#include "l2cap.h"
#include "bt_util.h"
#include "log.h"

#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define SDP_PSM 0x0001

#define SDP_PDU_SERVICE_SEARCH_REQ            0x02
#define SDP_PDU_SERVICE_SEARCH_RSP            0x03
#define SDP_PDU_SERVICE_ATTRIBUTE_REQ         0x04
#define SDP_PDU_SERVICE_ATTRIBUTE_RSP         0x05
#define SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_REQ  0x06
#define SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_RSP  0x07

struct sdp_server {
    int fd;
    int rfcomm_ch;
    pthread_t th;
    volatile int running;
};

static void be16_put(unsigned char* p, unsigned short v){ p[0]=(unsigned char)(v>>8); p[1]=(unsigned char)(v&0xFF); }
static unsigned short be16_get(const unsigned char* p){ return (unsigned short)((p[0]<<8)|p[1]); }

typedef struct { unsigned short lo, hi; } attr_range_t;

static int range_match(unsigned short id, const attr_range_t* rs, int n){
    for(int i=0;i<n;i++){
        if(id >= rs[i].lo && id <= rs[i].hi) return 1;
    }
    return 0;
}

// Parse AttributeIDList (DataElementSequence) into up to max ranges.
// Each element is either:
// - uint16 attrId, or
// - uint32 where high16=start, low16=end
static int parse_attr_id_list(const unsigned char* p, const unsigned char* end, attr_range_t* out, int max_out, const unsigned char** after){
    if(p>=end) return -1;
    if(*p++ != 0x35) return -1; // seq with 8-bit len
    if(p>=end) return -1;
    unsigned int len=*p++;
    if(p+len > end) return -1;
    const unsigned char* q=p;
    const unsigned char* qend=p+len;

    int n=0;
    while(q<qend && n<max_out){
        unsigned char de=*q++;
        if(de==0x09){ // uint16
            if(q+2>qend) break;
            unsigned short id=be16_get(q); q+=2;
            out[n].lo=id; out[n].hi=id; n++;
        } else if(de==0x0A){ // uint32 range
            if(q+4>qend) break;
            unsigned short lo=be16_get(q); unsigned short hi=be16_get(q+2);
            q+=4;
            out[n].lo=lo; out[n].hi=hi; n++;
        } else {
            break;
        }
    }

    if(after) *after = qend;
    return n;
}

// Build full attribute entries into tmp; optionally filter by requested ranges.
static int build_attr_entries(unsigned char* tmp, int cap, int rfcomm_ch, const attr_range_t* req, int req_n){
    unsigned char* t=tmp;
    unsigned char* end=tmp+cap;

    #define NEED(n) do{ if(t+(n)>end) return -1; }while(0)
    #define PUT8(v) do{ *t++=(unsigned char)(v); }while(0)
    #define PUT16(v) do{ unsigned short _v=(unsigned short)(v); PUT8(_v>>8); PUT8(_v&0xFF); }while(0)
    #define ATTR_U32(id,u32) do{ \
        if(req && !range_match((unsigned short)(id), req, req_n)) break; \
        NEED(3+5); PUT8(0x09); PUT16(id); PUT8(0x0A); PUT8(((u32)>>24)&0xFF); PUT8(((u32)>>16)&0xFF); PUT8(((u32)>>8)&0xFF); PUT8((u32)&0xFF); \
    }while(0)
    #define ATTR_U16(id,u16) do{ \
        if(req && !range_match((unsigned short)(id), req, req_n)) break; \
        NEED(3+3); PUT8(0x09); PUT16(id); PUT8(0x09); PUT16(u16); \
    }while(0)
    #define ATTR_STR(id,str) do{ \
        if(req && !range_match((unsigned short)(id), req, req_n)) break; \
        const char* s=(str); int L=(int)strlen(s); if(L>255) L=255; \
        NEED(3+2+L); PUT8(0x09); PUT16(id); PUT8(0x25); PUT8(L); memcpy(t,s,(size_t)L); t+=L; \
    }while(0)

    // 0x0000 ServiceRecordHandle
    ATTR_U32(0x0000, 0x00010001);

    // 0x0001 ServiceClassIDList = seq(uuid16 0x111F)
    if(!req || range_match(0x0001, req, req_n)){
        NEED(3+2+3);
        PUT8(0x09); PUT16(0x0001);
        PUT8(0x35); PUT8(0x03);
        PUT8(0x19); PUT16(0x111F);
    }

    // 0x0004 ProtocolDescriptorList
    if(!req || range_match(0x0004, req, req_n)){
        NEED(3+2+0x11);
        PUT8(0x09); PUT16(0x0004);
        PUT8(0x35); PUT8(0x11);
          PUT8(0x35); PUT8(0x06);
            PUT8(0x19); PUT16(0x0100);
            PUT8(0x09); PUT16(0x0003);
          PUT8(0x35); PUT8(0x05);
            PUT8(0x19); PUT16(0x0003);
            PUT8(0x08); PUT8(rfcomm_ch);
    }

    // 0x0005 BrowseGroupList
    if(!req || range_match(0x0005, req, req_n)){
        NEED(3+2+3);
        PUT8(0x09); PUT16(0x0005);
        PUT8(0x35); PUT8(0x03);
        PUT8(0x19); PUT16(0x1002);
    }

    // 0x0006 LanguageBaseAttributeIDList
    if(!req || range_match(0x0006, req, req_n)){
        NEED(3+2+9);
        PUT8(0x09); PUT16(0x0006);
        PUT8(0x35); PUT8(0x09);
        PUT8(0x09); PUT16(0x656E);
        PUT8(0x09); PUT16(0x006A);
        PUT8(0x09); PUT16(0x0100);
    }

    // 0x0009 BluetoothProfileDescriptorList
    if(!req || range_match(0x0009, req, req_n)){
        NEED(3+2+0x0A);
        PUT8(0x09); PUT16(0x0009);
        PUT8(0x35); PUT8(0x0A);
          PUT8(0x35); PUT8(0x08);
            PUT8(0x19); PUT16(0x111E);
            PUT8(0x09); PUT16(0x0107);
    }

    // 0x0100 ServiceName
    ATTR_STR(0x0100, "HFP AG");

    // 0x0311 SupportedFeatures
    ATTR_U16(0x0311, 0x0001);

    return (int)(t - tmp);
}

static int build_attr_list_seq(unsigned char* out, int cap, int rfcomm_ch, const attr_range_t* req, int req_n){
    unsigned char tmp[512];
    int entries = build_attr_entries(tmp, (int)sizeof(tmp), rfcomm_ch, req, req_n);
    if(entries < 0) return -1;
    if(entries > 255) return -1;
    if(2 + entries > cap) return -1;
    out[0]=0x35;
    out[1]=(unsigned char)entries;
    memcpy(out+2, tmp, (size_t)entries);
    return 2 + entries;
}

static void send_search_rsp(int cfd, unsigned short tid, unsigned short max_handles, unsigned char cont_in){
    (void)max_handles;
    unsigned int handle=0x00010001;
    unsigned short total=1;
    unsigned short count=(cont_in==0)?1:0;

    unsigned char rsp[64];
    unsigned char* q=rsp;
    *q++=SDP_PDU_SERVICE_SEARCH_RSP;
    be16_put(q,tid); q+=2;
    unsigned char* plen=q; q+=2;

    be16_put(q,total); q+=2;
    be16_put(q,count); q+=2;
    if(count==1){
        *q++=(handle>>24)&0xFF;
        *q++=(handle>>16)&0xFF;
        *q++=(handle>>8)&0xFF;
        *q++=(handle)&0xFF;
    }
    *q++=0x00; // no continuation
    be16_put(plen,(unsigned short)(q-(plen+2)));
    (void)send(cfd,rsp,(size_t)(q-rsp),0);
}

static void send_attr_pdu(int cfd, unsigned char pdu, unsigned short tid,
                          const unsigned char* attr_list, int attr_len,
                          unsigned short max_attr_bytes, unsigned char cont_token){
    int offset=(int)cont_token;
    if(offset<0) offset=0;
    if(offset>attr_len) offset=attr_len;

    int remaining=attr_len-offset;
    int send_bytes=remaining;
    if(send_bytes>(int)max_attr_bytes) send_bytes=(int)max_attr_bytes;

    unsigned char next_token=0;
    if(offset+send_bytes < attr_len) next_token=(unsigned char)(offset+send_bytes);

    unsigned char rsp[1024];
    unsigned char* q=rsp;
    *q++=pdu;
    be16_put(q,tid); q+=2;
    unsigned char* plen=q; q+=2;

    be16_put(q,(unsigned short)attr_len); q+=2;
    memcpy(q, attr_list+offset, (size_t)send_bytes); q+=send_bytes;

    if(next_token!=0){
        *q++=0x01; *q++=next_token;
    } else {
        *q++=0x00;
    }

    be16_put(plen,(unsigned short)(q-(plen+2)));
    (void)send(cfd,rsp,(size_t)(q-rsp),0);
}

// Skip a sequence DataElement (0x35 len8)
static int skip_seq(const unsigned char** pp, const unsigned char* end){
    const unsigned char* p=*pp;
    if(p+2>end) return -1;
    if(*p++ != 0x35) return -1;
    unsigned int len=*p++;
    if(p+len > end) return -1;
    *pp = p+len;
    return 0;
}

static void* th_main(void* arg){
    struct sdp_server* s=(struct sdp_server*)arg;

    while(s->running){
        int cfd=accept(s->fd,NULL,NULL);
        if(cfd<0){
            if(errno==EINTR) continue;
            usleep(50*1000);
            continue;
        }

        unsigned char reqbuf[1024];
        ssize_t n=recv(cfd,reqbuf,sizeof(reqbuf),0);
        if(n<5){ close(cfd); continue; }

        unsigned char pdu=reqbuf[0];
        unsigned short tid=be16_get(reqbuf+1);
        unsigned short plen=be16_get(reqbuf+3);
        if((int)plen+5 > (int)n){ close(cfd); continue; }

        const unsigned char* p=reqbuf+5;
        const unsigned char* end=reqbuf+5+plen;

        if(pdu==SDP_PDU_SERVICE_SEARCH_REQ){
            // SearchPattern(seq) + MaxRecCount + Continuation
            if(skip_seq(&p,end)<0){ close(cfd); continue; }
            if(p+2>end){ close(cfd); continue; }
            unsigned short max_rc=be16_get(p); p+=2;
            unsigned char cont_len=0, cont_token=0;
            if(p<end){
                cont_len=*p++;
                if(cont_len==1 && p<end) cont_token=*p++;
            }
            (void)max_rc;
            send_search_rsp(cfd,tid,max_rc,cont_token);
            close(cfd); continue;
        }

        if(pdu==SDP_PDU_SERVICE_ATTRIBUTE_REQ){
            // handle(u32) + maxAttr(u16) + attrIdList(seq) + cont
            if(p+4>end){ close(cfd); continue; }
            p+=4;
            if(p+2>end){ close(cfd); continue; }
            unsigned short max_attr=be16_get(p); p+=2;

            attr_range_t ranges[16];
            int rn=parse_attr_id_list(p,end,ranges,16,&p);
            if(rn<0){ close(cfd); continue; }

            unsigned char cont_len=0, cont_token=0;
            if(p<end){
                cont_len=*p++;
                if(cont_len==1 && p<end) cont_token=*p++;
            }

            unsigned char attr_list[512];
            int attr_len=build_attr_list_seq(attr_list,(int)sizeof(attr_list),s->rfcomm_ch,ranges,rn);
            if(attr_len>0){
                send_attr_pdu(cfd, SDP_PDU_SERVICE_ATTRIBUTE_RSP, tid, attr_list, attr_len, max_attr, cont_token);
            }
            close(cfd); continue;
        }

        if(pdu==SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_REQ){
            // SearchPattern(seq) + maxAttr(u16) + attrIdList(seq) + cont
            if(skip_seq(&p,end)<0){ close(cfd); continue; }
            if(p+2>end){ close(cfd); continue; }
            unsigned short max_attr=be16_get(p); p+=2;

            attr_range_t ranges[16];
            int rn=parse_attr_id_list(p,end,ranges,16,&p);
            if(rn<0){ close(cfd); continue; }

            unsigned char cont_len=0, cont_token=0;
            if(p<end){
                cont_len=*p++;
                if(cont_len==1 && p<end) cont_token=*p++;
            }

            unsigned char attr_list[512];
            int attr_len=build_attr_list_seq(attr_list,(int)sizeof(attr_list),s->rfcomm_ch,ranges,rn);
            if(attr_len>0){
                send_attr_pdu(cfd, SDP_PDU_SERVICE_SEARCH_ATTRIBUTE_RSP, tid, attr_list, attr_len, max_attr, cont_token);
            }
            close(cfd); continue;
        }

        close(cfd);
    }
    return NULL;
}

sdp_server_t* sdp_server_start(int rfcomm_channel){
    struct sdp_server* s=(struct sdp_server*)calloc(1,sizeof(*s));
    s->rfcomm_ch=rfcomm_channel;

    s->fd = socket(AF_BLUETOOTH, SOCK_SEQPACKET, BTPROTO_L2CAP);
    if(s->fd<0){
        LOGE("SDP socket failed: %s", strerror(errno));
        free(s);
        return NULL;
    }

    struct sockaddr_l2 addr;
    memset(&addr,0,sizeof(addr));
    addr.l2_family=AF_BLUETOOTH;
    addr.l2_psm=htons(SDP_PSM);
    bt_bdaddr_any(&addr.l2_bdaddr);

    if(bind(s->fd,(struct sockaddr*)&addr,sizeof(addr))<0){
        LOGE("SDP bind failed: %s", strerror(errno));
        close(s->fd); free(s);
        return NULL;
    }
    if(listen(s->fd,5)<0){
        LOGE("SDP listen failed: %s", strerror(errno));
        close(s->fd); free(s);
        return NULL;
    }

    s->running=1;
    pthread_create(&s->th,NULL,th_main,s);
    LOGI("SDP server started (HFP AG UUID 0x111F, RFCOMM ch=%d)", rfcomm_channel);
    return (sdp_server_t*)s;
}

void sdp_server_stop(sdp_server_t* s0){
    struct sdp_server* s=(struct sdp_server*)s0;
    if(!s) return;
    s->running=0;
    shutdown(s->fd,SHUT_RDWR);
    pthread_join(s->th,NULL);
    close(s->fd);
    free(s);
}
