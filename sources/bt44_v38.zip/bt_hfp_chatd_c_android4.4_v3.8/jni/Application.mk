APP_ABI := arm64-v8a
APP_PLATFORM := android-19
APP_OPTIM := release
