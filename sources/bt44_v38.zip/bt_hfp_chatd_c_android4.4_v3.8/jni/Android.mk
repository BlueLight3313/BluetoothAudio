LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := bt_chatd

LOCAL_CFLAGS := -O2 -std=c99 -Wall -Wextra -DANDROID -D__ANDROID__=1
LOCAL_C_INCLUDES := \
  $(LOCAL_PATH)/../src \
  $(LOCAL_PATH)/../third_party/linux_uapi_bt

LOCAL_SRC_FILES := \
  ../src/main.c \
  ../src/bt_util.c \
  ../src/cvsd.c \
  ../src/sco_bridge.c \
  ../src/hfp_ag.c \
  ../src/ctrl_server.c \
  ../src/bt_mgmt.c \
  ../src/state_machine.c \
  ../src/sdp_server.c \
  ../src/audio_opensles.c

LOCAL_LDLIBS := -lOpenSLES -llog
LOCAL_LDFLAGS := -fPIE -pie

include $(BUILD_EXECUTABLE)
