# NDK-only build (no CMake) - v3.3.5

This package includes **two** NDK-only build methods (no CMake required).

## Method A: Direct clang build (recommended)
```sh
export ANDROID_NDK=/path/to/android-ndk-r21e
./android_ndk/build_ndk.sh arm64-v8a 19
```
Output:
- android_ndk/out/arm64-v8a/bt_chatd

## Method B: ndk-build (Android.mk)
```sh
export ANDROID_NDK=/path/to/android-ndk-r21e
$ANDROID_NDK/ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk
```
Output:
- libs/arm64-v8a/bt_chatd

## Clean
```sh
./clean.sh
```

## Notes
- OpenSL ES symbols require linking `-lOpenSLES` (already included).
- Includes are simplified: use `#include "bluetooth.h"` etc.
