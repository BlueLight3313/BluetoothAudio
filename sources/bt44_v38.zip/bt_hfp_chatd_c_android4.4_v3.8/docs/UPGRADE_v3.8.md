# Upgrade v3.8: explicit CHAT_START / CHAT_STOP command

## Goal
Make "Bluetooth-only voice chat" usable without manual multi-step commands.

## New commands
### CHAT_START [MAC]
- If MAC is provided: sets it as target and enables AUTO.
- If MAC is omitted: uses current target.
- If RFCOMM is already connected: immediately triggers incoming-call UI (RING/+CLIP) to allow the headset to open SCO.
- If RFCOMM is not connected yet: returns `WAIT_RFCOMM` and the daemon will trigger automatically when RFCOMM connects.

### CHAT_STOP
Stops chat by hanging up (closes SCO) and clears pending chat.

## Implementation details
- `main.c` handles the commands and sets `app_state.chat_pending` and `chat_target`.
- `hfp_ag.c` watches the shared state on RFCOMM connect:
  - If `chat_pending=1` and the connected peer matches `chat_target`, it calls `set_incoming_call()` and clears the pending flag.
- This avoids requiring the user/UI to repeatedly call `DIAL` at the right moment.

Files changed:
- src/main.c
- src/state_machine.h
- src/hfp_ag.c
- src/bt_mgmt.c
