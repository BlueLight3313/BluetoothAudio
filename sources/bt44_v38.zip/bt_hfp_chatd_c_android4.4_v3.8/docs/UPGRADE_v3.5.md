# Upgrade v3.5: headset compatibility for Bluetooth voice chat

## What was added/improved

### 1) SDP advertising for HFP Audio Gateway
File: `src/sdp_server.c/.h`
- Runs an SDP server on L2CAP PSM 0x0001
- Responds to ServiceSearchAttributeRequest (0x06)
- Returns common HFP AG attributes including:
  - ServiceClassIDList (UUID 0x111F)
  - ProtocolDescriptorList (RFCOMM channel 8)
  - ProfileDescriptorList (Handsfree 0x111E, v1.7)
  - ServiceName, BrowseGroupList, Language list
- Implements minimal ContinuationState (1-byte offset) so clients with small max byte count still succeed.

### 2) More compatible "fake call" state machine (chat mode)
File: `src/hfp_ag.c`
- Maintains indicators: service/call/callsetup/callheld
- Sends +CIEV updates after CMER and during transitions
- Supports:
  - ATA (answer)
  - ATD... (dial)
  - AT+CHUP (hangup)
  - AT+CLCC (call list)
  - AT+VGS/AT+VGM (volume gain)
- `DIAL <MAC>` now triggers an incoming-call UI on the headset (RING/+CLIP) when RFCOMM is connected.
  The headset can press answer (ATA) -> SCO starts -> audio chat begins.

## Why
Many headsets will not open RFCOMM/HFP or enable SCO until:
- They discover a valid HFP AG service via SDP, and
- They observe reasonable HFP call-state/indicator behavior.

This upgrade targets those requirements while keeping everything pure C and daemon-based.
