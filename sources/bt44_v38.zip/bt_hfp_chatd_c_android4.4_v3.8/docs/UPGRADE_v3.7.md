# Upgrade v3.7: SDP attribute-range filtering + HFP timing improvements

## 1) SDP attribute-range filtering
Some headset SDP clients request specific attribute IDs/ranges and may fail if the server returns unrelated attributes.
v3.7 parses `AttributeIDList` and returns only requested attributes.

Also supports:
- ServiceSearchRequest (0x02)
- ServiceAttributeRequest (0x04)
- ServiceSearchAttributeRequest (0x06)
with continuation support.

File:
- src/sdp_server.c

## 2) HFP timing improvements
Some headsets require:
- a short delay between RING/+CLIP and indicator updates (+CIEV)
- repeated RING notifications while the call is incoming

v3.7 adds:
- a small delay before sending +CIEV after initial RING
- a ring thread that repeats RING/+CLIP every ~3s while incoming

File:
- src/hfp_ag.c
