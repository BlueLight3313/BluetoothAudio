#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
echo "Cleaning build artifacts under: $ROOT"
rm -rf "$ROOT/android_ndk/build" "$ROOT/android_ndk/out" "$ROOT/android_ndk/obj" "$ROOT/build" "$ROOT/libs" "$ROOT/obj"
find "$ROOT" -name "CMakeCache.txt" -o -name "CMakeFiles" | while read -r p; do rm -rf "$p"; done
find "$ROOT" -name "*.o" -o -name "*.a" -o -name "*.so" | while read -r p; do rm -f "$p"; done
echo "Done."
