#pragma once
#include <stdint.h>
#include "bluetooth.h"

#ifndef AF_BLUETOOTH
#define AF_BLUETOOTH 31
#endif
#ifndef SOCK_SEQPACKET
#define SOCK_SEQPACKET 5
#endif
#ifndef BTPROTO_L2CAP
#define BTPROTO_L2CAP 0
#endif

// Classic L2CAP sockaddr (kernel UAPI)
struct sockaddr_l2 {
    uint16_t l2_family;
    uint16_t l2_psm;
    bdaddr_t l2_bdaddr;
    uint16_t l2_cid;
    uint8_t  l2_bdaddr_type;
};
