#!/usr/bin/env bash
set -euo pipefail

# Direct NDK build (no CMake, no ndk-build)
# Usage:
#   export ANDROID_NDK=/path/to/android-ndk-r21e
#   ./android_ndk/build_ndk.sh arm64-v8a 19
#   ./android_ndk/build_ndk.sh armeabi-v7a 19

ABI="${1:-arm64-v8a}"
API="${2:-19}"

if [[ -z "${ANDROID_NDK:-}" ]]; then
  echo "ERROR: Set ANDROID_NDK=/path/to/android-ndk-r21e" >&2
  exit 2
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/android_ndk/out/$ABI"
OBJ="$ROOT/android_ndk/obj/$ABI"

rm -rf "$OUT" "$OBJ"
mkdir -p "$OUT" "$OBJ"

case "$ABI" in
  arm64-v8a)   TRIPLE="aarch64-linux-android" ;;
  armeabi-v7a) TRIPLE="armv7a-linux-androideabi" ;;
  x86)         TRIPLE="i686-linux-android" ;;
  x86_64)      TRIPLE="x86_64-linux-android" ;;
  *) echo "Unknown ABI: $ABI" >&2; exit 2 ;;
esac

TOOL="$ANDROID_NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
CC="$TOOL/${TRIPLE}${API}-clang"

CFLAGS=(
  -O2 -fPIE -fPIC
  -D__ANDROID__=1 -DANDROID
  -std=c99 -Wall -Wextra
  -I"$ROOT/src"
  -I"$ROOT/third_party/linux_uapi_bt"
)

LDFLAGS=( -fPIE -pie -Wl,--gc-sections )

SRCS=(
  "$ROOT/src/main.c"
  "$ROOT/src/bt_util.c"
  "$ROOT/src/cvsd.c"
  "$ROOT/src/sco_bridge.c"
  "$ROOT/src/hfp_ag.c"
  "$ROOT/src/ctrl_server.c"
  "$ROOT/src/bt_mgmt.c"
  "$ROOT/src/state_machine.c"
  "$ROOT/src/msg_store.c"
  "$ROOT/src/map_mse.c"
  "$ROOT/src/sdp_server.c"
  "$ROOT/src/audio_opensles.c"
)

echo "[*] Building ABI=$ABI API=$API"
"$CC" "${CFLAGS[@]}" "${SRCS[@]}" -o "$OUT/bt_chatd" "${LDFLAGS[@]}" -lOpenSLES -llog
echo "[OK] Output: $OUT/bt_chatd"
