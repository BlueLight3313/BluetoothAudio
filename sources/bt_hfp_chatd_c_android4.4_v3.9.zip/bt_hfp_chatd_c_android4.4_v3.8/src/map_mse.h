#pragma once
#include "msg_store.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct map_mse map_mse_t;
map_mse_t* map_mse_start(msg_store_t* store, int rfcomm_channel);
void map_mse_stop(map_mse_t* s);

#ifdef __cplusplus
}
#endif
