#include "map_mse.h"
#include "rfcomm.h"
#include "bt_util.h"
#include "log.h"

#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <stdio.h>

#define MAP_RFCOMM_DEFAULT 17
#define OBEX_OP_CONNECT     0x80
#define OBEX_OP_DISCONNECT  0x81
#define OBEX_OP_PUT         0x02
#define OBEX_OP_GET         0x03
#define OBEX_OP_SETPATH     0x85

#define OBEX_RSP_SUCCESS    0xA0
#define OBEX_RSP_BADREQ     0xC0
#define OBEX_RSP_NOTFOUND   0xC4
#define OBEX_RSP_SERVERR    0xD0

struct map_mse {
    int listen_fd;
    int cli_fd;
    int rfcomm_ch;
    pthread_t th;
    volatile int running;
    msg_store_t* store;
};

static unsigned short be16(const unsigned char* p){ return (unsigned short)((p[0]<<8)|p[1]); }
static void put_be16(unsigned char* p, unsigned short v){ p[0]=(unsigned char)(v>>8); p[1]=(unsigned char)(v&0xFF); }

static int send_simple_rsp(int fd, unsigned char code){
    unsigned char rsp[7];
    rsp[0]=code;
    put_be16(rsp+1, 7);
    rsp[3]=0x10;
    rsp[4]=0x00;
    put_be16(rsp+5, 1024);
    return (int)send(fd, rsp, 7, 0);
}

static int obex_send_body_rsp(int fd, unsigned char code, const char* body){
    unsigned char rsp[4096];
    int body_len = body ? (int)strlen(body) : 0;
    if(body_len > (int)sizeof(rsp)-16) body_len = (int)sizeof(rsp)-16;
    rsp[0]=code;
    unsigned short pkt_len = (unsigned short)(3 + (body_len ? 3 + body_len : 0));
    put_be16(rsp+1, pkt_len);
    int n=3;
    if(body_len){
        rsp[n++] = 0x49;
        put_be16(rsp+n, (unsigned short)(3 + body_len)); n+=2;
        memcpy(rsp+n, body, (size_t)body_len); n+=body_len;
    }
    return (int)send(fd, rsp, (size_t)n, 0);
}

static void parse_obex_headers(const unsigned char* p, int len, char* type, int type_sz, char* name, int name_sz){
    int i=0;
    if(type && type_sz>0) type[0]=0;
    if(name && name_sz>0) name[0]=0;
    while(i < len){
        unsigned char hi = p[i++];
        if((hi & 0xC0) == 0x00 || (hi & 0xC0) == 0x40){
            if(i+2 > len) break;
            unsigned short hlen = be16(p+i); i+=2;
            if(hlen < 3 || i + (hlen-3) > len) break;
            const unsigned char* data = p+i;
            int dlen = hlen - 3;
            if(hi == 0x42 && type && type_sz>0){
                int cpy = dlen;
                if(cpy > type_sz-1) cpy = type_sz-1;
                memcpy(type, data, (size_t)cpy);
                type[cpy]=0;
                while(cpy>0 && type[cpy-1]==0){ type[--cpy]=0; }
            } else if(hi == 0x01 && name && name_sz>0){
                int o=0;
                for(int j=0; j+1<dlen && o<name_sz-1; j+=2){
                    unsigned char c = data[j+1];
                    if(c==0) break;
                    name[o++] = (char)c;
                }
                name[o]=0;
            }
            i += dlen;
        } else if((hi & 0xC0) == 0x80){
            if(i+1 > len) break;
            i += 1;
        } else {
            if(i+4 > len) break;
            i += 4;
        }
    }
}

static void* th_main(void* arg){
    struct map_mse* s=(struct map_mse*)arg;
    while(s->running){
        struct sockaddr_rc rem;
        socklen_t slen=sizeof(rem);
        int fd=accept(s->listen_fd, (struct sockaddr*)&rem, &slen);
        if(fd<0){
            if(errno==EINTR) continue;
            usleep(50*1000);
            continue;
        }
        s->cli_fd = fd;
        char mac[18]={0};
        bt_format_mac(&rem.rc_bdaddr, mac);
        LOGI("MAP MSE RFCOMM connected %s", mac);

        while(s->running){
            unsigned char req[4096];
            ssize_t nr = recv(fd, req, sizeof(req), 0);
            if(nr <= 0) break;
            if(nr < 3) break;
            unsigned char op = req[0];
            unsigned short pkt_len = be16(req+1);
            if(pkt_len > nr) pkt_len = (unsigned short)nr;
            const unsigned char* hdr = req + 3;
            int hdr_len = pkt_len - 3;

            if(op == OBEX_OP_CONNECT){
                send_simple_rsp(fd, OBEX_RSP_SUCCESS);
                continue;
            }
            if(op == OBEX_OP_DISCONNECT){
                send_simple_rsp(fd, OBEX_RSP_SUCCESS);
                break;
            }
            if(op == OBEX_OP_SETPATH){
                send_simple_rsp(fd, OBEX_RSP_SUCCESS);
                continue;
            }
            if((op & 0x7F) == OBEX_OP_GET){
                char type[128], name[128];
                parse_obex_headers(hdr, hdr_len, type, sizeof(type), name, sizeof(name));

                if(strcmp(type, "x-obex/folder-listing")==0){
                    const char* xml =
                        "<?xml version=\"1.0\"?>\n"
                        "<folder-listing version=\"1.0\">\n"
                        "  <folder name=\"telecom\"/>\n"
                        "</folder-listing>\n";
                    obex_send_body_rsp(fd, OBEX_RSP_SUCCESS, xml);
                    continue;
                }
                if(strcmp(type, "x-bt/MAP-msg-listing")==0){
                    char xml[4096];
                    int n = msg_store_build_listing(s->store, xml, (int)sizeof(xml));
                    if(n < 0) obex_send_body_rsp(fd, OBEX_RSP_SERVERR, NULL);
                    else obex_send_body_rsp(fd, OBEX_RSP_SUCCESS, xml);
                    continue;
                }
                if(strcmp(type, "x-bt/message")==0){
                    char bmsg[4096];
                    int n = msg_store_build_bmessage(s->store, name[0]?name:"00000000", bmsg, (int)sizeof(bmsg));
                    if(n < 0) obex_send_body_rsp(fd, OBEX_RSP_NOTFOUND, NULL);
                    else obex_send_body_rsp(fd, OBEX_RSP_SUCCESS, bmsg);
                    continue;
                }
                obex_send_body_rsp(fd, OBEX_RSP_BADREQ, NULL);
                continue;
            }
            if((op & 0x7F) == OBEX_OP_PUT){
                obex_send_body_rsp(fd, OBEX_RSP_SUCCESS, NULL);
                continue;
            }
            obex_send_body_rsp(fd, OBEX_RSP_BADREQ, NULL);
        }

        LOGI("MAP MSE RFCOMM disconnected");
        close(fd);
        s->cli_fd = -1;
    }
    return NULL;
}

map_mse_t* map_mse_start(msg_store_t* store, int rfcomm_channel){
    struct map_mse* s=(struct map_mse*)calloc(1,sizeof(*s));
    s->store = store;
    s->rfcomm_ch = rfcomm_channel > 0 ? rfcomm_channel : MAP_RFCOMM_DEFAULT;
    s->listen_fd = socket(AF_BLUETOOTH, SOCK_STREAM, BTPROTO_RFCOMM);
    if(s->listen_fd < 0){
        free(s);
        return NULL;
    }
    struct sockaddr_rc loc;
    memset(&loc,0,sizeof(loc));
    loc.rc_family = AF_BLUETOOTH;
    bt_bdaddr_any(&loc.rc_bdaddr);
    loc.rc_channel = (unsigned char)s->rfcomm_ch;
    if(bind(s->listen_fd, (struct sockaddr*)&loc, sizeof(loc)) < 0){
        close(s->listen_fd);
        free(s);
        return NULL;
    }
    if(listen(s->listen_fd, 1) < 0){
        close(s->listen_fd);
        free(s);
        return NULL;
    }
    s->running = 1;
    s->cli_fd = -1;
    pthread_create(&s->th, NULL, th_main, s);
    LOGI("MAP MSE started ch %d", s->rfcomm_ch);
    return (map_mse_t*)s;
}

void map_mse_stop(map_mse_t* s0){
    struct map_mse* s=(struct map_mse*)s0;
    if(!s) return;
    s->running = 0;
    shutdown(s->listen_fd, SHUT_RDWR);
    pthread_join(s->th, NULL);
    if(s->cli_fd >= 0) close(s->cli_fd);
    close(s->listen_fd);
    free(s);
}
