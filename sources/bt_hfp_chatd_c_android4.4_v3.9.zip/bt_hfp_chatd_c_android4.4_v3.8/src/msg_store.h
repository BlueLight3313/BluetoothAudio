#pragma once
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define MSG_STORE_MAX_TEXT   256
#define MSG_STORE_MAX_ITEMS  32

typedef struct msg_item {
    char handle[16];
    char text[MSG_STORE_MAX_TEXT];
    int unread;
    unsigned int ts;
} msg_item_t;

typedef struct msg_store msg_store_t;

msg_store_t* msg_store_create(void);
void msg_store_destroy(msg_store_t* s);
int msg_store_add(msg_store_t* s, const char* text);
void msg_store_clear(msg_store_t* s);
int msg_store_build_listing(msg_store_t* s, char* out, int out_sz);
int msg_store_build_bmessage(msg_store_t* s, const char* handle, char* out, int out_sz);
int msg_store_debug_list(msg_store_t* s, char* out, int out_sz);

#ifdef __cplusplus
}
#endif
