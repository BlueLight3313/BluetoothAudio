#include "msg_store.h"
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

struct msg_store {
    pthread_mutex_t mu;
    msg_item_t items[MSG_STORE_MAX_ITEMS];
    int count;
    unsigned int next_id;
};

msg_store_t* msg_store_create(void){
    struct msg_store* s=(struct msg_store*)calloc(1,sizeof(*s));
    pthread_mutex_init(&s->mu, NULL);
    s->next_id = 1;
    return (msg_store_t*)s;
}

void msg_store_destroy(msg_store_t* s0){
    struct msg_store* s=(struct msg_store*)s0;
    if(!s) return;
    pthread_mutex_destroy(&s->mu);
    free(s);
}

int msg_store_add(msg_store_t* s0, const char* text){
    struct msg_store* s=(struct msg_store*)s0;
    if(!s || !text) return -1;
    pthread_mutex_lock(&s->mu);

    int idx;
    if(s->count < MSG_STORE_MAX_ITEMS){
        idx = s->count++;
    } else {
        memmove(&s->items[0], &s->items[1], sizeof(s->items[0]) * (MSG_STORE_MAX_ITEMS - 1));
        idx = MSG_STORE_MAX_ITEMS - 1;
    }

    msg_item_t* it=&s->items[idx];
    snprintf(it->handle, sizeof(it->handle), "%08u", s->next_id++);
    snprintf(it->text, sizeof(it->text), "%s", text);
    it->unread = 1;
    it->ts = (unsigned int)time(NULL);

    pthread_mutex_unlock(&s->mu);
    return 0;
}

void msg_store_clear(msg_store_t* s0){
    struct msg_store* s=(struct msg_store*)s0;
    if(!s) return;
    pthread_mutex_lock(&s->mu);
    memset(s->items, 0, sizeof(s->items));
    s->count = 0;
    pthread_mutex_unlock(&s->mu);
}

int msg_store_build_listing(msg_store_t* s0, char* out, int out_sz){
    struct msg_store* s=(struct msg_store*)s0;
    if(!s || !out || out_sz <= 0) return -1;
    pthread_mutex_lock(&s->mu);
    int n=0;
    n += snprintf(out+n, out_sz-n, "<?xml version=\"1.0\"?>\n<MAP-msg-listing version=\"1.0\">\n");
    for(int i=s->count-1; i>=0 && n < out_sz; --i){
        msg_item_t* it=&s->items[i];
        n += snprintf(out+n, out_sz-n,
            "  <msg handle=\"%s\" subject=\"%.32s\" datetime=\"%u\" sender_name=\"device\" sender_addressing=\"device\" recipient_name=\"headset\" recipient_addressing=\"headset\" type=\"SMS_GSM\" size=\"%u\" text=\"yes\" reception_status=\"complete\" attachment_size=\"0\" priority=\"no\" read=\"%s\" sent=\"no\" protected=\"no\"/>\n",
            it->handle, it->text, it->ts, (unsigned)strlen(it->text), it->unread ? "no" : "yes");
    }
    n += snprintf(out+n, out_sz-n, "</MAP-msg-listing>\n");
    pthread_mutex_unlock(&s->mu);
    if(n >= out_sz) return out_sz-1;
    return n;
}

int msg_store_build_bmessage(msg_store_t* s0, const char* handle, char* out, int out_sz){
    struct msg_store* s=(struct msg_store*)s0;
    if(!s || !handle || !out || out_sz <= 0) return -1;
    pthread_mutex_lock(&s->mu);
    msg_item_t* found = NULL;
    for(int i=0;i<s->count;i++){
        if(strcmp(s->items[i].handle, handle)==0){
            found = &s->items[i];
            break;
        }
    }
    if(!found){
        pthread_mutex_unlock(&s->mu);
        return -1;
    }
    found->unread = 0;
    int n=0;
    n += snprintf(out+n, out_sz-n,
        "BEGIN:BMSG\r\n"
        "VERSION:1.0\r\n"
        "STATUS:UNREAD\r\n"
        "TYPE:SMS_GSM\r\n"
        "FOLDER:telecom/msg/inbox\r\n"
        "BEGIN:VCARD\r\n"
        "VERSION:2.1\r\n"
        "N:device\r\n"
        "TEL:device\r\n"
        "END:VCARD\r\n"
        "BEGIN:BENV\r\n"
        "BEGIN:VCARD\r\n"
        "VERSION:2.1\r\n"
        "N:headset\r\n"
        "TEL:headset\r\n"
        "END:VCARD\r\n"
        "BEGIN:BBODY\r\n"
        "CHARSET:UTF-8\r\n"
        "LENGTH:%u\r\n"
        "BEGIN:MSG\r\n"
        "%s\r\n"
        "END:MSG\r\n"
        "END:BBODY\r\n"
        "END:BENV\r\n"
        "END:BMSG\r\n",
        (unsigned)strlen(found->text), found->text);
    pthread_mutex_unlock(&s->mu);
    if(n >= out_sz) return out_sz-1;
    return n;
}

int msg_store_debug_list(msg_store_t* s0, char* out, int out_sz){
    struct msg_store* s=(struct msg_store*)s0;
    if(!s || !out || out_sz <= 0) return -1;
    pthread_mutex_lock(&s->mu);
    int n=0;
    if(s->count == 0){
        n += snprintf(out+n, out_sz-n, "(empty)");
    } else {
        for(int i=s->count-1; i>=0 && n < out_sz; --i){
            msg_item_t* it=&s->items[i];
            n += snprintf(out+n, out_sz-n, "%s:%s%s", it->handle, it->text, (i==0)?"":" | ");
        }
    }
    pthread_mutex_unlock(&s->mu);
    if(n >= out_sz) return out_sz-1;
    return n;
}
