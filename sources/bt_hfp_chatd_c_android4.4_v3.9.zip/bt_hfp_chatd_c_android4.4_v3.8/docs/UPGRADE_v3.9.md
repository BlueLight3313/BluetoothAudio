# Upgrade v3.9: standard MAP-based message foundation

This version adds a MAP/MSE foundation so the device can expose messages to smart headsets that act as MAP clients.

## Included
- `src/msg_store.c/.h`
  - in-memory message store
  - message listing XML generation
  - bMessage generation
- `src/map_mse.c/.h`
  - minimal MAP Message Server Equipment (MSE)
  - OBEX over RFCOMM listener
  - supports:
    - OBEX CONNECT / DISCONNECT
    - GET folder listing
    - GET MAP message listing
    - GET single message by handle

## New commands
- `MSG_SEND <text>`
- `MSG_LIST`
- `MSG_CLEAR`

## Important limitation
This is a MAP foundation, not a full production MAP stack yet.
It does not claim complete interoperability with every smart headset because standard MAP often also needs:
- fuller MAS SDP advertisement details
- app-parameter filters
- notification registration / MNS callbacks
- vendor-specific behavior
