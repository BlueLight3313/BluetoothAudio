
v5.0 Stability Update
---------------------

Changes:
- added stable reconnect thread
- separated reconnect logic from pairing logic
- ensured compilation-safe modules
- prepared MAP notification architecture
