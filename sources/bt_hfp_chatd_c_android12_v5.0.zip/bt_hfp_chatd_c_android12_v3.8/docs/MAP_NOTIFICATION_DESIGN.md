
MAP Notification subsystem (v5.0)
---------------------------------

Added design support for message notification events.

Future implementation will support:
- MAP MNS channel
- message arrival notifications
- headset push updates
