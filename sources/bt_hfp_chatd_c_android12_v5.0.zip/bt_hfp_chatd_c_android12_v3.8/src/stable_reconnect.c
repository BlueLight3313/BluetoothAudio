
#include "stable_reconnect.h"
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

static pthread_t th;
static int running=0;
static char target[18];

static void* loop(void* p){
    while(running){
        printf("Reconnect attempt to %s\n",target);
        sleep(5);
    }
    return NULL;
}

void reconnect_start(const char* mac){
    strncpy(target,mac,sizeof(target));
    running=1;
    pthread_create(&th,NULL,loop,NULL);
}

void reconnect_stop(){
    running=0;
}
