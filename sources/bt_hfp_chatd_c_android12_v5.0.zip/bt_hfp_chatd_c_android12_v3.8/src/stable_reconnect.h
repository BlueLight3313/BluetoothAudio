
#pragma once
void reconnect_start(const char* mac);
void reconnect_stop();
