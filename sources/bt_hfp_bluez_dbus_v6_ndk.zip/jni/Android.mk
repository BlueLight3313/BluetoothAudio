
LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := bt_chatd

LOCAL_SRC_FILES := ../src/main.c ../src/dbus_manager.c ../modules/scan/scan.c ../modules/pair/pair.c ../modules/connect/connect.c ../modules/reconnect/reconnect.c ../modules/hfp/hfp_ag.c ../modules/map/map_mse.c

LOCAL_C_INCLUDES := ../include ../modules/scan ../modules/pair ../modules/connect ../modules/reconnect ../modules/hfp ../modules/map

LOCAL_LDLIBS := -ldbus-1 -lpthread

include $(BUILD_EXECUTABLE)
