
#include <stdio.h>
#include "dbus_manager.h"
#include "scan.h"
#include "pair.h"
#include "connect.h"
#include "reconnect.h"
#include "hfp_ag.h"
#include "map_mse.h"

int main()
{
    printf("bt_chatd BlueZ DBus v6 starting\n");

    if(dbus_manager_init()!=0)
    {
        printf("DBus init failed\n");
        return -1;
    }

    scan_init();
    pair_init();
    connect_init();
    reconnect_init();
    hfp_init();
    map_init();

    dbus_manager_loop();
    return 0;
}
