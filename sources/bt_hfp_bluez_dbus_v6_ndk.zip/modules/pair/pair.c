
#include <stdio.h>
#include "pair.h"

int pair_init()
{
    printf("Pair module ready\n");
    return 0;
}

int pair_device(const char* mac)
{
    printf("Pair device %s\n",mac);
    return 0;
}
