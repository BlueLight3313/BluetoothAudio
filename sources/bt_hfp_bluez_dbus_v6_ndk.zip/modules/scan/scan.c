
#include <stdio.h>
#include "scan.h"

int scan_init()
{
    printf("Scan module ready\n");
    return 0;
}

int scan_start()
{
    printf("BlueZ StartDiscovery call\n");
    return 0;
}

int scan_stop()
{
    printf("BlueZ StopDiscovery call\n");
    return 0;
}
