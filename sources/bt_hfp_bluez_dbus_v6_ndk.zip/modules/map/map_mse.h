
#pragma once
int map_init();
int map_send_sms(const char* msg);
