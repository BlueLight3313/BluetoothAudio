
#include <stdio.h>
#include "map_mse.h"

int map_init()
{
    printf("MAP Message Server ready\n");
    return 0;
}

int map_send_sms(const char* msg)
{
    printf("Send MAP SMS: %s\n",msg);
    return 0;
}
