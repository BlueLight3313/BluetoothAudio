
#include <stdio.h>
#include "connect.h"

int connect_init()
{
    printf("Connect module ready\n");
    return 0;
}

int connect_device(const char* mac)
{
    printf("Connect device %s\n",mac);
    return 0;
}
