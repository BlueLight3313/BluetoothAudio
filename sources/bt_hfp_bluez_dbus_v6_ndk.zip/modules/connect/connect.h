
#pragma once
int connect_init();
int connect_device(const char* mac);
