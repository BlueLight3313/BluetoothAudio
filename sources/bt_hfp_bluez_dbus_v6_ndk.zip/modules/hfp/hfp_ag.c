
#include <stdio.h>
#include "hfp_ag.h"

int hfp_init()
{
    printf("HFP Audio Gateway ready\n");
    return 0;
}

int hfp_start_chat()
{
    printf("Start SCO voice chat\n");
    return 0;
}

int hfp_stop_chat()
{
    printf("Stop SCO voice chat\n");
    return 0;
}
