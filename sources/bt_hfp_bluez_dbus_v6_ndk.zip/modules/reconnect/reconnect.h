
#pragma once
int reconnect_init();
void reconnect_start(const char* mac);
