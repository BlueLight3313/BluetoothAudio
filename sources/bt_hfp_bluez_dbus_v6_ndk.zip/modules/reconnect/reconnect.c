
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include "reconnect.h"

static char target[18];
static pthread_t th;

static void* loop(void* p)
{
    while(1)
    {
        printf("Reconnect attempt to %s\n",target);
        sleep(5);
    }
}

int reconnect_init()
{
    printf("Reconnect module ready\n");
    return 0;
}

void reconnect_start(const char* mac)
{
    strncpy(target,mac,sizeof(target));
    pthread_create(&th,NULL,loop,NULL);
}
