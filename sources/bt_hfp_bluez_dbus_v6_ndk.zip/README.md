
Bluetooth Chat Project v6 (BlueZ + DBus)

Features
- Scan
- Pair (multi pairing ready)
- Connect
- Auto reconnect
- HFP voice chat
- MAP SMS

Build with Android NDK

cd jni
ndk-build

Binary:
libs/<abi>/bt_chatd
