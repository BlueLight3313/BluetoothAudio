
#pragma once
#include <dbus/dbus.h>
int dbus_manager_init();
void dbus_manager_loop();
DBusConnection* dbus_manager_get();
