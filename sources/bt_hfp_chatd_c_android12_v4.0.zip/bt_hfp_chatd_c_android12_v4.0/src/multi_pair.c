
#include "multi_pair.h"
#include <string.h>
#include <stdio.h>

static paired_device_t devices[MAX_PAIRED_DEVICES];
static int count=0;

void pair_db_init(){ count=0; }

int pair_db_add(const char* mac){
    if(count>=MAX_PAIRED_DEVICES) return -1;
    snprintf(devices[count].mac,18,"%s",mac);
    count++;
    return 0;
}

int pair_db_remove(const char* mac){
    for(int i=0;i<count;i++){
        if(strcmp(devices[i].mac,mac)==0){
            for(int j=i;j<count-1;j++) devices[j]=devices[j+1];
            count--;
            return 0;
        }
    }
    return -1;
}

int pair_db_list(char* out,int sz){
    int n=0;
    for(int i=0;i<count;i++)
        n+=snprintf(out+n,sz-n,"%s\n",devices[i].mac);
    return n;
}
