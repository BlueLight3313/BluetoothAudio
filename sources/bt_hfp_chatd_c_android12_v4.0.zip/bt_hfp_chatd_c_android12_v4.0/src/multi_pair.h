
#pragma once
#define MAX_PAIRED_DEVICES 8

typedef struct {
    char mac[18];
} paired_device_t;

void pair_db_init();
int pair_db_add(const char* mac);
int pair_db_remove(const char* mac);
int pair_db_list(char* out,int sz);
