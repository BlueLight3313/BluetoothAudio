
#include "auto_reconnect.h"
#include <unistd.h>
#include <stdio.h>

void auto_reconnect_loop(const char* mac){
    while(1){
        printf("Attempt reconnect to %s\n",mac);
        sleep(5);
    }
}
