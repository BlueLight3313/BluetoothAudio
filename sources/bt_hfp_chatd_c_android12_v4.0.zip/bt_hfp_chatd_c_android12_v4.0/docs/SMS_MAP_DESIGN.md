
SMS subsystem (MAP based)
-------------------------

Implemented foundation:
- local message store
- MAP MSE server
- commands:
  MSG_SEND <text>
  MSG_LIST
  MSG_CLEAR

Future improvements:
- MAP MAS SDP advertisement
- notification registration
- vendor compatibility
