APP_PLATFORM := android-31
APP_ABI := armeabi-v7a arm64-v8a
