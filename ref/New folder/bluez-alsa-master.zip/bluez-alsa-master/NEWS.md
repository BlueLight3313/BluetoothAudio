<!--
SPDX-FileCopyrightText: 2016-2025 BlueALSA developers
SPDX-License-Identifier: MIT
-->

# BlueALSA Release Notes

## unreleased

- renamed bluealsa to bluealsad (no backward compatibility)
- renamed bluealsa.conf to org.bluealsa.conf (no backward compatibility)
- renamed bluealsa-cli to bluealsactl (no backward compatibility)
- optional support for A2DP Sink and Source with LHDC v3 codec
- optional support for Audio Streaming for Hearing Aids (ASHA) profile
- channel map and volume control for surround sound (5.1, 7.1) audio
- native A2DP volume control by default (dropped --a2dp-volume option)
- optional support for adaptive audio resampling in bluealsa-aplay
- fix configuration for Android 13 A2DP Opus codec
- improved ALSA PCM support for A2DP-sink, HFP-HF and HSP-HS

## bluez-alsa v4.3.1 (2024-08-30)

- fix crash when playing audio with more than 2 channels
- fix AAC configuration selection for low sample rates

## bluez-alsa v4.3.0 (2024-08-13)

- optional support for Android 13 A2DP Opus codec
- multi channels and sample rates mode for ALSA PCM plug-in
- bluealsa-aplay: fix volume synchronization on Raspberry Pi

## bluez-alsa v4.2.0 (2024-05-11)

- optional support for BLE MIDI 1.0 profile as a GATT server
- optional support for HFP LC3-SWB (Super Wide Band) codec
- command line option to set real-time priority for IO threads
- command line option to filter log messages based on severity
- allow to select individual extended controls in ALSA plug-in
- codec-specific delay adjustment with ALSA control and persistency
- improved AAC codec support to be conformant with A2DP v1.4
- fix for SBC codec and audio scaling on big-endian platforms
- fix mSBC decode for MTU > 60 bytes (e.g. Realtek USB adapters)
- bluealsa-aplay: option to auto-select volume mode for used PCM
- support use of libfreeaptx for apt-X and apt-X HD codecs
- stability fixes for ALSA PCM I/O plug-in

## bluez-alsa v4.1.1 (2023-06-24)

- fix for oFono HF role SCO socket authorization
- fix for mSBC MTU adjustment for Realtek USB adapters
- bluealsa-aplay: fix playback after BT codec update

## bluez-alsa v4.1.0 (2023-05-23)

- removed deprecated org.bluealsa.Manager1 D-Bus interface
- persistent storage for PCM volume and mute state
- PCM volume control with oFono HFP-AG and HFP-HF profiles
- transport running state exported in PCM D-Bus interface
- A2DP codec configuration blob exported in PCM D-Bus interface
- optional non-dynamic operation mode for ALSA control plug-in
- optional extended controls for ALSA control plug-in
- changed RFCOMM D-Bus API features property to array of strings
- fix for SCO link establishment for oFono HFP-AG profile
- fix for volume control for HSP-HS and HFP-HF profiles
- stability fixes for ALSA PCM I/O and control plug-ins
- bluealsa-aplay: fix for volume synchronization
- lots of fixes for race conditions (TSAN)
- lots of updates to the manual pages

## bluez-alsa v4.0.0 (2022-06-03)

- changes in command line options (no backward compatibility)
- implement D-Bus ObjectManager (deprecate org.bluealsa.Manager1)
- optional support for A2DP FastStream codec (music & voice)
- optional support for A2DP LC3plus codec (music & voice)
- enhanced SBC XQ mode (XQ+) which bumps bitrate to 595 kbps
- packet loss concealment (PLC) for HFP with mSBC codec
- enable/disable BT codecs via command line options
- allow to select BT transport codec with ALSA configuration
- allow to set PCM volume properties with ALSA configuration
- optional single-device mode for ALSA control plug-in
- export battery status/charge via BlueZ battery provider
- connection keep-alive timeout for all BT profiles
- better conformance with RTP specification for A2DP codecs
- fix for rapid consecutive SCO link close(2)/connect(2)
- bluealsa-aplay: forward PCM volume to ALSA mixer element
- systemd service files for bluealsa and bluealsa-aplay
- lots of fixes for ALSA PCM I/O and control plug-ins

## bluez-alsa v3.1.0 (2021-06-01)

- higher PCM bit depth for apt-X HD (24-bit) and LDAC (32-bit)
- support for A2DP Sink with apt-X (HD) if decoder is available
- support for A2DP Sink with LDAC codec if decoder is available
- better audio volume scaling (Bluetooth volume as loudness)
- support TLV data for dB calculations in ALSA control plug-in
- fix PCM delay reporting from connected Bluetooth devices
- most recently connected Bluetooth device as a default PCM
- lots of improvements to the ALSA PCM I/O plug-in
- use rst2man (docutils) instead of pandoc to build man-pages
- bluealsa-cli: utility for using D-Bus API from command line
- bash completion script for installed applications

## bluez-alsa v3.0.0 (2020-09-15)

- separate D-Bus paths for PCM sink and source (API breakage)
- store PCM sample physical width in the D-Bus format property
- list available and supported audio codecs via D-Bus API
- support for A2DP audio codec selection or reconfiguration
- fix SBC encoder bit-pool selection (support SBC XQ quality)
- allow to disable software volume scaling via D-Bus API
- great improvement to the PCM I/O plug-in (thanks to @borine)
- install bluez-alsa manual pages (optional, requires pandoc)
- bluealsa-aplay: list connected BT devices and available PCMs
- bluealsa-aplay: fix PCM corruption due to out-of-bounds read

## bluez-alsa v2.1.0 (2020-01-25)

- support HSP/HFP headset mode (connect phone without oFono)
- optional integration with UPower for battery level reporting
- initial (HFP only) support for audio codec selection
- auto-detect BlueZ D-Bus service appearance/disappearance
- lots of improvements for SCO connection robustness
- route SCO data via transport interface in Broadcom chips
- lots of fixes for ALSA plug-ins and BlueALSA server

## bluez-alsa v2.0.0 (2019-10-15)

- BlueALSA server as a D-Bus service with public API
- optional support for A2DP Sink and Source with MP3 codec
- optional support for A2DP Source with apt-X HD codec
- optional support for mSBC codec in HFP profile
- manage internal BlueALSA memory by reference counting
- lots of fixes for ALSA plug-ins and BlueALSA server

## bluez-alsa v1.4.0 (2019-03-16)

- optional support for A2DP Source with LDAC codec
- optional support for HFP-AG and HFP-HF over oFono
- keep-alive timeout for closed A2DP connections
- volume update notification for connected ALSA mixers
- HCI selection by MAC address on multi-HCI hosts
- lots of fixes for ALSA plug-ins and BlueALSA server

## bluez-alsa v1.3.1 (2018-09-08)

- bluealsa-aplay: release playback PCM when there is no data
- workaround for RTP mark bit quirk (fix audio from Android)
- stability fixes for ALSA plug-ins and BlueALSA server

## bluez-alsa v1.3.0 (2018-07-23)

- initial support for Hands-Free Profile (HFP-HF)
- optional support for A2DP Source with apt-X codec
- multiple A2DP connections (allow to connect many headsets)
- report missing device in ALSA after BT disconnection
- selective profile selection via command line arguments
- optional logging to system logger (e.g. syslog)
- PCM FIFO file descriptor sharing via domain socket
- configuration option for PulseAudio compatibility
- bluealsa-rfcomm tool for handling custom RFCOMM commands
- lots of fixes for ALSA plug-ins and BlueALSA server

## bluez-alsa v1.2.0 (2017-04-13)

- optional A2DP Sink and Source with AAC codec
- initial support for HSP and HFP Audio Gateway
- support remote device volume change for A2DP Sink
- display remote BT device battery level in ALSA mixer
- allow to force 44100 Hz and/or mono audio for A2DP
- software volume control separately for left/right channel
- account for PCM delay reported by remote BT headset
- randomize RTP timestamp and sequence number (RFC 3016)
- bluealsa-aplay tool for playing audio from BT device
- lots of fixes for ALSA plug-ins and BlueALSA server

## bluez-alsa v1.1.0 (2016-09-19)

- support for PCM pause, resume and delay reporting
- lots of fixes for ALSA plug-ins and BlueALSA server

## bluez-alsa v1.0.0 (2016-08-27)

- A2DP Sink and Source with mandatory SBC codec
- PCM I/O and control plug-ins for ALSA integration
- hcitop tool for displaying HCI bandwidth
