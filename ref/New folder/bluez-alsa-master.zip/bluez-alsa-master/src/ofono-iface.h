/*
 * BlueALSA - ofono-iface.h
 * SPDX-FileCopyrightText: 2018-2025 BlueALSA developers
 * SPDX-License-Identifier: MIT
 */

#ifndef BLUEALSA_OFONOIFACE_H_
#define BLUEALSA_OFONOIFACE_H_

#include "dbus/org.ofono.h"

#define OFONO_SERVICE "org.ofono"

#define OFONO_IFACE_MANAGER          OFONO_SERVICE ".Manager"
#define OFONO_IFACE_HF_AUDIO_AGENT   OFONO_SERVICE ".HandsfreeAudioAgent"
#define OFONO_IFACE_HF_AUDIO_CARD    OFONO_SERVICE ".HandsfreeAudioCard"
#define OFONO_IFACE_HF_AUDIO_MANAGER OFONO_SERVICE ".HandsfreeAudioManager"
#define OFONO_IFACE_CALL_VOLUME      OFONO_SERVICE ".CallVolume"

#define OFONO_AUDIO_CARD_TYPE_AG "gateway"
#define OFONO_AUDIO_CARD_TYPE_HF "handsfree"

#define OFONO_AUDIO_CODEC_CVSD    0x01
#define OFONO_AUDIO_CODEC_MSBC    0x02
#define OFONO_AUDIO_CODEC_LC3_SWB 0x03

#define OFONO_MODEM_TYPE_HARDWARE "hardware"
#define OFONO_MODEM_TYPE_HFP      "hfp"
#define OFONO_MODEM_TYPE_SAP      "sap"

#endif
