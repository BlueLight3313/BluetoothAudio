
#ifndef SCO_AUDIO_H
#define SCO_AUDIO_H

int sco_get_fd();
void sco_handle_audio();

#endif
