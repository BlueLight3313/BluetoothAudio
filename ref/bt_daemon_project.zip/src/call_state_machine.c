
#include "call_state_machine.h"

static call_state_t current_state = CALL_IDLE;

void call_set_state(call_state_t state)
{
    current_state = state;
}

call_state_t call_get_state()
{
    return current_state;
}
