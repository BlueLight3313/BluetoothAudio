
#include <poll.h>
#include <stdio.h>
#include "event_loop.h"
#include "hci_manager.h"
#include "rfcomm_hfp.h"
#include "sco_audio.h"

#define MAX_FDS 5

static int running = 1;

void event_loop_start()
{
    struct pollfd fds[MAX_FDS];

    while (running)
    {
        int n = 0;

        int hci_fd = hci_get_fd();
        if (hci_fd >= 0)
        {
            fds[n].fd = hci_fd;
            fds[n].events = POLLIN;
            n++;
        }

        int rfcomm_fd = rfcomm_get_fd();
        if (rfcomm_fd >= 0)
        {
            fds[n].fd = rfcomm_fd;
            fds[n].events = POLLIN;
            n++;
        }

        int sco_fd = sco_get_fd();
        if (sco_fd >= 0)
        {
            fds[n].fd = sco_fd;
            fds[n].events = POLLIN;
            n++;
        }

        int ret = poll(fds, n, -1);

        if (ret <= 0)
            continue;

        int i = 0;

        if (hci_fd >= 0 && (fds[i++].revents & POLLIN))
            hci_handle_event();

        if (rfcomm_fd >= 0 && (fds[i++].revents & POLLIN))
            rfcomm_handle_event();

        if (sco_fd >= 0 && (fds[i++].revents & POLLIN))
            sco_handle_audio();
    }
}

void event_loop_stop()
{
    running = 0;
}
