
#include <stdio.h>
#include "event_loop.h"
#include "hci_manager.h"

int main()
{
    printf("Bluetooth Call Daemon Starting\n");

    if (hci_init() < 0)
    {
        printf("Failed to initialize HCI\n");
        return -1;
    }

    event_loop_start();

    return 0;
}
