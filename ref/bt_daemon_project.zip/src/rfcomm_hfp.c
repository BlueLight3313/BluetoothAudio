
#include "rfcomm_hfp.h"
#include <stdio.h>

static int rfcomm_fd = -1;

int rfcomm_get_fd()
{
    return rfcomm_fd;
}

void rfcomm_handle_event()
{
    printf("RFCOMM event\n");
}
