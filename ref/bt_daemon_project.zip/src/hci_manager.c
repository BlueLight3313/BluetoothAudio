
#include "hci_manager.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>
#include <bluetooth/hci_lib.h>

static int hci_fd = -1;

int hci_get_fd()
{
    return hci_fd;
}

int hci_init()
{
    struct sockaddr_hci addr;

    int dev_id = hci_get_route(NULL);

    if (dev_id < 0)
    {
        printf("No Bluetooth adapter found\n");
        return -1;
    }

    hci_fd = socket(AF_BLUETOOTH, SOCK_RAW, BTPROTO_HCI);

    if (hci_fd < 0)
    {
        perror("HCI socket");
        return -1;
    }

    addr.hci_family = AF_BLUETOOTH;
    addr.hci_dev = dev_id;
    addr.hci_channel = HCI_CHANNEL_RAW;

    if (bind(hci_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0)
    {
        perror("HCI bind");
        close(hci_fd);
        return -1;
    }

    printf("HCI initialized (dev %d)\n", dev_id);

    return 0;
}

void hci_handle_event()
{
    unsigned char buf[1024];

    int len = read(hci_fd, buf, sizeof(buf));

    if (len > 0)
    {
        printf("HCI event received (%d bytes)\n", len);
    }
}
