
#include "sco_audio.h"
#include <stdio.h>

static int sco_fd = -1;

int sco_get_fd()
{
    return sco_fd;
}

void sco_handle_audio()
{
    printf("SCO audio event\n");
}
