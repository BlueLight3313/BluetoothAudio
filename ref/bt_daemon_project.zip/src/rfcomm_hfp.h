
#ifndef RFCOMM_HFP_H
#define RFCOMM_HFP_H

int rfcomm_get_fd();
void rfcomm_handle_event();

#endif
