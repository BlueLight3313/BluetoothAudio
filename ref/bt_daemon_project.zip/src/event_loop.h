
#ifndef EVENT_LOOP_H
#define EVENT_LOOP_H

void event_loop_start();
void event_loop_stop();

#endif
