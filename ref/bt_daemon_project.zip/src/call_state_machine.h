
#ifndef CALL_STATE_MACHINE_H
#define CALL_STATE_MACHINE_H

typedef enum
{
    CALL_IDLE,
    CALL_RINGING,
    CALL_DIALING,
    CALL_ACTIVE
} call_state_t;

void call_set_state(call_state_t state);
call_state_t call_get_state();

#endif
