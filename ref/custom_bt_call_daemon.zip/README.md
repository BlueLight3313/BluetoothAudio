
# Custom Bluetooth Call Daemon (Self‑Contained)

This project demonstrates a Bluetooth HFP call daemon architecture implemented
without depending on system Bluetooth development headers (no <bluetooth/...> includes).

Minimal protocol definitions are provided locally to reduce Linux version dependency.
