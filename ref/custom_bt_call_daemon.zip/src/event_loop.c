
#include <poll.h>
#include <stdio.h>
#include "event_loop.h"
#include "hci_manager.h"
#include "rfcomm_hfp.h"
#include "sco_audio.h"

void event_loop_start()
{
    struct pollfd fds[3];

    while (1)
    {
        int n = 0;

        int hci = hci_get_fd();
        if (hci >= 0)
        {
            fds[n].fd = hci;
            fds[n].events = POLLIN;
            n++;
        }

        int rf = rfcomm_get_fd();
        if (rf >= 0)
        {
            fds[n].fd = rf;
            fds[n].events = POLLIN;
            n++;
        }

        int sco = sco_get_fd();
        if (sco >= 0)
        {
            fds[n].fd = sco;
            fds[n].events = POLLIN;
            n++;
        }

        int ret = poll(fds, n, -1);
        if (ret <= 0) continue;

        int i = 0;

        if (hci >= 0 && (fds[i++].revents & POLLIN))
            hci_handle_event();

        if (rf >= 0 && (fds[i++].revents & POLLIN))
            rfcomm_handle_event();

        if (sco >= 0 && (fds[i++].revents & POLLIN))
            sco_handle_audio();
    }
}
