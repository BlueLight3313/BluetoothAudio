
#include <stdio.h>
#include "rfcomm_hfp.h"

static int rf_fd = -1;

int rfcomm_get_fd()
{
    return rf_fd;
}

void rfcomm_handle_event()
{
    printf("RFCOMM HFP message received\n");
}
