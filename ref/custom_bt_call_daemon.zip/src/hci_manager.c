
#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include "hci_manager.h"
#include "bt_defs.h"

static int hci_fd = -1;

int hci_get_fd()
{
    return hci_fd;
}

int hci_init()
{
    hci_fd = socket(AF_BLUETOOTH, SOCK_RAW, BTPROTO_HCI);

    if (hci_fd < 0)
    {
        perror("HCI socket");
        return -1;
    }

    printf("HCI socket opened\n");
    return 0;
}

void hci_handle_event()
{
    unsigned char buf[1024];
    int len = read(hci_fd, buf, sizeof(buf));

    if (len > 0)
        printf("HCI event received (%d bytes)\n", len);
}
