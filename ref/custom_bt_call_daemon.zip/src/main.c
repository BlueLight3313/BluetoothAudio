
#include <stdio.h>
#include "event_loop.h"
#include "hci_manager.h"

int main()
{
    printf("Custom Bluetooth Call Daemon\n");

    if (hci_init() < 0)
    {
        printf("HCI init failed\n");
        return -1;
    }

    event_loop_start();
    return 0;
}
