
#ifndef BT_DEFS_H
#define BT_DEFS_H
#include <stdint.h>

#define AF_BLUETOOTH 31
#define BTPROTO_HCI 1
#define BTPROTO_RFCOMM 3
#define BTPROTO_SCO 2

typedef struct {
    uint8_t b[6];
} bdaddr_t;

typedef struct {
    uint16_t opcode;
    uint8_t plen;
} hci_cmd_hdr;

typedef struct {
    uint8_t evt;
    uint8_t plen;
} hci_event_hdr;

#endif
