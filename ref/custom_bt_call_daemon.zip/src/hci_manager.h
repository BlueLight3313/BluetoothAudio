
#ifndef HCI_MANAGER_H
#define HCI_MANAGER_H
int hci_init();
int hci_get_fd();
void hci_handle_event();
#endif
